"""DTPolicy: adapta un DecisionTransformer entrenado a la interfaz Policy del protocolo."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import torch

from dt.modelo import UNKNOWN_GROUP, DecisionTransformer, prev_ratings


def load_model(run_dir: Path | str, device: str = "cpu") -> DecisionTransformer:
    ckpt = torch.load(Path(run_dir) / "modelo.pt", map_location=device)
    model = DecisionTransformer(**ckpt["model_kwargs"]).to(device)
    model.load_state_dict(ckpt["state_dict"])
    return model.eval()


class DTPolicy:
    """Usa el modelo de forma autorregresiva con un retorno objetivo fijo.

    En el paso t:
      R̂_k = objetivo − suma de los ratings revelados antes de k   (k = 0..t)
      s_k = (grupo o "desconocido", rating revelado en k − 1)
      a_t = relleno (la salida de s_t no lo ve)
    Los puntajes son las logits del paso t.

    Con warm-up, los ítems del warm-up llegan en items_seen y sus ratings también se
    restan de R̂: el objetivo se refiere a los 20 pasos de la sesión completa.
    """

    def __init__(self, model: DecisionTransformer, target_return: float, device: str = "cpu"):
        self.model = model.eval()
        self.target = float(target_return)
        self.device = torch.device(device)

    def reset(self, group: int | None, horizon: int) -> None:
        if horizon > self.model.horizon:
            raise ValueError(f"horizonte {horizon} mayor que el del modelo ({self.model.horizon})")
        self.group = UNKNOWN_GROUP if group is None else int(group)

    @torch.no_grad()
    def scores(self, items_seen: np.ndarray, ratings_seen: np.ndarray) -> np.ndarray:
        t = len(items_seen)
        ratings = np.asarray(ratings_seen, dtype=np.float32)

        rtg = self.target - np.concatenate([[0.0], np.cumsum(ratings)])            # (t + 1,)
        items = np.append(np.asarray(items_seen, dtype=np.int64), 0)                # relleno en t
        ratings_pad = np.append(ratings, 1.0)                                       # r_t no se usa

        dev = self.device
        logits = self.model(
            torch.as_tensor(rtg, dtype=torch.float32, device=dev)[None],
            torch.as_tensor(items, device=dev)[None],
            prev_ratings(torch.as_tensor(ratings_pad, device=dev)[None]),
            torch.tensor([self.group], device=dev),
        )[0, t]
        return logits.double().cpu().numpy()
