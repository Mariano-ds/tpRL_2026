"""Grafica las curvas de entrenamiento (curvas.csv) del DT y de IQL, sin recortes.

    python -m dt.curvas --runs outputs/dt_netflix_random_seed{0,1,2} --output outputs/curvas_dt_random
    python -m dt.curvas --runs outputs/iql_netflix_random_g0.9_t0.7_b3_seed{0,1,2} --output outputs/curvas_iql_random

Detecta el tipo de modelo por config.json. Una línea por corrida (hasta 8; por ejemplo, las
semillas de una configuración). Todas las épocas y el rango completo de cada eje: nada se recorta.

  DT:  cross-entropy de train, de val con grupo visible y de val con grupo oculto, con la
       referencia uniforme log(n_items) y la época del checkpoint guardado marcada.
  IQL: pérdidas de V, Q y π (train sólido, val punteado), peso medio de AWR, fracción de pesos
       truncados, desvío de las ventajas y V(s_0) medio en val.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

PALETTE = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, MUTED, GRID = "#1f1f1e", "#6b6a64", "#e4e3dd"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--runs", type=Path, nargs="+", required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--nombre", default=None, help="nombre del PNG (default: curvas_dt.png o curvas_iql.png)")
    return p.parse_args()


def style(ax, title: str) -> None:
    ax.set_title(title, color=INK, fontsize=10, loc="left")
    ax.grid(color=GRID, lw=0.6)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(GRID)
    ax.tick_params(colors=MUTED, labelsize=8)
    from matplotlib.ticker import MaxNLocator
    ax.xaxis.set_major_locator(MaxNLocator(integer=True))


def plot_dt(runs, curves, out: Path, plt, name: str = "curvas_dt.png") -> Path:
    fig, axes = plt.subplots(1, 3, figsize=(13, 3.8), sharey=True)
    panels = [("train", "Train"), ("val_visible", "Val, grupo visible (checkpoint)"), ("val_oculto", "Val, grupo oculto")]
    for ax, (col, title) in zip(axes, panels):
        for i, (run, df) in enumerate(zip(runs, curves)):
            c = PALETTE[i % len(PALETTE)]
            ax.plot(df["epoch"], df[col], color=c, lw=2, label=run.name)
            if col == "val_visible":
                best = df.loc[df[col].idxmin()]
                ax.plot(best["epoch"], best[col], "o", color=c, ms=8, mec="white", mew=2, zorder=4)
        ax.axhline(curves[0]["uniforme"].iloc[0], color=MUTED, lw=1, ls="--")
        ax.text(ax.get_xlim()[1], curves[0]["uniforme"].iloc[0], "log(n_items) ", color=MUTED, fontsize=8,
                ha="right", va="bottom")
        style(ax, title)
        ax.set_xlabel("Época", color=INK, fontsize=9)
    axes[0].set_ylabel("Cross-entropy", color=INK, fontsize=9)
    fig.suptitle("DT: curvas de entrenamiento (● = época del checkpoint)", color=INK, fontsize=12, x=0.01, ha="left")
    if len(runs) > 1:
        fig.legend(*axes[0].get_legend_handles_labels(), loc="upper right", frameon=False, fontsize=8)
    fig.tight_layout(rect=(0, 0, 1, 0.92))
    path = out / name
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path


def plot_iql(runs, curves, out: Path, plt, name: str = "curvas_iql.png") -> Path:
    panels = [("v", "Pérdida de V (expectil)", True), ("q", "Pérdida de Q (TD)", True),
              ("pi", "Pérdida de π (AWR)", True), ("w_media", "Peso medio de AWR", True),
              ("w_truncados", "Fracción de pesos truncados", True), ("adv_desvio", "Desvío de las ventajas", True),
              ("v0", "V(s₀) medio", True), ("q_media", "Q medio en la acción registrada", True)]
    fig, axes = plt.subplots(2, 4, figsize=(15, 6.4))
    for ax, (key, title, both) in zip(axes.flat, panels):
        for i, (run, df) in enumerate(zip(runs, curves)):
            c = PALETTE[i % len(PALETTE)]
            ax.plot(df["epoch"], df[f"train_{key}"], color=c, lw=2, label=run.name)
            if both:
                ax.plot(df["epoch"], df[f"val_{key}"], color=c, lw=1.5, ls=":")
        if key == "w_media":
            ax.axhline(1.0, color=MUTED, lw=1, ls="--")
            ax.text(ax.get_xlim()[1], 1.0, "≈ behavior cloning ", color=MUTED, fontsize=8, ha="right", va="bottom")
        style(ax, title)
    for ax in axes[1]:
        ax.set_xlabel("Época", color=INK, fontsize=9)
    cfg = json.loads((runs[0] / "config.json").read_text())
    fig.suptitle(f"IQL: curvas de entrenamiento (γ={cfg['gamma']:g}, τ={cfg['tau']:g}, β={cfg['beta']:g}; "
                 f"sólido = train, punteado = val)", color=INK, fontsize=12, x=0.01, ha="left")
    if len(runs) > 1:
        fig.legend(*axes[0, 0].get_legend_handles_labels(), loc="upper right", frameon=False, fontsize=8)
    fig.tight_layout(rect=(0, 0, 1, 0.92))
    path = out / name
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path


def main() -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    args = parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    kinds = {"iql" if "gamma" in json.loads((r / "config.json").read_text()) else "dt" for r in args.runs}
    if len(kinds) > 1:
        raise SystemExit("Mezcla de corridas DT e IQL: graficarlas por separado.")
    if len(args.runs) > len(PALETTE):
        raise SystemExit(f"Hasta {len(PALETTE)} corridas por gráfico (una por color); dividir en varios.")
    curves = [pd.read_csv(r / "curvas.csv") for r in args.runs]
    kind = kinds.pop()
    name = args.nombre or f"curvas_{kind}.png"
    path = (plot_dt if kind == "dt" else plot_iql)(args.runs, curves, args.output, plt, name)
    print(f"gráfico en {path}")


if __name__ == "__main__":
    main()
