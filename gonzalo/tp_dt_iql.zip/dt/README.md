# Decision Transformer: entrenamiento y evaluación

> Este README cubre también las piezas compartidas con IQL: `repro.py`, `curvas.py` y `reporte.py`.
>
> Para correr todo el TP de una vez (líneas base, DT, IQL, reportes y comparación de logs, de forma reanudable) ver `experimentos/README.md`. Este README describe cada paso por separado.

Implementación mínima del entrenamiento y la evaluación del DT del TP. Usa el protocolo común (`protocolo/`) para cargar datos, separar train y validación y generar logs. No reimplementa nada de eso.

## Archivos

| Archivo | Qué hace |
|---|---|
| `modelo.py` | Define `DecisionTransformer`, la máscara de ítems ya vistos (`seen_before_mask`), la pérdida (`dt_loss`), el cálculo del rating previo (`prev_ratings`) y el test de no fuga (`check_no_leak`). |
| `entrenar.py` | Script de entrenamiento: carga episodios, entrena, valida y guarda el mejor checkpoint. |
| `repro.py` | `env_info()`: versiones de Python, torch, numpy y pandas, GPU, commit de git, comando y huella SHA-256 del código de `dt/` e `iql/`. Se guarda en `config.json` de cada corrida, del DT y de IQL. |
| `curvas.py` | Gráficos de las curvas de entrenamiento del DT y de IQL, sin recortes. |
| `tests/test_dt.py` | Tests unitarios: no fuga en los pasos 0, 7 y 19, máscara de ítems vistos y corrimiento del rating previo. |
| `tests/test_reporte.py` | Tests del cálculo de IC 95 % por usuario y del desvío entre semillas de entrenamiento. |

### Modelo (`modelo.py`)

- Cada paso del episodio aporta tres tokens intercalados: R̂_t, s_t y a_t. La máscara es causal sobre los 60 tokens.
- **Estado s_t:** el embedding del grupo (0 a 7, o 8 = "desconocido") más el embedding del rating del paso anterior (0 = sin rating previo, 1 a 5 en los demás casos). Nunca incluye r_t.
- **R̂** entra crudo y el modelo lo divide por 100 internamente, así el entrenamiento y la política le pasan el mismo valor.
- **Salida:** a_t se predice desde la salida del token s_t. La proyección a los n_items comparte pesos con el embedding de ítems.
- **Pérdida:** cross-entropy con los ítems ya mostrados en el episodio enmascarados con −∞.

### Entrenamiento (`entrenar.py`)

1. Separa los usuarios de train en 90 % / 10 % con `split_by_user`.
2. Arma episodios de 20 pasos, con `make_episodes` para `--logs random` y `logged_episodes` para `mixto` o `experto`. Las semillas de generación de logs quedan fijas (0 para train y 1 para validación), así que todas las semillas de entrenamiento ven los mismos datos.
3. Corre el test de no fuga sobre el modelo inicializado y aborta si falla.
4. Entrena con AdamW, OneCycle y recorte de gradiente en 1,0. En cada batch reemplaza el grupo por "desconocido" en el 30 % de los episodios (`--p-hide`).
5. Al final de cada época calcula la cross-entropy de validación con el grupo visible y con el grupo oculto. Guarda el checkpoint con la menor pérdida de validación con el grupo visible.

**Cómo leer la pérdida:** la referencia es log(n_items) ≈ 6,62 en Netflix. Con los logs `random` la política de registro es uniforme y la pérdida apenas baja. Es lo esperable y no indica un error: la pérdida mide qué tan bien el modelo imita los logs, no qué tan bien recomienda.

## Cómo correrlo

Todo se ejecuta desde `2026/tp`, con la carpeta `dt/` al lado de `protocolo/` y el entorno virtual activado.

### Tests

```bash
python -m pytest dt/tests
```

Si `test_no_leak` falla, hay una fuga en la máscara o en la alineación, y ningún resultado posterior es válido.

### Entrenamiento

```bash
# una corrida
python -m dt.entrenar --dataset netflix --logs random --seed 0

# 3 semillas × 2 tipos de logs
for logs in random mixto; do
  for seed in 0 1 2; do
    python -m dt.entrenar --dataset netflix --logs $logs --seed $seed
  done
done
```

Argumentos principales:

| Argumento | Default | Descripción |
|---|---|---|
| `--dataset` | `netflix` | `netflix` o `goodreads` |
| `--logs` | `random` | `random`, `mixto` o `experto` |
| `--seed` | `0` | semilla de entrenamiento (inicialización y orden) |
| `--epochs` | `20` | épocas |
| `--batch-size` | `256` | episodios por batch |
| `--lr` | `1e-3` | lr máximo de OneCycle |
| `--d-model`, `--n-layers`, `--n-heads` | `128`, `3`, `4` | tamaño del transformer |
| `--p-hide` | `0.3` | fracción de episodios de train con el grupo oculto |
| `--output` | `outputs/dt_{dataset}_{logs}_seed{seed}` | carpeta de salida |

`python -m dt.entrenar --help` muestra la lista completa.

### Salidas

En la carpeta de salida:

| Archivo | Contenido |
|---|---|
| `modelo.pt` | mejor checkpoint: `state_dict`, `model_kwargs` para reconstruir el modelo, época y pérdida de validación |
| `config.json` | argumentos de la corrida, decisiones de diseño a declarar y, en `entorno`, versiones, GPU, commit, comando y huella del código |
| `curvas.csv` | por época: pérdida de train, de validación con grupo visible y con grupo oculto, referencia uniforme y lr |
| `retornos_train.json` | media, mínimo, máximo y percentiles 10–99 de los retornos de train: el soporte para el barrido de retorno pedido |

Para cargar el modelo entrenado:

```python
import torch
from dt.modelo import DecisionTransformer

ckpt = torch.load("outputs/dt_netflix_random_seed0/modelo.pt")
model = DecisionTransformer(**ckpt["model_kwargs"])
model.load_state_dict(ckpt["state_dict"])
```

## Evaluación con el protocolo

| Archivo | Qué hace |
|---|---|
| `politica.py` | `DTPolicy`: adapta el modelo a la interfaz `reset` / `scores`. En el paso t pide R̂_k = objetivo − ratings ya revelados, arma la secuencia con un relleno en a_t y devuelve las logits del paso t. Con warm-up, los ratings del warm-up también se restan. `load_model` carga `modelo.pt`. |
| `evaluar.py` | Evalúa en dos etapas: `--split val` barre retornos pedidos y elige el mejor; `--split test` evalúa ese retorno **una sola vez**. |
| `reporte.py` | Junta las semillas y las líneas base en la tabla final y genera el gráfico de retorno pedido frente a obtenido. |

### Paso 1: validación (elige el retorno pedido)

```bash
python -m dt.evaluar --split val --run outputs/dt_netflix_random_seed0 outputs/dt_netflix_random_seed1 outputs/dt_netflix_random_seed2
```

- Por defecto barre los percentiles 10, 25, 50, 75, 90 y 99 de `retornos_train.json`, más dos valores por encima del máximo de train (máx + 5 y máx + 15). Con `--targets 60 70 80 90` se puede pasar otra lista.
- Evalúa las 4 condiciones (warm-up 0 y 5, grupo visible y oculto) sobre los usuarios de validación, con el catálogo restringido.
- **Criterio:** se elige el retorno con mayor `normalized` medio, como promedio simple de las 4 condiciones. Cada semilla de entrenamiento elige el suyo.
- Escribe `<run>/eval/val/`: `sesiones.csv`, `resumen*.csv` y `mejor_retorno.json`, con el retorno elegido y la tabla por condición.

### Paso 2: test (una sola vez)

```bash
python -m dt.evaluar --split test --run outputs/dt_netflix_random_seed0 outputs/dt_netflix_random_seed1 outputs/dt_netflix_random_seed2
```

- Si falta `mejor_retorno.json` se niega a correr: el retorno nunca se elige mirando test.
- Evalúa la política `dt` con el retorno elegido en las 4 condiciones y con las semillas de sesión 0, 1 y 2 (`--seeds`). El resultado va a `<run>/eval/test/`.
- Además barre todos los retornos pedidos en warm-up 0 y lo guarda en `<run>/eval/test/barrido/`. Ese barrido **sólo** se usa para el gráfico, no para elegir nada.

### Paso 3: líneas base con los mismos logs

```bash
python -m protocolo.evaluar --dataset netflix --output outputs/baselines_netflix                         # logs random
python -m protocolo.evaluar --dataset netflix --logs mixto --output outputs/baselines_netflix_mixto      # logs mixto
```

### Paso 4: tablas y gráfico

```bash
python -m dt.reporte \
    --runs outputs/dt_netflix_random_seed0 outputs/dt_netflix_random_seed1 outputs/dt_netflix_random_seed2 \
    --baselines outputs/baselines_netflix \
    --output outputs/reporte_netflix_random
```

Con `--iql` se agregan las filas de IQL; ver `iql/README.md`. `--iql` se puede repetir, una vez por configuración, por ejemplo la principal y la de γ = 0.

**Dos fuentes de variabilidad, separadas como pide la consigna:**
- **`±`:** desvío entre semillas de **entrenamiento**, o sea cuánto cambia el resultado al reentrenar.
- **`[±]`:** semiancho del **IC 95 % por usuario**. Se calcula con el mismo procedimiento que `protocolo.metricas.summarize`: primero se promedian las semillas de sesión de cada usuario y después se toman la media y 1,96 · desvío / √n entre usuarios. Para un modelo con varias semillas se informa el promedio de los semianchos.
- Las líneas base no se reentrenan, así que solo llevan `[±]`.

Salidas:

| Archivo | Contenido |
|---|---|
| `tabla.md` | una tabla por métrica: retorno normalizado (la principal), hit rate, NDCG@10 y precision@10. Las dos últimas miden el ranking del **primer** paso controlado, no la sesión. |
| `tabla.csv` | lo mismo en formato largo: `politica`, `clave`, `metrica`, `warmup`, `group_visible`, `media`, `desvio_semillas`, `ic95_usuario`, `n_semillas`, `n_usuarios`. `clave` es estable entre tipos de logs (`DT`, `IQL π [principal]`, …) y la usa `experimentos.comparar_logs`. |
| `tabla_por_grupo.md` / `.csv` | normalizado por grupo de usuarios (g0–g7), una tabla por condición. El protocolo pide reportar el agregado **y** cada grupo. El IC por grupo está en el `.csv`. |
| `retorno_pedido_vs_obtenido.png` / `.csv` | retorno obtenido frente a pedido, con la diagonal y el máximo de train. Tiene un panel agregado y uno por grupo, con una curva para grupo visible y otra para grupo oculto. **Incertidumbre:** la banda es el IC 95 % por usuario y las líneas finas son cada semilla de entrenamiento. El `.csv` incluye `desvio_semillas` e `ic95_usuario` por retorno pedido. |

**Controles del script:**
- Si se mezclan corridas de distintos datasets o logs, aborta. Las corridas y `--baselines` tienen que usar los **mismos** logs.
- Si una métrica no está en `sesiones.csv`, la tabla lo indica en vez de fallar. Los nombres que reconoce son `ndcg@10`, `ndcg_10`, `precision@10`, etc.

Para los logs `mixto`, repetir los pasos 1, 2 y 4 con las carpetas `dt_netflix_mixto_seed*` y `--baselines outputs/baselines_netflix_mixto`.

### Curvas de entrenamiento

```bash
python -m dt.curvas --runs outputs/dt_netflix_random_seed0 outputs/dt_netflix_random_seed1 outputs/dt_netflix_random_seed2 \
                    --output outputs/reporte_netflix_random
```

`curvas_dt.png` muestra la cross-entropy de train, la de validación con grupo visible y la de validación con grupo oculto. Incluye la referencia log(n_items) y marca la época del checkpoint guardado. Hay una línea por semilla, con todas las épocas y sin recortar ejes. Con `--nombre` se elige el nombre del PNG, por ejemplo para no pisar las curvas de dos configuraciones de IQL.

### Tiempos

`DTPolicy` hace una pasada del modelo por paso de sesión, y la interfaz no permite agrupar sesiones en un batch. Cada combinación de retorno, condición y semilla son 1.600 usuarios × 20 pasos. Para que no tarde horas:

- los barridos usan una sola semilla de sesión (`--seeds-barrido 0`);
- la evaluación final usa tres (`--seeds 0 1 2`).

Con GPU (`--device cuda`, que es el valor por defecto si hay una) es bastante más rápido.
