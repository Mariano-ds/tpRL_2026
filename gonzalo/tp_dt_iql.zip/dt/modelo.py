"""Decision Transformer mínimo: modelo, máscara de ítems vistos, pérdida y test de no fuga.

Decisiones de diseño (declararlas en el informe):

- Tokens intercalados R̂_t, s_t, a_t (3 por paso). a_t se predice desde la salida de s_t.
- Estado s_t = embedding del grupo (0..7, u 8 = "desconocido") + embedding del rating
  del paso anterior (0 = sin rating previo, 1..5). s_t nunca incluye r_t.
- R̂ se escala dividiendo por RTG_SCALE dentro del modelo, así entrenamiento y política
  le pasan el mismo valor crudo.
- La proyección de salida comparte pesos con el embedding de ítems.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

N_GROUPS = 8
UNKNOWN_GROUP = N_GROUPS          # índice del token "grupo desconocido"
NO_PREV_RATING = 0                # rating previo en t = 0
RTG_SCALE = 100.0


def prev_ratings(ratings: torch.Tensor) -> torch.Tensor:
    """(B, T) ratings -> (B, T) long con el rating del paso anterior (0 en t = 0).

    Los ratings se redondean a 1..5: en train son enteros; en el test de Goodreads son
    continuos y hay que llevarlos a un índice de embedding.
    """
    r = ratings.round().clamp(1, 5).long()
    prev = torch.full_like(r, NO_PREV_RATING)
    prev[:, 1:] = r[:, :-1]
    return prev


class DecisionTransformer(nn.Module):
    def __init__(self, n_items: int, horizon: int = 20, d_model: int = 128, n_layers: int = 3,
                 n_heads: int = 4, dropout: float = 0.1):
        super().__init__()
        self.n_items = n_items
        self.horizon = horizon

        self.rtg_emb = nn.Linear(1, d_model)
        self.group_emb = nn.Embedding(N_GROUPS + 1, d_model)
        self.prev_emb = nn.Embedding(6, d_model)
        self.item_emb = nn.Embedding(n_items, d_model)
        self.step_emb = nn.Embedding(horizon, d_model)
        self.type_emb = nn.Embedding(3, d_model)      # 0 = R̂, 1 = s, 2 = a

        self.ln_in = nn.LayerNorm(d_model)
        self.drop = nn.Dropout(dropout)
        layer = nn.TransformerEncoderLayer(d_model, n_heads, 4 * d_model, dropout,
                                           activation="gelu", batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(layer, n_layers, enable_nested_tensor=False)
        self.ln_out = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, n_items, bias=False)
        self.head.weight = self.item_emb.weight       # pesos compartidos

        # True = no puede ver. Triangular superior estricta sobre los 3T tokens.
        L = 3 * horizon
        self.register_buffer("causal_mask", torch.triu(torch.ones(L, L, dtype=torch.bool), 1),
                             persistent=False)
        self.apply(self._init)

    @staticmethod
    def _init(m: nn.Module) -> None:
        if isinstance(m, (nn.Linear, nn.Embedding)):
            nn.init.normal_(m.weight, std=0.02)
        if isinstance(m, nn.Linear) and m.bias is not None:
            nn.init.zeros_(m.bias)

    def forward(self, rtg: torch.Tensor, items: torch.Tensor, prev_rating: torch.Tensor,
                groups: torch.Tensor) -> torch.Tensor:
        """rtg (B, T) float crudo, items (B, T), prev_rating (B, T), groups (B,).

        Devuelve logits (B, T, n_items) de a_t, calculadas desde el token s_t.
        """
        B, T = items.shape
        step = self.step_emb(torch.arange(T, device=items.device))[None]      # (1, T, d)
        types = self.type_emb.weight                                            # (3, d)

        r_tok = self.rtg_emb((rtg / RTG_SCALE).unsqueeze(-1)) + step + types[0]
        s_tok = self.group_emb(groups)[:, None] + self.prev_emb(prev_rating) + step + types[1]
        a_tok = self.item_emb(items) + step + types[2]

        x = torch.stack([r_tok, s_tok, a_tok], dim=2).reshape(B, 3 * T, -1)   # R̂_0, s_0, a_0, R̂_1, ...
        x = self.drop(self.ln_in(x))
        h = self.encoder(x, mask=self.causal_mask[:3 * T, :3 * T])
        h = self.ln_out(h[:, 1::3])                                             # salidas de s_t
        return self.head(h)


def seen_before_mask(items: torch.Tensor, n_items: int) -> torch.Tensor:
    """(B, T, n_items): True si el ítem ya se mostró antes del paso t en el episodio."""
    oh = F.one_hot(items, n_items)
    return (oh.cumsum(1) - oh) > 0


def dt_loss(model: DecisionTransformer, batch: dict) -> torch.Tensor:
    logits = model(batch["rtg"], batch["items"], batch["prev"], batch["groups"])
    logits = logits.masked_fill(seen_before_mask(batch["items"], logits.shape[-1]), float("-inf"))
    return F.cross_entropy(logits.reshape(-1, logits.shape[-1]), batch["items"].reshape(-1))


@torch.no_grad()
def check_no_leak(model: DecisionTransformer, batch: dict, t: int = 7, atol: float = 1e-5) -> bool:
    """Cambiar a_t, todo lo posterior y el estado de los pasos > t no debe cambiar las logits de t."""
    was_training = model.training
    model.eval()
    base = model(batch["rtg"], batch["items"], batch["prev"], batch["groups"])[:, t]

    items2 = batch["items"].clone()
    items2[:, t:] = torch.randint(0, model.n_items, items2[:, t:].shape, device=items2.device)
    rtg2 = batch["rtg"].clone()
    rtg2[:, t + 1:] = torch.rand_like(rtg2[:, t + 1:]) * 100
    prev2 = batch["prev"].clone()
    prev2[:, t + 1:] = torch.randint(0, 6, prev2[:, t + 1:].shape, device=prev2.device)

    out = model(rtg2, items2, prev2, batch["groups"])[:, t]
    model.train(was_training)
    return torch.allclose(base, out, atol=atol)
