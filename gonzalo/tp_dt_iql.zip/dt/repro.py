"""Información de entorno para reproducibilidad: se guarda en config.json de cada corrida."""

from __future__ import annotations

import hashlib
import platform
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def _git(*args: str) -> str | None:
    try:
        r = subprocess.run(["git", *args], capture_output=True, text=True, timeout=10)
        return r.stdout.strip() if r.returncode == 0 else None
    except (OSError, subprocess.SubprocessError):
        return None


def _command() -> str:
    """Comando de la corrida, como se escribe con `python -m` desde 2026/tp."""
    script = Path(sys.argv[0])
    try:
        module = ".".join(script.resolve().relative_to(Path.cwd().resolve()).with_suffix("").parts)
        return " ".join(["python", "-m", module, *sys.argv[1:]])
    except ValueError:
        return " ".join(["python", *sys.argv])


def code_fingerprint(packages=("dt", "iql")) -> dict:
    """SHA-256 (12 caracteres) de los .py de cada paquete: identifica la versión del código
    aunque dt/ e iql/ no estén en el repositorio (p. ej. si vienen de un ZIP)."""
    out = {}
    for pkg in packages:
        files = sorted(Path(pkg).rglob("*.py"))
        if files:
            h = hashlib.sha256()
            for f in files:
                h.update(str(f).encode())
                h.update(f.read_bytes())
            out[pkg] = h.hexdigest()[:12]
    return out


def env_info() -> dict:
    import numpy
    import pandas
    import torch

    cuda = torch.cuda.is_available()
    return {
        "fecha": datetime.now().isoformat(timespec="seconds"),
        "comando": _command(),
        "python": platform.python_version(),
        "torch": torch.__version__,
        "numpy": numpy.__version__,
        "pandas": pandas.__version__,
        "cuda": torch.version.cuda if cuda else None,
        "gpu": torch.cuda.get_device_name(0) if cuda else None,
        "plataforma": platform.platform(),
        "git_commit": _git("rev-parse", "HEAD"),
        "git_cambios_sin_commit": bool(_git("status", "--porcelain", "--untracked-files=no")),
        "codigo_sha256": code_fingerprint(),
    }
