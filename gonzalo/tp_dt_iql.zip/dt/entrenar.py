"""Entrena un Decision Transformer con los episodios del protocolo.

Uso, desde 2026/tp:

    python -m dt.entrenar --dataset netflix --logs random --seed 0
    python -m dt.entrenar --dataset netflix --logs mixto  --seed 1 --epochs 30

Salidas en outputs/dt_{dataset}_{logs}_seed{seed}/:
    modelo.pt          mejor checkpoint (menor cross-entropy en validación) + kwargs del modelo
    config.json        argumentos de la corrida
    curvas.csv         pérdidas por época
    retornos_train.json distribución de retornos de los episodios de train (para el barrido de R̂)

No evalúa en test ni elige el retorno pedido: eso va en el script de evaluación.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset

from protocolo.datos import load_train, make_episodes, num_items, split_by_user
from protocolo.logs import logged_episodes, logs_cache

from dt.modelo import UNKNOWN_GROUP, DecisionTransformer, check_no_leak, dt_loss, prev_ratings

HORIZON = 20


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--dataset", default="netflix", choices=["netflix", "goodreads"])
    p.add_argument("--logs", default="random", choices=["random", "mixto", "experto"])
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--output", type=Path, default=None)
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--weight-decay", type=float, default=0.1)
    p.add_argument("--d-model", type=int, default=128)
    p.add_argument("--n-layers", type=int, default=3)
    p.add_argument("--n-heads", type=int, default=4)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--p-hide", type=float, default=0.3,
                   help="fracción de episodios de train con el grupo reemplazado por 'desconocido'")
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    return p.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def load_episodes(dataset: str, logs: str, n_items: int):
    """Episodios de train y validación de la misma fuente de logs.

    Las semillas de generación de logs (0 y 1) son fijas: todas las semillas de
    entrenamiento ven los mismos datos y sólo cambia la inicialización y el orden.
    """
    train, val = split_by_user(load_train(dataset))
    if logs == "random":
        return make_episodes(train, length=HORIZON), make_episodes(val, length=HORIZON)
    tr = logged_episodes(logs, train, train, n_items, HORIZON, seed=0, cache=logs_cache(dataset, logs, "train"))
    va = logged_episodes(logs, val, train, n_items, HORIZON, seed=1, cache=logs_cache(dataset, logs, "val"))
    return tr.episodes, va.episodes


def _tensor(x, dtype) -> torch.Tensor:
    # ascontiguousarray: returns_to_go() puede devolver una vista invertida (strides negativos),
    # que torch no acepta.
    return torch.as_tensor(np.ascontiguousarray(x), dtype=dtype)


def to_tensors(ep) -> TensorDataset:
    items = _tensor(ep.items, torch.long)
    ratings = _tensor(ep.ratings, torch.float32)
    groups = _tensor(ep.groups, torch.long)
    rtg = _tensor(ep.returns_to_go(), torch.float32)
    return TensorDataset(rtg, items, prev_ratings(ratings), groups)


def as_batch(tensors, device, p_hide: float = 0.0, hide_all: bool = False) -> dict:
    rtg, items, prev, groups = (x.to(device) for x in tensors)
    if hide_all:
        groups = torch.full_like(groups, UNKNOWN_GROUP)
    elif p_hide > 0:
        groups = groups.masked_fill(torch.rand(groups.shape, device=device) < p_hide, UNKNOWN_GROUP)
    return {"rtg": rtg, "items": items, "prev": prev, "groups": groups}


@torch.no_grad()
def eval_loss(model, loader, device, hide_all: bool = False) -> float:
    model.eval()
    total, n = 0.0, 0
    for tensors in loader:
        b = as_batch(tensors, device, hide_all=hide_all)
        total += dt_loss(model, b).item() * b["items"].shape[0]
        n += b["items"].shape[0]
    model.train()
    return total / n


def make_optimizer(model, lr: float, weight_decay: float) -> torch.optim.Optimizer:
    # Weight decay sólo en matrices; no en sesgos ni LayerNorm.
    decay = [p for p in model.parameters() if p.dim() >= 2]
    no_decay = [p for p in model.parameters() if p.dim() < 2]
    return torch.optim.AdamW([{"params": decay, "weight_decay": weight_decay},
                              {"params": no_decay, "weight_decay": 0.0}], lr=lr)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    out = args.output or Path(f"outputs/dt_{args.dataset}_{args.logs}_seed{args.seed}")
    out.mkdir(parents=True, exist_ok=True)
    device = torch.device(args.device)

    n_items = num_items(args.dataset)
    train_ep, val_ep = load_episodes(args.dataset, args.logs, n_items)
    train_ds, val_ds = to_tensors(train_ep), to_tensors(val_ep)
    g = torch.Generator().manual_seed(args.seed)
    train_dl = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, drop_last=True, generator=g)
    val_dl = DataLoader(val_ds, batch_size=1024)
    print(f"{args.dataset} / logs {args.logs}: {len(train_ds)} episodios de train, {len(val_ds)} de val")

    # Distribución de retornos de train: soporte para el barrido de retorno pedido.
    returns = train_ds.tensors[0][:, 0].numpy()
    pct = [10, 25, 50, 75, 90, 99]
    ret_info = {"media": float(returns.mean()), "min": float(returns.min()), "max": float(returns.max()),
                "percentiles": {str(q): float(np.percentile(returns, q)) for q in pct}}
    (out / "retornos_train.json").write_text(json.dumps(ret_info, indent=2))
    print(f"retorno de train: media {ret_info['media']:.1f}, máx {ret_info['max']:.0f}")

    model_kwargs = dict(n_items=n_items, horizon=HORIZON, d_model=args.d_model, n_layers=args.n_layers,
                        n_heads=args.n_heads, dropout=args.dropout)
    model = DecisionTransformer(**model_kwargs).to(device)

    # Test de no fuga antes de entrenar: si falla, nada de lo que sigue es válido.
    probe = as_batch(next(iter(val_dl)), device)
    probe = {k: v[:64] for k, v in probe.items()}
    if not check_no_leak(model, probe):
        raise SystemExit("FALLA el test de no fuga: las logits del paso t dependen de a_t o del futuro.")
    print("test de no fuga: OK")

    opt = make_optimizer(model, args.lr, args.weight_decay)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=args.lr, total_steps=args.epochs * len(train_dl),
                                                pct_start=0.1)

    config = {**{k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
              "output": str(out), "model": model_kwargs, "estado": "grupo (8 = desconocido) + rating previo",
              "checkpoint": "menor cross-entropy en val, grupo visible"}
    (out / "config.json").write_text(json.dumps(config, indent=2))

    uniform = math.log(n_items)
    print(f"referencia uniforme log(n_items) = {uniform:.3f}")
    curves, best = [], float("inf")
    for epoch in range(1, args.epochs + 1):
        t0, total, n = time.time(), 0.0, 0
        for tensors in train_dl:
            b = as_batch(tensors, device, p_hide=args.p_hide)
            loss = dt_loss(model, b)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            sched.step()
            total += loss.item()
            n += 1

        row = {"epoch": epoch, "train": total / n,
               "val_visible": eval_loss(model, val_dl, device),
               "val_oculto": eval_loss(model, val_dl, device, hide_all=True),
               "uniforme": uniform, "lr": sched.get_last_lr()[0]}
        curves.append(row)
        mark = ""
        if row["val_visible"] < best:
            best = row["val_visible"]
            torch.save({"state_dict": model.state_dict(), "model_kwargs": model_kwargs, "epoch": epoch,
                        "val_loss": best}, out / "modelo.pt")
            mark = "  *"
        print(f"época {epoch:3d}  train {row['train']:.4f}  val {row['val_visible']:.4f}  "
              f"val oculto {row['val_oculto']:.4f}  ({time.time() - t0:.0f}s){mark}")

        with open(out / "curvas.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(row))
            w.writeheader()
            w.writerows(curves)

    print(f"mejor val {best:.4f} (uniforme {uniform:.3f}); checkpoint en {out / 'modelo.pt'}")


if __name__ == "__main__":
    main()
