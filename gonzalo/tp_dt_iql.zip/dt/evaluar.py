"""Evalúa un DT entrenado con el protocolo común.

Dos etapas, siempre en este orden:

  1. Validación: barre retornos pedidos, elige el mejor y lo guarda.
       python -m dt.evaluar --run outputs/dt_netflix_random_seed0 --split val

  2. Test (una sola vez): evalúa el retorno elegido en validación en las 4 condiciones,
     más el barrido de retornos pedidos (warm-up 0) para el gráfico pedido vs obtenido.
       python -m dt.evaluar --run outputs/dt_netflix_random_seed0 --split test

--run acepta varias carpetas (una por semilla de entrenamiento). Cada una elige su
propio retorno en validación. Dataset y logs se leen del config.json de la corrida.

Salidas en <run>/eval/{val,test}/: sesiones.csv, resumen.csv, resumen_por_grupo.csv
(de protocolo.evaluar.write_reports). En val, además, mejor_retorno.json.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import torch

from protocolo.datos import load_test, load_train, num_items, split_by_user
from protocolo.evaluar import evaluate_grid, write_reports

from dt.politica import DTPolicy, load_model

HORIZON = 20
WARMUPS = (0, 5)
VISIBILITY = (True, False)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--run", type=Path, nargs="+", required=True, help="carpetas de entrenamiento")
    p.add_argument("--split", choices=["val", "test"], required=True)
    p.add_argument("--targets", type=float, nargs="*", default=None,
                   help="retornos pedidos a barrer (default: percentiles de train + 2 sobre el máximo)")
    p.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2],
                   help="semillas de sesión para la evaluación final en test")
    p.add_argument("--seeds-barrido", type=int, nargs="+", default=[0],
                   help="semillas de sesión para los barridos (más barato)")
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    return p.parse_args()


def policy_name(target: float) -> str:
    return f"dt_R{target:g}"


def default_targets(run: Path) -> list[float]:
    info = json.loads((run / "retornos_train.json").read_text())
    targets = {round(v) for v in info["percentiles"].values()}
    mx = round(info["max"])
    targets |= {mx + 5, mx + 15}                      # fuera del soporte de train
    return sorted(float(t) for t in targets)


def factories_for(model, targets, device):
    # Las fábricas crean una política nueva por condición; el modelo se comparte (sólo lectura).
    return {policy_name(t): (lambda t=t: DTPolicy(model, t, device)) for t in targets}


def choose_target(df: pd.DataFrame) -> tuple[float, pd.DataFrame]:
    """Retorno pedido con mayor normalizado medio, promediando las 4 condiciones por igual."""
    table = (df.groupby(["policy", "warmup", "group_visible"])["normalized"].mean()
               .unstack(["warmup", "group_visible"]))
    table.columns = [f"warmup{w}_{'visible' if v else 'oculto'}" for w, v in table.columns]
    table["media"] = table.mean(axis=1)
    best_policy = table["media"].idxmax()
    best = float(best_policy.removeprefix("dt_R"))
    return best, table


def run_val(run: Path, users, n_items, targets, args) -> None:
    out = run / "eval" / "val"
    model = load_model(run, args.device)
    print(f"[val] {run.name}: barriendo {len(targets)} retornos pedidos: {targets}")
    df = evaluate_grid(factories_for(model, targets, args.device), users, n_items, horizon=HORIZON,
                       warmups=WARMUPS, group_visibility=VISIBILITY, seeds=tuple(args.seeds_barrido))
    write_reports(df, out)
    best, table = choose_target(df)
    (out / "mejor_retorno.json").write_text(json.dumps({
        "target": best,
        "criterio": "mayor normalizado medio en val, promedio simple de las 4 condiciones",
        "seeds_sesion": args.seeds_barrido,
        "tabla": table.round(4).to_dict(orient="index"),
    }, indent=2))
    print(table.round(3).to_string())
    print(f"[val] {run.name}: retorno elegido = {best:g}  ->  {out / 'mejor_retorno.json'}")


def run_test(run: Path, users, n_items, targets, args) -> None:
    chosen_file = run / "eval" / "val" / "mejor_retorno.json"
    if not chosen_file.exists():
        raise SystemExit(f"Falta {chosen_file}: correr primero --split val. El retorno no se elige en test.")
    best = json.loads(chosen_file.read_text())["target"]
    out = run / "eval" / "test"
    model = load_model(run, args.device)

    print(f"[test] {run.name}: retorno elegido en val = {best:g}, 4 condiciones, semillas {args.seeds}")
    final = evaluate_grid({"dt": lambda: DTPolicy(model, best, args.device)}, users, n_items,
                          horizon=HORIZON, warmups=WARMUPS, group_visibility=VISIBILITY,
                          seeds=tuple(args.seeds))

    print(f"[test] {run.name}: barrido de retornos pedidos (warm-up 0) para el gráfico")
    sweep = evaluate_grid(factories_for(model, targets, args.device), users, n_items, horizon=HORIZON,
                          warmups=(0,), group_visibility=VISIBILITY, seeds=tuple(args.seeds_barrido))

    write_reports(final, out)                     # tabla final: sólo el retorno elegido
    write_reports(sweep, out / "barrido")         # sólo para el gráfico pedido vs obtenido
    (out / "retorno_usado.json").write_text(json.dumps({"target": best, "elegido_en": str(chosen_file)}, indent=2))
    summary = final.groupby(["warmup", "group_visible"])["normalized"].mean()
    print(summary.round(3).to_string())


def main() -> None:
    args = parse_args()
    for run in args.run:
        cfg = json.loads((run / "config.json").read_text())
        dataset = cfg["dataset"]
        n_items = num_items(dataset)
        if args.split == "val":
            _, users = split_by_user(load_train(dataset))
        else:
            users = load_test(dataset)
        targets = args.targets or default_targets(run)
        (run_val if args.split == "val" else run_test)(run, users, n_items, targets, args)


if __name__ == "__main__":
    main()
