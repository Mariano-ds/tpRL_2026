"""Arma la tabla final y el gráfico de return conditioning a partir de las evaluaciones en test.

    python -m dt.reporte \
        --runs outputs/dt_netflix_random_seed0 outputs/dt_netflix_random_seed1 outputs/dt_netflix_random_seed2 \
        --baselines outputs/baselines_netflix \
        --output outputs/reporte_netflix_random

Entradas:
  --runs       carpetas de entrenamiento ya evaluadas con `dt.evaluar --split test`
  --baselines  carpeta de `python -m protocolo.evaluar` con los MISMOS logs que los runs

Salidas en --output:
  tabla.csv, tabla.md     normalizado medio por política y condición; para el DT,
                          media ± desvío entre semillas de entrenamiento
  retorno_pedido_vs_obtenido.png   barrido en test, warm-up 0, agregado y por grupo
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

CONDITIONS = [(0, True, "Visible"), (0, False, "Oculto"),
              (5, True, "Warm-up 5, visible"), (5, False, "Warm-up 5, oculto")]
BASELINE_ORDER = ["random", "popularity", "item_mean", "group_mean", "group_posterior"]
COLOR_VISIBLE, COLOR_HIDDEN = "#2a78d6", "#eb6834"   # slots 1 y 2 de la paleta categórica
INK, MUTED, GRID = "#1f1f1e", "#6b6a64", "#e4e3dd"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--runs", type=Path, nargs="+", required=True)
    p.add_argument("--baselines", type=Path, default=None)
    p.add_argument("--output", type=Path, required=True)
    return p.parse_args()


def by_condition(df: pd.DataFrame) -> pd.Series:
    return df.groupby(["policy", "warmup", "group_visible"])["normalized"].mean()


def group_column(df: pd.DataFrame) -> str | None:
    return next((c for c in ("group", "grupo") if c in df.columns), None)


def check_same_logs(runs: list[Path]) -> dict:
    cfgs = [json.loads((r / "config.json").read_text()) for r in runs]
    keys = {(c["dataset"], c["logs"]) for c in cfgs}
    if len(keys) > 1:
        raise SystemExit(f"Los runs mezclan datasets o logs distintos: {keys}")
    return cfgs[0]


def build_table(runs: list[Path], baselines: Path | None) -> pd.DataFrame:
    rows = {}
    if baselines is not None:
        base = by_condition(pd.read_csv(baselines / "sesiones.csv"))
        names = [p for p in BASELINE_ORDER if p in base.index.get_level_values(0)]
        names += sorted(set(base.index.get_level_values(0)) - set(names))   # p. ej. el sistema anterior
        for name in names:
            rows[name] = {label: _fmt(base.get((name, w, v))) for w, v, label in CONDITIONS}

    per_seed = pd.concat([by_condition(pd.read_csv(r / "eval" / "test" / "sesiones.csv")).rename(r.name)
                          for r in runs], axis=1)
    targets = [json.loads((r / "eval" / "test" / "retorno_usado.json").read_text())["target"] for r in runs]
    dt_row = {}
    for w, v, label in CONDITIONS:
        vals = per_seed.loc[("dt", w, v)] if ("dt", w, v) in per_seed.index else pd.Series(dtype=float)
        dt_row[label] = (f"{vals.mean():.3f} ± {vals.std(ddof=1):.3f}" if len(vals) > 1
                         else _fmt(vals.mean() if len(vals) else None))
    rows[f"DT (R̂ elegido en val: {', '.join(f'{t:g}' for t in targets)})"] = dt_row
    return pd.DataFrame.from_dict(rows, orient="index")


def _fmt(x) -> str:
    return "" if x is None or (isinstance(x, float) and np.isnan(x)) else f"{x:.3f}"


def sweep_curves(runs: list[Path]) -> tuple[pd.DataFrame, str | None]:
    """Retorno obtenido medio por retorno pedido, visibilidad y grupo; promediado entre semillas."""
    frames = []
    for r in runs:
        df = pd.read_csv(r / "eval" / "test" / "barrido" / "sesiones.csv")
        df = df[df["warmup"] == 0].copy()
        df["target"] = df["policy"].str.removeprefix("dt_R").astype(float)
        df["run"] = r.name
        frames.append(df)
    df = pd.concat(frames)
    gcol = group_column(df)
    keys = ["target", "group_visible"] + ([gcol] if gcol else [])
    per_run = df.groupby(["run"] + keys)["return"].mean()
    curves = per_run.groupby(level=keys).mean().reset_index()
    agg = df.groupby(["run", "target", "group_visible"])["return"].mean().groupby(
        level=["target", "group_visible"]).mean().reset_index()
    agg[gcol or "group"] = "todos"
    return pd.concat([agg, curves]) if gcol else agg, gcol or "group"


def plot_sweep(curves: pd.DataFrame, gcol: str, train_max: float, path: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    panels = ["todos"] + sorted(g for g in curves[gcol].unique() if g != "todos")
    ncols = 3
    nrows = int(np.ceil(len(panels) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(4 * ncols, 3.4 * nrows), sharex=True, sharey=True,
                             squeeze=False)
    lo = min(curves["target"].min(), curves["return"].min()) - 3
    hi = max(curves["target"].max(), curves["return"].max()) + 3

    for ax, panel in zip(axes.flat, panels):
        sub = curves[curves[gcol] == panel]
        ax.plot([lo, hi], [lo, hi], color=MUTED, lw=1, ls="--", zorder=1)
        ax.axvline(train_max, color=MUTED, lw=1, ls=":", zorder=1)
        for visible, color, label in ((True, COLOR_VISIBLE, "grupo visible"), (False, COLOR_HIDDEN, "grupo oculto")):
            s = sub[sub["group_visible"] == visible].sort_values("target")
            ax.plot(s["target"], s["return"], color=color, lw=2, marker="o", ms=4, label=label, zorder=3)
        ax.set_title("Agregado" if panel == "todos" else f"Grupo {panel}", color=INK, fontsize=10, loc="left")
        ax.set_xlim(lo, hi)
        ax.set_ylim(lo, hi)
        ax.grid(color=GRID, lw=0.6)
        for side in ("top", "right"):
            ax.spines[side].set_visible(False)
        for side in ("left", "bottom"):
            ax.spines[side].set_color(GRID)
        ax.tick_params(colors=MUTED, labelsize=8)
    for ax in list(axes.flat)[len(panels):]:
        ax.set_visible(False)

    first = axes.flat[0]
    first.text(train_max, hi, " máx. train", color=MUTED, fontsize=8, va="top")
    first.text(hi, hi, "diagonal ", color=MUTED, fontsize=8, ha="right", va="bottom")
    handles, labels = first.get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper right", frameon=False, fontsize=9)
    fig.supxlabel("Retorno pedido (20 pasos)", color=INK, fontsize=10)
    fig.supylabel("Retorno obtenido en test (media)", color=INK, fontsize=10)
    fig.suptitle("DT: retorno pedido frente a obtenido, warm-up 0", color=INK, fontsize=12, x=0.01, ha="left")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    fig.savefig(path, dpi=150)
    plt.close(fig)


def main() -> None:
    args = parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    cfg = check_same_logs(args.runs)
    if args.baselines is None:
        print("Aviso: sin --baselines, la tabla sólo tiene el DT.")

    table = build_table(args.runs, args.baselines)
    table.to_csv(args.output / "tabla.csv")
    md = [f"Dataset `{cfg['dataset']}`, logs `{cfg['logs']}`, test, `normalized` medio. "
          f"DT: media ± desvío entre {len(args.runs)} semillas de entrenamiento.", "",
          "| Política | " + " | ".join(table.columns) + " |",
          "|---|" + "---:|" * len(table.columns)]
    md += [f"| {name} | " + " | ".join(row) + " |" for name, row in table.iterrows()]
    (args.output / "tabla.md").write_text("\n".join(md) + "\n")
    print("\n".join(md))

    train_max = max(json.loads((r / "retornos_train.json").read_text())["max"] for r in args.runs)
    curves, gcol = sweep_curves(args.runs)
    curves.to_csv(args.output / "retorno_pedido_vs_obtenido.csv", index=False)
    plot_sweep(curves, gcol, train_max, args.output / "retorno_pedido_vs_obtenido.png")
    print(f"\ntabla y gráfico en {args.output}")


if __name__ == "__main__":
    main()
