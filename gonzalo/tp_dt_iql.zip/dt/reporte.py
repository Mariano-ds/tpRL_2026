"""Tabla final (líneas base, DT e IQL) con métricas principales y secundarias, resultados por
grupo y gráfico de return conditioning del DT.

    python -m dt.reporte \
        --runs outputs/dt_netflix_random_seed0 outputs/dt_netflix_random_seed1 outputs/dt_netflix_random_seed2 \
        --iql  outputs/iql_netflix_random_g0.9_t0.7_b3_seed0 outputs/iql_netflix_random_g0.9_t0.7_b3_seed1 \
               outputs/iql_netflix_random_g0.9_t0.7_b3_seed2 \
        --iql  outputs/iql_netflix_random_g0_t0.9_b3_seed0 outputs/iql_netflix_random_g0_t0.9_b3_seed1 \
               outputs/iql_netflix_random_g0_t0.9_b3_seed2 \
        --baselines outputs/baselines_netflix \
        --output outputs/reporte_netflix_random

Entradas (todas con los MISMOS dataset y logs):
  --runs       corridas del DT evaluadas con `dt.evaluar --split test`
  --iql        corridas de UNA configuración de IQL evaluadas con `iql.evaluar --split test`;
               se puede repetir (p. ej. la principal y la de γ = 0)
  --baselines  carpeta de `python -m protocolo.evaluar`

Dos fuentes de variabilidad, reportadas por separado:
  - desvío entre semillas de ENTRENAMIENTO (±): cuánto cambia el resultado al reentrenar;
  - IC 95 % por USUARIO ([±]): semiancho del intervalo entre usuarios. Mismo procedimiento que
    protocolo.metricas.summarize: primero se promedian las semillas de sesión de cada usuario,
    después media y 1,96 · desvío / √n entre usuarios. Para modelos con varias semillas de
    entrenamiento se informa el promedio de los semianchos.

Salidas en --output:
  tabla.md                 una tabla por métrica (normalizado, hit rate, NDCG@10, precision@10)
  tabla.csv                lo mismo en formato largo (media, desvío entre semillas, IC, n)
  tabla_por_grupo.md/.csv  normalizado por grupo de usuarios, una tabla por condición
  retorno_pedido_vs_obtenido.png/.csv   barrido del DT en test, warm-up 0, agregado y por grupo
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

CONDITIONS = [(0, True, "Visible"), (0, False, "Oculto"),
              (5, True, "Warm-up 5, visible"), (5, False, "Warm-up 5, oculto")]
COND_KEYS = ["warmup", "group_visible"]
BASELINE_ORDER = ["random", "popularity", "item_mean", "group_mean", "group_posterior"]
# (clave, título, nombres posibles de la columna en sesiones.csv)
METRICS = [("normalized", "Retorno normalizado (métrica principal)", ("normalized",)),
           ("hit_rate", "Hit rate (rating ≥ 4)", ("hit_rate",)),
           ("ndcg@10", "NDCG@10 (primer paso controlado)", ("ndcg@10", "ndcg_10", "ndcg10", "ndcg")),
           ("precision@10", "Precision@10 (primer paso controlado)",
            ("precision@10", "precision_10", "precision10", "precision"))]
USER_COLUMNS = ("user_id", "user", "usuario")
COLOR_VISIBLE, COLOR_HIDDEN = "#2a78d6", "#eb6834"   # slots 1 y 2 de la paleta categórica
INK, MUTED, GRID = "#1f1f1e", "#6b6a64", "#e4e3dd"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--runs", type=Path, nargs="*", default=[], help="corridas del DT")
    p.add_argument("--iql", type=Path, nargs="+", action="append", default=[],
                   help="corridas de una configuración de IQL (repetible)")
    p.add_argument("--baselines", type=Path, default=None)
    p.add_argument("--output", type=Path, required=True)
    return p.parse_args()


def group_column(df: pd.DataFrame) -> str | None:
    return next((c for c in ("group", "grupo") if c in df.columns), None)


def find_column(df: pd.DataFrame, candidates) -> str | None:
    return next((c for c in candidates if c in df.columns), None)


def read_config(run: Path) -> dict:
    return json.loads((run / "config.json").read_text())


def check_same_logs(runs: list[Path]) -> dict:
    cfgs = [read_config(r) for r in runs]
    keys = {(c["dataset"], c["logs"]) for c in cfgs}
    if len(keys) > 1:
        raise SystemExit(f"Las corridas mezclan datasets o logs distintos: {keys}")
    return cfgs[0]


def test_sessions(run: Path) -> pd.DataFrame:
    return pd.read_csv(run / "eval" / "test" / "sesiones.csv")


# ------------------------------------------------------------------------------- entradas

def iql_variant(run: Path) -> str:
    f = run / "eval" / "test" / "seleccion_usada.json"
    return json.loads(f.read_text()).get("variante", "principal") if f.exists() else "principal"


def collect_entries(args) -> list[tuple[str, list[pd.DataFrame], str, str]]:
    """(nombre en la tabla, sesiones de cada semilla de entrenamiento, policy en sesiones.csv, clave).

    La clave es estable entre tipos de logs (no incluye hiperparámetros ni el retorno elegido):
    sirve para comparar el reporte de `random` con el de `mixto`.
    """
    entries = []
    if args.baselines is not None:
        base = pd.read_csv(args.baselines / "sesiones.csv")
        present = list(base["policy"].unique())
        names = [p for p in BASELINE_ORDER if p in present] + sorted(set(present) - set(BASELINE_ORDER))
        entries += [(name, [base], name, name) for name in names]      # p. ej. el sistema anterior
    if args.runs:
        targets = [json.loads((r / "eval" / "test" / "retorno_usado.json").read_text())["target"] for r in args.runs]
        entries.append((f"DT (R̂ elegido en val: {', '.join(f'{t:g}' for t in targets)})",
                        [test_sessions(r) for r in args.runs], "dt", "DT"))
    for group in args.iql:
        cfgs = [read_config(r) for r in group]
        hps = {(c["gamma"], c["tau"], c["beta"], c["reward"]) for c in cfgs}
        if len(hps) > 1:
            raise SystemExit(f"Un mismo --iql mezcla configuraciones distintas: {hps}. Usar un --iql por configuración.")
        g, t, b, _ = hps.pop()
        hp = f"γ={g:g}, τ={t:g}, β={b:g}"
        dfs = [test_sessions(r) for r in group]
        var = iql_variant(group[0])
        entries.append((f"IQL π ({hp})", dfs, "iql_pi", f"IQL π [{var}]"))
        entries.append((f"IQL, máximo de Q ({hp})", dfs, "iql_q", f"IQL, máximo de Q [{var}]"))
    return entries


# ------------------------------------------------------------------------------- estadísticos

def entry_stats(dfs: list[pd.DataFrame], policy: str, metric_cands, by: list[str]) -> pd.DataFrame | None:
    """Media, desvío entre semillas de entrenamiento e IC 95 % por usuario, agrupando por `by`."""
    per_run = []
    for df in dfs:
        d = df[df["policy"] == policy]
        col = find_column(d, metric_cands)
        if d.empty or col is None:
            continue
        ucol = find_column(d, USER_COLUMNS)
        # 1) promedio de las semillas de sesión de cada usuario (si no hay columna de usuario, cada sesión es una unidad)
        u = d.groupby(by + [ucol])[col].mean() if ucol else d.set_index(by)[col]
        g = u.groupby(level=list(range(len(by))))
        n = g.count()
        per_run.append(pd.DataFrame({"media": g.mean(), "ic95": 1.96 * g.std(ddof=1) / np.sqrt(n), "n": n}))
    if not per_run:
        return None
    cat = pd.concat(per_run, keys=range(len(per_run)), names=["semilla"])
    levels = list(range(1, len(by) + 1))
    res = cat.groupby(level=levels).agg(media=("media", "mean"),
                                        desvio_semillas=("media", lambda s: s.std(ddof=1) if len(s) > 1 else np.nan),
                                        ic95_usuario=("ic95", "mean"), n_usuarios=("n", "mean"))
    res.index.names = by
    res["n_semillas"] = len(per_run)
    return res


def long_table(entries, metrics, by: list[str]) -> pd.DataFrame:
    rows = []
    for name, dfs, policy, clave in entries:
        for key, _, cands in metrics:
            st = entry_stats(dfs, policy, cands, by)
            if st is not None:
                rows.append(st.reset_index().assign(politica=name, clave=clave, metrica=key))
    if not rows:
        return pd.DataFrame()
    out = pd.concat(rows, ignore_index=True)
    return out[["politica", "clave", "metrica", *by, "media", "desvio_semillas", "ic95_usuario", "n_semillas", "n_usuarios"]]


def cell(r: pd.Series | None, with_ic: bool = True) -> str:
    if r is None or pd.isna(r["media"]):
        return ""
    s = f"{r['media']:.3f}"
    if r["n_semillas"] > 1 and not pd.isna(r["desvio_semillas"]):
        s += f" ± {r['desvio_semillas']:.3f}"
    if with_ic and not pd.isna(r["ic95_usuario"]):
        s += f" [±{r['ic95_usuario']:.3f}]"
    return s


def md_table(header: list[str], rows: list[list[str]]) -> list[str]:
    return (["| " + " | ".join(header) + " |", "|---|" + "---:|" * (len(header) - 1)]
            + ["| " + " | ".join(r) + " |" for r in rows])


def lookup(tab: pd.DataFrame, **kv) -> pd.Series | None:
    m = np.ones(len(tab), dtype=bool)
    for k, v in kv.items():
        m &= (tab[k] == v).to_numpy()
    return tab[m].iloc[0] if m.any() else None


def write_main_table(tab: pd.DataFrame, entries, cfg: dict, out: Path) -> None:
    tab.to_csv(out / "tabla.csv", index=False)
    names = [e[0] for e in entries]
    md = [f"# Resultados en test: dataset `{cfg['dataset']}`, logs `{cfg['logs']}`", "",
          "Notación: `media ± desvío entre semillas de entrenamiento [±semiancho del IC 95 % por usuario]`. "
          "Las líneas base no se reentrenan: sólo llevan el IC. NDCG@10 y precision@10 miden el ranking del "
          "primer paso controlado, no la sesión.", ""]
    for key, title, _ in METRICS:
        sub = tab[tab["metrica"] == key]
        if sub.empty:
            md += [f"## {title}", "", "_No está en sesiones.csv._", ""]
            continue
        rows = [[n] + [cell(lookup(sub, politica=n, warmup=w, group_visible=v)) for w, v, _ in CONDITIONS]
                for n in names if (sub["politica"] == n).any()]
        md += [f"## {title}", "", *md_table(["Política"] + [c[2] for c in CONDITIONS], rows), ""]
    (out / "tabla.md").write_text("\n".join(md))
    print("\n".join(md))


def write_group_table(entries, gcol: str, cfg: dict, out: Path) -> None:
    tab = long_table(entries, METRICS[:1], COND_KEYS + [gcol])
    tab.to_csv(out / "tabla_por_grupo.csv", index=False)
    groups = sorted(tab[gcol].unique())
    names = [e[0] for e in entries]
    md = [f"# Retorno normalizado por grupo, test: dataset `{cfg['dataset']}`, logs `{cfg['logs']}`", "",
          "Notación: `media ± desvío entre semillas de entrenamiento`. Los IC por usuario están en "
          "`tabla_por_grupo.csv` (cada grupo tiene ~1/8 de los usuarios).", ""]
    for w, v, label in CONDITIONS:
        rows = [[n] + [cell(lookup(tab, politica=n, warmup=w, group_visible=v, **{gcol: g}), with_ic=False)
                       for g in groups]
                for n in names if (tab["politica"] == n).any()]
        md += [f"## {label}", "", *md_table(["Política"] + [f"g{g}" for g in groups], rows), ""]
    (out / "tabla_por_grupo.md").write_text("\n".join(md))


# ------------------------------------------------------------------------------- return conditioning (DT)

def sweep_curves(runs: list[Path]) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Retorno obtenido por retorno pedido, visibilidad y panel (agregado y cada grupo).

    Para cada semilla de entrenamiento: promedio de las semillas de sesión de cada usuario, y
    después media e IC 95 % entre usuarios. Entre semillas: media de las medias, desvío de las
    medias y promedio de los semianchos. Devuelve (curvas, valores por semilla).
    """
    frames = []
    for r in runs:
        df = pd.read_csv(r / "eval" / "test" / "barrido" / "sesiones.csv")
        df = df[df["warmup"] == 0].copy()
        df["target"] = df["policy"].str.removeprefix("dt_R").astype(float)
        df["run"] = r.name
        frames.append(df)
    df = pd.concat(frames, ignore_index=True)
    gcol = group_column(df)
    ucol = find_column(df, USER_COLUMNS)

    def stats(keys):
        u = df.groupby(["run"] + keys + ([ucol] if ucol else []))["return"].mean() if ucol \
            else df.set_index(["run"] + keys)["return"]
        g = u.groupby(level=list(range(len(keys) + 1)))
        per_run = pd.DataFrame({"return": g.mean(), "ic": 1.96 * g.std(ddof=1) / np.sqrt(g.count())})
        agg = per_run.groupby(level=list(range(1, len(keys) + 1))).agg(
            **{"return": ("return", "mean"),
               "desvio_semillas": ("return", lambda x: x.std(ddof=1) if len(x) > 1 else np.nan),
               "ic95_usuario": ("ic", "mean")})
        agg["n_semillas"] = len(runs)
        return agg.reset_index(), per_run["return"].reset_index()

    curves, per_run = stats(["target", "group_visible"])
    curves["panel"], per_run["panel"] = "todos", "todos"
    if gcol:
        c2, p2 = stats(["target", "group_visible", gcol])
        curves = pd.concat([curves, c2.rename(columns={gcol: "panel"})], ignore_index=True)
        per_run = pd.concat([per_run, p2.rename(columns={gcol: "panel"})], ignore_index=True)
    return curves, per_run


def plot_sweep(curves: pd.DataFrame, per_run: pd.DataFrame, train_max: float, path: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    panels = ["todos"] + sorted((g for g in curves["panel"].unique() if g != "todos"), key=str)
    ncols = 3
    nrows = int(np.ceil(len(panels) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(4 * ncols, 3.4 * nrows), sharex=True, sharey=True,
                             squeeze=False)
    band = curves["ic95_usuario"].fillna(0)
    lo = min(curves["target"].min(), (curves["return"] - band).min(), per_run["return"].min()) - 3
    hi = max(curves["target"].max(), (curves["return"] + band).max(), per_run["return"].max()) + 3
    several = per_run["run"].nunique() > 1

    for ax, panel in zip(axes.flat, panels):
        sub = curves[curves["panel"] == panel]
        ax.plot([lo, hi], [lo, hi], color=MUTED, lw=1, ls="--", zorder=1)
        ax.axvline(train_max, color=MUTED, lw=1, ls=":", zorder=1)
        for visible, color, label in ((True, COLOR_VISIBLE, "grupo visible"), (False, COLOR_HIDDEN, "grupo oculto")):
            s = sub[sub["group_visible"] == visible].sort_values("target")
            ic = s["ic95_usuario"].fillna(0)
            ax.fill_between(s["target"], s["return"] - ic, s["return"] + ic, color=color, alpha=0.15, lw=0, zorder=2)
            if several:
                pr = per_run[(per_run["panel"] == panel) & (per_run["group_visible"] == visible)]
                for _, one in pr.groupby("run"):
                    one = one.sort_values("target")
                    ax.plot(one["target"], one["return"], color=color, lw=0.8, alpha=0.45, zorder=2)
            ax.plot(s["target"], s["return"], color=color, lw=2, marker="o", ms=4, label=label, zorder=3)
        ax.set_title("Agregado" if panel == "todos" else f"Grupo {panel}", color=INK, fontsize=10, loc="left")
        ax.set_xlim(lo, hi)
        ax.set_ylim(lo, hi)
        ax.grid(color=GRID, lw=0.6)
        for side in ("top", "right"):
            ax.spines[side].set_visible(False)
        for side in ("left", "bottom"):
            ax.spines[side].set_color(GRID)
        ax.tick_params(colors=MUTED, labelsize=8)
    for ax in list(axes.flat)[len(panels):]:
        ax.set_visible(False)

    first = axes.flat[0]
    first.text(train_max, hi, " máx. train", color=MUTED, fontsize=8, va="top")
    first.text(hi, hi, "diagonal ", color=MUTED, fontsize=8, ha="right", va="bottom")
    handles, labels = first.get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper right", frameon=False, fontsize=9)
    note = "banda = IC 95 % por usuario" + ("; líneas finas = cada semilla de entrenamiento" if several else "")
    fig.supxlabel("Retorno pedido (20 pasos)", color=INK, fontsize=10)
    fig.supylabel("Retorno obtenido en test (media)", color=INK, fontsize=10)
    fig.suptitle(f"DT: retorno pedido frente a obtenido, warm-up 0 ({note})", color=INK, fontsize=12,
                 x=0.01, ha="left")
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    fig.savefig(path, dpi=150)
    plt.close(fig)


def main() -> None:
    args = parse_args()
    iql_runs = [r for group in args.iql for r in group]
    if not args.runs and not iql_runs:
        raise SystemExit("Indicar al menos --runs (DT) o --iql.")
    args.output.mkdir(parents=True, exist_ok=True)
    cfg = check_same_logs(args.runs + iql_runs)
    if args.baselines is None:
        print("Aviso: sin --baselines, la tabla no tiene líneas base.")

    entries = collect_entries(args)
    tab = long_table(entries, METRICS, COND_KEYS)
    write_main_table(tab, entries, cfg, args.output)
    missing = [k for k, _, _ in METRICS if not (tab["metrica"] == k).any()]
    if missing:
        print(f"Aviso: métricas que no están en sesiones.csv: {missing}")

    gcol = group_column(entries[0][1][0])
    if gcol:
        write_group_table(entries, gcol, cfg, args.output)
    else:
        print("Aviso: sesiones.csv no tiene columna de grupo; no se arma la tabla por grupo.")

    if args.runs:
        train_max = max(json.loads((r / "retornos_train.json").read_text())["max"] for r in args.runs)
        curves, per_run = sweep_curves(args.runs)
        curves.to_csv(args.output / "retorno_pedido_vs_obtenido.csv", index=False)
        plot_sweep(curves, per_run, train_max, args.output / "retorno_pedido_vs_obtenido.png")
    print(f"\nresultados en {args.output}: {sorted(p.name for p in args.output.iterdir())}")


if __name__ == "__main__":
    main()
