import numpy as np
import pandas as pd

from dt.reporte import entry_stats


def _sessions(values_by_user, policy="dt"):
    # dos semillas de sesión por usuario, una condición
    rows = [{"policy": policy, "warmup": 0, "group_visible": True, "user_id": u, "seed": s, "normalized": v}
            for u, vals in values_by_user.items() for s, v in enumerate(vals)]
    return pd.DataFrame(rows)


def test_ic_promedia_semillas_de_sesion_por_usuario():
    df = _sessions({0: [0.0, 1.0], 1: [1.0, 1.0], 2: [0.0, 0.0]})      # medias por usuario: 0,5 / 1 / 0
    st = entry_stats([df], "dt", ("normalized",), ["warmup", "group_visible"]).iloc[0]
    per_user = np.array([0.5, 1.0, 0.0])
    assert np.isclose(st["media"], per_user.mean())
    assert np.isclose(st["ic95_usuario"], 1.96 * per_user.std(ddof=1) / np.sqrt(3))
    assert st["n_usuarios"] == 3 and st["n_semillas"] == 1 and np.isnan(st["desvio_semillas"])


def test_desvio_entre_semillas_de_entrenamiento():
    a = _sessions({0: [0.2, 0.2], 1: [0.4, 0.4]})                     # media 0,3
    b = _sessions({0: [0.6, 0.6], 1: [0.8, 0.8]})                     # media 0,7
    st = entry_stats([a, b], "dt", ("normalized",), ["warmup", "group_visible"]).iloc[0]
    assert np.isclose(st["media"], 0.5)
    assert np.isclose(st["desvio_semillas"], np.std([0.3, 0.7], ddof=1))
    assert st["n_semillas"] == 2
