import torch

from dt.modelo import DecisionTransformer, check_no_leak, prev_ratings, seen_before_mask


def _batch(n_items=50, B=8, T=20):
    items = torch.stack([torch.randperm(n_items)[:T] for _ in range(B)])
    ratings = torch.randint(1, 6, (B, T)).float()
    rtg = ratings.flip(1).cumsum(1).flip(1)
    return {"rtg": rtg, "items": items, "prev": prev_ratings(ratings), "groups": torch.randint(0, 9, (B,))}


def test_no_leak():
    torch.manual_seed(0)
    model = DecisionTransformer(50, d_model=32, n_layers=2, n_heads=2)
    b = _batch()
    for t in (0, 7, 19):
        assert check_no_leak(model, b, t=t)


def test_seen_before_mask():
    m = seen_before_mask(torch.tensor([[17, 30, 45]]), 50)
    assert not m[0, 0].any()
    assert m[0, 1].nonzero().flatten().tolist() == [17]
    assert m[0, 2].nonzero().flatten().tolist() == [17, 30]


def test_prev_ratings():
    assert prev_ratings(torch.tensor([[4.0, 2.0, 5.0]])).tolist() == [[0, 4, 2]]
