"""Compara los reportes de distintos tipos de logs (p. ej. random frente a mixto), lado a lado.

    python -m experimentos.comparar_logs \
        --reporte random=outputs/reporte_netflix_random \
        --reporte mixto=outputs/reporte_netflix_mixto \
        --output outputs/comparacion_netflix

Lee tabla.csv de cada reporte (dt.reporte) y empareja las filas por la columna `clave`, que es
estable entre logs: el nombre de cada línea base, "DT", "IQL π [principal]", etc. Los
hiperparámetros y el retorno elegido pueden diferir entre logs: se listan debajo de la tabla.

Salidas en --output:
  comparacion_logs.md   una tabla por condición: normalizado (± semillas [± IC]) con cada tipo de
                        logs y la diferencia respecto del primero; además hit rate en warm-up 0
  comparacion_logs.csv  formato largo con todas las métricas
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from dt.reporte import CONDITIONS, cell, md_table

ORDER = ["random", "popularity", "item_mean", "group_mean", "group_posterior"]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--reporte", action="append", required=True, metavar="ETIQUETA=CARPETA",
                   help="reporte de un tipo de logs (repetible; el primero es la referencia de las diferencias)")
    p.add_argument("--output", type=Path, required=True)
    return p.parse_args()


def key_order(keys) -> list[str]:
    keys = list(dict.fromkeys(keys))
    base = [k for k in ORDER if k in keys]
    models = [k for k in keys if k.startswith(("DT", "IQL"))]
    others = [k for k in keys if k not in base and k not in models]   # p. ej. el sistema anterior
    return base + others + models


def main() -> None:
    args = parse_args()
    reports = []
    for spec in args.reporte:
        label, _, folder = spec.partition("=")
        if not folder:
            raise SystemExit(f"Formato esperado ETIQUETA=CARPETA, recibido: {spec}")
        tab = pd.read_csv(Path(folder) / "tabla.csv")
        if "clave" not in tab.columns:
            raise SystemExit(f"{folder}/tabla.csv no tiene la columna 'clave': regenerarlo con dt.reporte.")
        reports.append((label, tab.assign(logs=label)))
    args.output.mkdir(parents=True, exist_ok=True)

    long = pd.concat([t for _, t in reports], ignore_index=True)
    long.to_csv(args.output / "comparacion_logs.csv", index=False)
    labels = [lab for lab, _ in reports]
    ref = labels[0]
    keys = key_order(long["clave"])

    def get(metric, label, key, w, v):
        m = long[(long["metrica"] == metric) & (long["logs"] == label) & (long["clave"] == key)
                 & (long["warmup"] == w) & (long["group_visible"] == v)]
        return m.iloc[0] if len(m) else None

    md = ["# Comparación entre tipos de logs", "",
          "Test, misma evaluación para todos: sólo cambian los logs con que se entrenan los modelos y se "
          "ajustan las líneas base. Notación: `media ± desvío entre semillas [±IC 95 % por usuario]`. "
          f"Δ = diferencia de medias respecto de `{ref}`.", ""]
    for metric, title, conds in (("normalized", "Retorno normalizado", CONDITIONS),
                                 ("hit_rate", "Hit rate", [c for c in CONDITIONS if c[0] == 0])):
        for w, v, cond in conds:
            header = ["Política"] + labels + [f"Δ {lab}" for lab in labels[1:]]
            rows = []
            for k in keys:
                vals = [get(metric, lab, k, w, v) for lab in labels]
                if all(x is None for x in vals):
                    continue
                deltas = [f"{x['media'] - vals[0]['media']:+.3f}" if x is not None and vals[0] is not None else ""
                          for x in vals[1:]]
                rows.append([k] + [cell(x) for x in vals] + deltas)
            md += [f"## {title}: {cond}", "", *md_table(header, rows), ""]

    md += ["## Configuración de cada modelo por tipo de logs", ""]
    names = long[long["clave"].str.startswith(("DT", "IQL"))][["logs", "clave", "politica"]].drop_duplicates()
    for k in [k for k in keys if k.startswith(("DT", "IQL"))]:
        for lab in labels:
            n = names[(names["clave"] == k) & (names["logs"] == lab)]["politica"]
            if len(n):
                md.append(f"- `{lab}` / {k}: {n.iloc[0]}")
    (args.output / "comparacion_logs.md").write_text("\n".join(md) + "\n")
    print("\n".join(md[:4 + 3 + len(keys) + 2]))
    print(f"\ncomparación en {args.output}")


if __name__ == "__main__":
    main()
