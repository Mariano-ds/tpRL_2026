"""Prueba corta de punta a punta con el protocolo real (paso 0).

Verifica los supuestos de los scripts sobre el protocolo y corre cada etapa en miniatura:
1 época, modelos chicos y pocos usuarios de val/test. No usa GPU de forma significativa.

    python -m experimentos.prueba_corta --dataset netflix

Frena en el primer supuesto que no se cumpla y muestra el error. Todo se escribe en
outputs/smoke/ (se puede borrar); los logs mixto quedan en outputs/logs/ y se reutilizan.
Los números que imprime no significan nada: sólo importa llegar a "TODO OK".
"""

import argparse
import importlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd  # noqa: F401
import torch

if os.getcwd() not in sys.path:
    sys.path.insert(0, os.getcwd())


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--dataset", default="netflix", choices=["netflix", "goodreads"])
    p.add_argument("--n-users", type=int, default=40, help="usuarios de val y de test para la mini-evaluación")
    p.add_argument("--output", type=Path, default=Path("outputs/smoke"))
    return p.parse_args()


def main():
    args = parse_args()
    DATASET = args.dataset
    N_USERS = args.n_users
    SMOKE = args.output
    shutil.rmtree(SMOKE, ignore_errors=True)
    DEV = "cuda" if torch.cuda.is_available() else "cpu"
    PY = sys.executable
    print(f"device: {DEV} | torch {torch.__version__} | dataset {DATASET}")

    def sh(cmd):
        """Corre un comando, muestra las últimas líneas y frena si falla."""
        t0 = time.time()
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        lines = (r.stdout + r.stderr).strip().splitlines()
        print(f"  $ {cmd.replace(PY, 'python')}  ({time.time() - t0:.0f}s)")
        print("\n".join("      " + l for l in lines[-(25 if r.returncode else 4):]))
        if r.returncode:
            raise RuntimeError(f"FALLÓ: {cmd}")

    def ok(msg):
        print("  OK  " + msg)

    # ---------------------------------------------------------------- 1. datos y logs
    print("\n[1/6] Datos y logs")
    from protocolo.datos import load_train, load_test, split_by_user, make_episodes, num_items
    from protocolo.logs import logged_episodes, logs_cache
    from protocolo.evaluar import evaluate_grid, write_reports, baseline_factories

    n_items = num_items(DATASET)
    train, val = split_by_user(load_train(DATASET))
    test = load_test(DATASET)
    ep = make_episodes(train, length=20)
    items, ratings, groups = map(np.asarray, (ep.items, ep.ratings, ep.groups))
    rtg = np.asarray(ep.returns_to_go())
    assert items.shape == ratings.shape == rtg.shape and rtg.shape[1] == 20, (items.shape, ratings.shape, rtg.shape)
    assert groups.shape == (len(items),), groups.shape
    assert np.allclose(rtg[:, 0], ratings.sum(1)), "returns_to_go()[:, 0] no es el retorno del episodio"
    assert items.min() >= 0 and items.max() < n_items
    ok(f"n_items={n_items} | usuarios train={len(train)} val={len(val)} test={len(test)} | episodios={len(items)}")
    ok(f"retorno medio de un episodio (random): {rtg[:, 0].mean():.1f}   (Netflix en el protocolo: 64,3)")
    lg = logged_episodes("mixto", train, train, n_items, 20, seed=0, cache=logs_cache(DATASET, "mixto", "train"))
    ok(f"logs mixto: retorno medio {np.asarray(lg.episodes.ratings).sum(1).mean():.1f}   (Netflix en el protocolo: 74,6)")
    assert hasattr(lg, "logged_users"), "logged_episodes no devuelve logged_users()"

    # ---------------------------------------------------------------- 2. contrato de evaluate_grid
    print("\n[2/6] evaluate_grid y write_reports")
    fac = baseline_factories(train, n_items)
    fac = {k: fac[k] for k in ("random", "item_mean") if k in fac}
    for split, users in (("val", val[:N_USERS]), ("test", test[:N_USERS])):
        df = evaluate_grid(fac, users, n_items, horizon=20, warmups=(0, 5), group_visibility=(True, False), seeds=(0,))
        missing = {"policy", "warmup", "group_visible", "normalized", "return"} - set(df.columns)
        assert not missing, f"faltan columnas {missing}; sesiones tiene: {list(df.columns)}"
        conds = set(map(tuple, df[["warmup", "group_visible"]].drop_duplicates().values.tolist()))
        assert len(conds) == 4, f"se esperaban 4 condiciones y hay {conds}"
        ok(f"{split}: {len(df)} sesiones, 4 condiciones, columnas esperadas presentes")
    gcol = next((c for c in ("group", "grupo") if c in df.columns), None)
    print(f"  {'OK ' if gcol else 'AVISO'} columna de grupo en sesiones: {gcol}  (sin ella, el gráfico por grupo sólo muestra el agregado)")
    from dt.reporte import METRICS, USER_COLUMNS, find_column
    ucol = find_column(df, USER_COLUMNS)
    print(f"  {'OK ' if ucol else 'AVISO'} columna de usuario: {ucol}  (sin ella, el IC 95 % trata cada sesión como unidad)")
    for key, _, cands in METRICS[1:]:
        col = find_column(df, cands)
        print(f"  {'OK ' if col else 'AVISO'} métrica {key}: columna {col}  (sin ella, la tabla la marca como ausente)")
    print(f"      columnas de sesiones.csv: {list(df.columns)}")
    write_reports(df, SMOKE / "baselines")
    ok(f"write_reports -> {sorted(p.name for p in (SMOKE / 'baselines').iterdir())}")

    # ---------------------------------------------------------------- 3. tests unitarios
    print("\n[3/6] Tests unitarios")
    sh(f"{PY} -m pytest -q dt/tests iql/tests")

    # ---------------------------------------------------------------- 4. DT: 1 época + val/test en miniatura
    print("\n[4/6] DT")
    DT_RUN = SMOKE / "dt"
    sh(f"{PY} -m dt.entrenar --dataset {DATASET} --epochs 1 --d-model 32 --n-layers 1 --n-heads 2 --output {DT_RUN}")
    import dt.evaluar as dte
    a = argparse.Namespace(seeds=[0], seeds_barrido=[0], device=DEV, targets=None)
    dte.run_val(DT_RUN, val[:N_USERS], n_items, [50.0, 80.0], a)
    dte.run_test(DT_RUN, test[:N_USERS], n_items, [50.0, 80.0], a)
    ok("DT: entrenamiento, validación y test")

    # ---------------------------------------------------------------- 5. IQL: 2 configuraciones + val/test en miniatura
    print("\n[5/6] IQL")
    import iql.evaluar as iqe
    iql_runs = []
    for g in (0, 0.9):
        run = SMOKE / f"iql_g{g}"
        sh(f"{PY} -m iql.entrenar --dataset {DATASET} --gamma {g} --epochs 1 --d-model 32 --hidden 64 --output {run}")
        iql_runs.append(run)
    b = argparse.Namespace(seeds=[0], seeds_val=[0], device=DEV, config="principal", seleccion=SMOKE / "iql_seleccion.json")
    try:   # limitar los usuarios de iql.evaluar sólo para esta prueba
        iqe.load_train = lambda d: None
        iqe.split_by_user = lambda _: (None, val[:N_USERS])
        iqe.load_test = lambda d: test[:N_USERS]
        iqe.run_val(iql_runs, DATASET, "random", b)
        chosen = json.loads(b.seleccion.read_text())["run_elegida"]
        iql_chosen = next(r for r in iql_runs if r.name == chosen)
        iqe.run_test([iql_chosen], DATASET, "random", b)
    finally:
        importlib.reload(iqe)                      # restaura las funciones originales
    ok("IQL: entrenamiento, validación, selección y test")

    # ---------------------------------------------------------------- 6. reporte
    print("\n[6/6] Reporte")
    sh(f"{PY} -m dt.reporte --runs {DT_RUN} --iql {iql_chosen} --baselines {SMOKE / 'baselines'} --output {SMOKE / 'reporte'}")
    ok(f"salidas: {sorted(p.name for p in (SMOKE / 'reporte').iterdir())}")

    print("\nTODO OK. Los números no significan nada (1 época, pocos usuarios): sólo se verificó que el flujo funciona.")
    print(f"Se puede borrar {SMOKE}/ (los logs mixto quedan en outputs/logs/ y se reutilizan).")


if __name__ == "__main__":
    main()
