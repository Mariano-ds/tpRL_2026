"""Scripts de orquestación: prueba corta, corrida completa y comparación de logs."""
