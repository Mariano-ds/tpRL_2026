# Experimentos: prueba corta, corrida completa y comparación de logs

Scripts que orquestan `dt/` e `iql/` sobre el protocolo. Todos se corren desde `2026/tp`.

| Archivo | Qué hace |
|---|---|
| `prueba_corta.py` | Paso 0: verifica los supuestos sobre el protocolo real y corre todo el flujo en miniatura (1 época, 40 usuarios). |
| `correr_todo.py` | Corrida completa y **reanudable**: líneas base, DT, barrido y selección de IQL, semillas, test, reportes, curvas y comparación de logs. |
| `comparar_logs.py` | Tabla lado a lado de los reportes de cada tipo de logs (`random` frente a `mixto`). |

## 1. Prueba corta (antes de gastar GPU)

```bash
python -m experimentos.prueba_corta --dataset netflix
```

Verifica, en orden:
1. **Datos y logs:**
   - forma de los episodios;
   - que `returns_to_go()[:, 0]` sea el retorno del episodio;
   - que los ítems estén en rango;
   - que funcionen los logs `mixto`.

   Imprime los retornos medios para compararlos con la tabla del protocolo: 64,3 con `random` y 74,6 con `mixto` en Netflix.
2. **`evaluate_grid`:**
   - que acepte usuarios de validación y de test;
   - que devuelva las columnas y las 4 condiciones que esperan los scripts.

   Además avisa si faltan las columnas de grupo, de usuario o de las métricas secundarias.
3. **Tests unitarios** de `dt/` e `iql/`.
4. **DT:** 1 época, validación y test con 40 usuarios.
5. **IQL:** dos configuraciones (γ = 0 y γ = 0,9), selección y test.
6. **Reporte:** las tablas y el gráfico.

Frena en el primer supuesto que no se cumpla. Las salidas van a `outputs/smoke/`, que se puede borrar. Los números que imprime no significan nada: solo importa llegar a `TODO OK`.

## 2. Corrida completa

```bash
python -m experimentos.correr_todo --dataset netflix --logs random mixto
```

Para cada tipo de logs corre estas etapas:

| Etapa | Qué corre | Se saltea si existe |
|---|---|---|
| `baselines` | `protocolo.evaluar`, con `--logs` si no es `random`; con `mixto` incluye el sistema anterior | `baselines_{ds}_{logs}/sesiones.csv` |
| `dt` | `dt.entrenar` con cada semilla → `dt.evaluar --split val` → `dt.evaluar --split test` | entrenamiento completo¹ / `eval/val/mejor_retorno.json` / `eval/test/retorno_usado.json` |
| `iql` | barrido τ × β × γ con la primera semilla → `iql.evaluar --split val` (selección) → semillas restantes de la variante `principal` y de la otra variante de γ (`gamma0` o `gamma_pos`) → `iql.evaluar --split test --config …` | entrenamiento completo¹ / `iql_{ds}_{logs}_seleccion.json` / `eval/test/seleccion_usada.json` |
| `reporte` | `dt.reporte`, con DT, todas las variantes de IQL y líneas base, más `dt.curvas` | se regenera siempre (es rápido) |
| `comparacion` | `experimentos.comparar_logs`, si hay más de un tipo de logs | se regenera siempre |

¹ Un entrenamiento cuenta como hecho si existe `modelo.pt` y `curvas.csv` tiene todas las épocas de su `config.json`. Si quedó a medias, se reentrena desde cero.

**Reanudar:** si la sesión se corta, se vuelve a correr **el mismo comando** y se saltea lo que ya está hecho. Para rehacer un paso, borrar su salida.
- La selección de IQL se reutiliza si ya existe. Si cambiás el barrido (`--gammas`, `--taus`, `--betas`), borrá `iql_{ds}_{logs}_seleccion.json`.
- Test se evalúa **una sola vez** por corrida: si una corrida ya tiene `eval/test/`, no se vuelve a evaluar.

**Argumentos:**

| Argumento | Default | Descripción |
|---|---|---|
| `--dataset` | `netflix` | `netflix` o `goodreads` |
| `--logs` | `random mixto` | tipos de logs, en orden; el primero es la referencia de la comparación |
| `--base` | `outputs` | carpeta de salidas, por ejemplo en Drive |
| `--seeds` | `0 1 2` | semillas de entrenamiento; el barrido de IQL usa la primera |
| `--dt-epochs`, `--iql-epochs` | `20`, `20` | épocas |
| `--gammas`, `--taus`, `--betas` | `0 0.9`, `0.7 0.9`, `3 10` | barrido de IQL (8 configuraciones) |
| `--dt-args`, `--iql-args` | | argumentos extra para el entrenamiento, por ejemplo `"--batch-size 512"` |
| `--etapas` | todas | subconjunto de `baselines dt iql reporte comparacion` |
| `--dry-run` | | solo muestra qué correría |

Todo lo que se imprime queda también en `{base}/correr_todo_{dataset}.log`. Al final hay un resumen con los pasos más lentos.

**Salidas en `--base`:**
- `baselines_{ds}_{logs}/`, `dt_{ds}_{logs}_seed{s}/` e `iql_{ds}_{logs}_g{γ}_t{τ}_b{β}_seed{s}/`: una carpeta por corrida, con `config.json`, `curvas.csv`, `modelo.pt` y `eval/`.
- `iql_{ds}_{logs}_seleccion.json` y `.csv`: la selección de IQL y la tabla de validación de todo el barrido.
- `reporte_{ds}_{logs}/`:
  - `tabla.md` y `.csv`, con todas las métricas, el desvío entre semillas y el IC por usuario;
  - `tabla_por_grupo.md` y `.csv`;
  - `retorno_pedido_vs_obtenido.png` y `.csv`;
  - `curvas_dt.png` y `curvas_iql_{variante}.png`.
- `comparacion_{ds}/comparacion_logs.md` y `.csv`.

**Tiempo:** el barrido de IQL (8 configuraciones × 2 tipos de logs) y las evaluaciones son lo más pesado. Una forma de repartirlo en sesiones de Colab:

```bash
python -m experimentos.correr_todo --logs random --etapas baselines dt reporte      # sesión 1
python -m experimentos.correr_todo --logs random --etapas iql reporte               # sesión 2
python -m experimentos.correr_todo --logs mixto                                     # sesión 3, …
python -m experimentos.correr_todo --logs random mixto --etapas reporte comparacion  # al final
```

## 3. Comparación entre tipos de logs

`correr_todo` la corre al final. A mano:

```bash
python -m experimentos.comparar_logs \
    --reporte random=outputs/reporte_netflix_random \
    --reporte mixto=outputs/reporte_netflix_mixto \
    --output outputs/comparacion_netflix
```

- **Cómo empareja las filas:** usa la columna `clave` de `tabla.csv`, que es estable entre tipos de logs: el nombre de cada línea base, `DT`, `IQL π [principal]`, `IQL, máximo de Q [gamma0]`, etc.
- **Qué muestra:** el normalizado en las 4 condiciones y el hit rate con warm-up 0, para cada tipo de logs y con la diferencia respecto del primero.
- **Configuraciones:** el retorno elegido y los hiperparámetros pueden diferir entre tipos de logs; se listan al final.
