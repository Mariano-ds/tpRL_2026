"""Corrida completa del TP, reanudable: líneas base, DT, IQL, reportes y comparación de logs.

    python -m experimentos.correr_todo --dataset netflix --logs random mixto
    python -m experimentos.correr_todo --dataset netflix --logs random --base /content/drive/MyDrive/tp_rl/outputs

Para cada tipo de logs, en orden:
  1. baselines   líneas base ajustadas con esos logs (protocolo.evaluar; con mixto incluye el sistema anterior)
  2. dt          entrenar el DT con cada semilla; validación (elige el retorno pedido); test
  3. iql         barrido de τ, β y γ con semilla 0; validación (selección); semillas restantes de la
                 configuración principal y de la otra variante de γ; test de cada una
  4. reporte     tablas (todas las métricas, IC por usuario, por grupo), gráfico de return
                 conditioning y curvas de entrenamiento
y al final, si hay más de un tipo de logs:
  5. comparacion tabla lado a lado (experimentos.comparar_logs)

REANUDABLE: cada paso se saltea si su salida ya existe (un entrenamiento cuenta como hecho si
curvas.csv tiene todas las épocas de su config.json). Si la sesión se corta, volver a correr el
mismo comando. Para rehacer un paso, borrar su salida. La selección de IQL se reutiliza si ya
existe: si se cambia el barrido, borrar iql_{dataset}_{logs}_seleccion.json.

Test se evalúa una sola vez por corrida: si ya tiene eval/test/, no se repite.
Todo lo que se imprime queda también en {base}/correr_todo_{dataset}.log.
"""

from __future__ import annotations

import argparse
import itertools
import json
import shlex
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

import pandas as pd

STAGES = ["baselines", "dt", "iql", "reporte", "comparacion"]
PY = sys.executable


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--dataset", default="netflix", choices=["netflix", "goodreads"])
    p.add_argument("--logs", nargs="+", default=["random", "mixto"], choices=["random", "mixto", "experto"])
    p.add_argument("--base", type=Path, default=Path("outputs"), help="carpeta de salidas (p. ej. en Drive)")
    p.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2], help="semillas de entrenamiento")
    p.add_argument("--dt-epochs", type=int, default=20)
    p.add_argument("--iql-epochs", type=int, default=20)
    p.add_argument("--gammas", type=float, nargs="+", default=[0.0, 0.9])
    p.add_argument("--taus", type=float, nargs="+", default=[0.7, 0.9])
    p.add_argument("--betas", type=float, nargs="+", default=[3.0, 10.0])
    p.add_argument("--dt-args", default="", help='argumentos extra para dt.entrenar, p. ej. "--batch-size 512"')
    p.add_argument("--iql-args", default="", help="argumentos extra para iql.entrenar")
    p.add_argument("--etapas", nargs="+", default=STAGES, choices=STAGES, help="etapas a correr")
    p.add_argument("--dry-run", action="store_true", help="sólo mostrar qué se correría")
    return p.parse_args()


class Runner:
    def __init__(self, log_path: Path, dry: bool):
        self.dry = dry
        self.log_path = log_path
        log_path.parent.mkdir(parents=True, exist_ok=True)
        self.times: list[tuple[str, float]] = []

    def log(self, msg: str) -> None:
        print(msg, flush=True)
        with open(self.log_path, "a") as f:
            f.write(msg + "\n")

    def run(self, title: str, cmd: list) -> None:
        cmd = [str(c) for c in cmd]
        shown = " ".join(shlex.quote(c) for c in ["python", *cmd[1:]])
        self.log(f"\n>>> {title}\n$ {shown}")
        if self.dry:
            return
        t0 = time.time()
        with subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1) as p, \
                open(self.log_path, "a") as f:
            for line in p.stdout:
                print(line, end="", flush=True)
                f.write(line)
        dt = time.time() - t0
        self.times.append((title, dt))
        if p.returncode:
            self.log(f"!!! FALLÓ ({dt:.0f}s): {title}. Corregir y volver a correr el mismo comando: lo hecho se saltea.")
            raise SystemExit(p.returncode)
        self.log(f"<<< listo en {dt / 60:.1f} min")

    def skip(self, title: str, why: str) -> None:
        self.log(f"--- ya hecho, se saltea: {title} ({why})")


def training_done(run: Path) -> bool:
    try:
        cfg = json.loads((run / "config.json").read_text())
        return (run / "modelo.pt").exists() and len(pd.read_csv(run / "curvas.csv")) >= cfg["epochs"]
    except (FileNotFoundError, KeyError, pd.errors.EmptyDataError):
        return False


def hp_name(g: float, t: float, b: float) -> str:
    return f"g{g:g}_t{t:g}_b{b:g}"


def stage_baselines(R: Runner, a, logs: str) -> Path:
    out = a.base / f"baselines_{a.dataset}_{logs}"
    title = f"[{logs}] líneas base"
    if (out / "sesiones.csv").exists():
        R.skip(title, out / "sesiones.csv")
    else:
        extra = ["--logs", logs] if logs != "random" else []
        R.run(title, [PY, "-m", "protocolo.evaluar", "--dataset", a.dataset, *extra, "--output", out])
    return out


def stage_dt(R: Runner, a, logs: str) -> list[Path]:
    runs = [a.base / f"dt_{a.dataset}_{logs}_seed{s}" for s in a.seeds]
    for s, run in zip(a.seeds, runs):
        title = f"[{logs}] DT: entrenar semilla {s}"
        if training_done(run):
            R.skip(title, run / "modelo.pt")
        else:
            R.run(title, [PY, "-m", "dt.entrenar", "--dataset", a.dataset, "--logs", logs, "--seed", s,
                          "--epochs", a.dt_epochs, "--output", run, *shlex.split(a.dt_args)])
    for split, marker in (("val", "eval/val/mejor_retorno.json"), ("test", "eval/test/retorno_usado.json")):
        for run in runs:
            title = f"[{logs}] DT: {split} {run.name}"
            if (run / marker).exists():
                R.skip(title, run / marker)
            else:
                R.run(title, [PY, "-m", "dt.evaluar", "--split", split, "--run", run])
    return runs


def stage_iql(R: Runner, a, logs: str) -> list[tuple[str, list[Path]]]:
    """Devuelve [(variante, corridas)] de las configuraciones finales evaluadas en test."""
    def run_dir(g, t, b, s):
        return a.base / f"iql_{a.dataset}_{logs}_{hp_name(g, t, b)}_seed{s}"

    def train(g, t, b, s):
        run = run_dir(g, t, b, s)
        title = f"[{logs}] IQL: entrenar γ={g:g} τ={t:g} β={b:g} semilla {s}"
        if training_done(run):
            R.skip(title, run / "modelo.pt")
        else:
            R.run(title, [PY, "-m", "iql.entrenar", "--dataset", a.dataset, "--logs", logs, "--seed", s,
                          "--gamma", g, "--tau", t, "--beta", b, "--epochs", a.iql_epochs, "--output", run,
                          *shlex.split(a.iql_args)])
        return run

    s0 = a.seeds[0]
    sweep = [train(g, t, b, s0) for g, t, b in itertools.product(a.gammas, a.taus, a.betas)]

    sel = a.base / f"iql_{a.dataset}_{logs}_seleccion.json"
    title = f"[{logs}] IQL: validación y selección ({len(sweep)} configuraciones)"
    if sel.exists():
        R.skip(title, f"{sel}; borrarlo para rehacer la selección")
    else:
        R.run(title, [PY, "-m", "iql.evaluar", "--split", "val", "--seleccion", sel, "--run", *sweep])
    if not sel.exists():                      # dry-run
        R.log(f"(selección pendiente: las semillas y el test de IQL dependen de {sel})")
        return []

    variants = json.loads(sel.read_text())["variantes"]
    finals, seen = [], set()
    for name in ("principal", "gamma0", "gamma_pos"):          # la principal primero; sin duplicados
        v = variants.get(name)
        if v is None or (key := (v["gamma"], v["tau"], v["beta"])) in seen:
            continue
        seen.add(key)
        runs = [train(v["gamma"], v["tau"], v["beta"], s) for s in a.seeds]
        pending = [r for r in runs if not (r / "eval/test/seleccion_usada.json").exists()]
        title = f"[{logs}] IQL: test variante {name} (γ={v['gamma']:g} τ={v['tau']:g} β={v['beta']:g})"
        if not pending:
            R.skip(title, "todas las semillas ya tienen eval/test/")
        else:
            R.run(title, [PY, "-m", "iql.evaluar", "--split", "test", "--config", name, "--seleccion", sel,
                          "--run", *pending])
        finals.append((name, runs))
    return finals


def stage_report(R: Runner, a, logs: str, baselines: Path, dt_runs, iql_finals) -> Path:
    out = a.base / f"reporte_{a.dataset}_{logs}"
    cmd = [PY, "-m", "dt.reporte", "--output", out]
    if dt_runs:
        cmd += ["--runs", *dt_runs]
    for _, runs in iql_finals:
        cmd += ["--iql", *runs]
    if (baselines / "sesiones.csv").exists() or R.dry:
        cmd += ["--baselines", baselines]
    if not dt_runs and not iql_finals:
        R.log(f"[{logs}] reporte: no hay corridas de DT ni de IQL todavía")
        return out
    R.run(f"[{logs}] reporte: tablas y gráfico", cmd)
    if dt_runs:
        R.run(f"[{logs}] curvas DT", [PY, "-m", "dt.curvas", "--runs", *dt_runs, "--output", out])
    for name, runs in iql_finals:
        R.run(f"[{logs}] curvas IQL {name}", [PY, "-m", "dt.curvas", "--runs", *runs, "--output", out,
                                               "--nombre", f"curvas_iql_{name}.png"])
    return out


def main() -> None:
    a = parse_args()
    R = Runner(a.base / f"correr_todo_{a.dataset}.log", a.dry_run)
    R.log(f"\n===== correr_todo {datetime.now().isoformat(timespec='seconds')} | dataset {a.dataset} | "
          f"logs {a.logs} | semillas {a.seeds} | etapas {a.etapas}{' | DRY-RUN' if a.dry_run else ''} =====")
    t0 = time.time()
    reports = {}
    for logs in a.logs:
        baselines = a.base / f"baselines_{a.dataset}_{logs}"
        if "baselines" in a.etapas:
            baselines = stage_baselines(R, a, logs)
        dt_runs = stage_dt(R, a, logs) if "dt" in a.etapas else \
            [r for s in a.seeds if training_done(r := a.base / f"dt_{a.dataset}_{logs}_seed{s}")]
        iql_finals = stage_iql(R, a, logs) if "iql" in a.etapas else []
        if "reporte" in a.etapas:
            dt_tested = [r for r in dt_runs if (r / "eval/test/retorno_usado.json").exists() or a.dry_run]
            reports[logs] = stage_report(R, a, logs, baselines, dt_tested, iql_finals)

    if "comparacion" in a.etapas and len(a.logs) > 1:
        specs = [f"{lab}={a.base / f'reporte_{a.dataset}_{lab}'}" for lab in a.logs]
        if all((a.base / f"reporte_{a.dataset}_{lab}" / "tabla.csv").exists() for lab in a.logs) or a.dry_run:
            R.run("comparación entre tipos de logs", [PY, "-m", "experimentos.comparar_logs",
                                                      *sum((["--reporte", s] for s in specs), []),
                                                      "--output", a.base / f"comparacion_{a.dataset}"])
        else:
            R.log("comparación: faltan reportes de algún tipo de logs")

    R.log(f"\n===== terminado en {(time.time() - t0) / 60:.1f} min =====")
    for title, secs in sorted(R.times, key=lambda x: -x[1])[:10]:
        R.log(f"  {secs / 60:6.1f} min  {title}")


if __name__ == "__main__":
    main()
