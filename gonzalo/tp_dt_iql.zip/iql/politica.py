"""IQLPolicy: adapta un modelo IQL entrenado a la interfaz Policy del protocolo.

Dos modos a partir del mismo modelo (sección 5.7 de la guía):
  "pi": ordena por las logits de π (lo que propone IQL; π sólo se entrenó con acciones registradas).
  "q":  ordena por Q(s, a) sobre todos los ítems: el máximo de Q que IQL evita al entrenar.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import torch

from iql.modelo import IQL, UNKNOWN_GROUP


def load_model(run_dir: Path | str, device: str = "cpu") -> IQL:
    ckpt = torch.load(Path(run_dir) / "modelo.pt", map_location=device)
    model = IQL(**ckpt["model_kwargs"]).to(device)
    model.load_state_dict(ckpt["state_dict"])
    return model.eval()


class IQLPolicy:
    def __init__(self, model: IQL, mode: str = "pi", device: str = "cpu"):
        if mode not in ("pi", "q"):
            raise ValueError("mode debe ser 'pi' o 'q'")
        self.model = model.eval()
        self.net = model.pi if mode == "pi" else model.q
        self.mode = mode
        self.device = torch.device(device)

    def reset(self, group: int | None, horizon: int) -> None:
        if horizon > self.model.horizon:
            raise ValueError(f"horizonte {horizon} mayor que el del modelo ({self.model.horizon})")
        self.group = UNKNOWN_GROUP if group is None else int(group)

    @torch.no_grad()
    def scores(self, items_seen: np.ndarray, ratings_seen: np.ndarray) -> np.ndarray:
        t = len(items_seen)
        dev = self.device
        items = torch.as_tensor(np.asarray(items_seen, dtype=np.int64), device=dev).reshape(1, t)
        ratings = torch.as_tensor(np.asarray(ratings_seen, dtype=np.float32), device=dev).reshape(1, t)
        out = self.net(items, ratings, torch.tensor([self.group], device=dev))   # (1, t + 1, n_items)
        return out[0, t].double().cpu().numpy()                                  # estado h_t
