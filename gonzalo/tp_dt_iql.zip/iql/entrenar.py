"""Entrena IQL con los mismos episodios de 20 pasos que el DT.

Uso, desde 2026/tp:

    python -m iql.entrenar --dataset netflix --logs random --seed 0
    python -m iql.entrenar --dataset netflix --logs random --gamma 0 --tau 0.7 --beta 3 --seed 0

Salidas en outputs/iql_{dataset}_{logs}_g{gamma}_t{tau}_b{beta}_seed{seed}/:
    modelo.pt     estado final de Q, V, π y Q̄ + kwargs del modelo
    config.json   argumentos de la corrida y decisiones de diseño
    curvas.csv    pérdidas y diagnósticos por época, en train y val

Se guarda el modelo final, no el de menor pérdida: las pérdidas de Q y π no miden la
calidad de la política. τ, β y γ se eligen con el protocolo en validación.
"""

from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import torch
from torch.utils.data import DataLoader, TensorDataset

from dt.entrenar import HORIZON, _tensor, load_episodes, set_seed
from protocolo.datos import num_items

from iql.modelo import IQL, UNKNOWN_GROUP, check_no_leak, iql_losses

DIAG = ["v", "q", "pi", "w_media", "w_truncados", "adv_media", "adv_desvio", "v0", "q_media"]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--dataset", default="netflix", choices=["netflix", "goodreads"])
    p.add_argument("--logs", default="random", choices=["random", "mixto", "experto"])
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--output", type=Path, default=None)
    p.add_argument("--gamma", type=float, default=0.9)
    p.add_argument("--tau", type=float, default=0.7, help="expectil de V")
    p.add_argument("--beta", type=float, default=3.0, help="temperatura inversa de AWR")
    p.add_argument("--max-weight", type=float, default=100.0)
    p.add_argument("--reward", default="centered", choices=["centered", "raw"],
                   help="centered: (r − 3) / 2; raw: r")
    p.add_argument("--polyak", type=float, default=0.005)
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--d-model", type=int, default=128)
    p.add_argument("--hidden", type=int, default=256)
    p.add_argument("--p-hide", type=float, default=0.3,
                   help="fracción de episodios de train con el grupo reemplazado por 'desconocido'")
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    return p.parse_args()


def to_tensors(ep) -> TensorDataset:
    return TensorDataset(_tensor(ep.items, torch.long), _tensor(ep.ratings, torch.float32),
                         _tensor(ep.groups, torch.long))


def as_batch(tensors, device, p_hide: float = 0.0) -> dict:
    items, ratings, groups = (x.to(device) for x in tensors)
    if p_hide > 0:
        groups = groups.masked_fill(torch.rand(groups.shape, device=device) < p_hide, UNKNOWN_GROUP)
    return {"items": items, "ratings": ratings, "groups": groups}


def loss_kwargs(args) -> dict:
    return dict(gamma=args.gamma, tau=args.tau, beta=args.beta, max_weight=args.max_weight, reward=args.reward)


@torch.no_grad()
def eval_epoch(model, loader, device, args) -> dict:
    model.eval()
    sums, n = {k: 0.0 for k in DIAG}, 0
    for tensors in loader:
        b = as_batch(tensors, device)
        out = iql_losses(model, b, **loss_kwargs(args))
        bs = b["items"].shape[0]
        for k in DIAG:
            sums[k] += out[k].item() * bs
        n += bs
    model.train()
    return {k: v / n for k, v in sums.items()}


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    name = f"iql_{args.dataset}_{args.logs}_g{args.gamma:g}_t{args.tau:g}_b{args.beta:g}_seed{args.seed}"
    out = args.output or Path("outputs") / name
    out.mkdir(parents=True, exist_ok=True)
    device = torch.device(args.device)

    n_items = num_items(args.dataset)
    train_ep, val_ep = load_episodes(args.dataset, args.logs, n_items)
    train_ds, val_ds = to_tensors(train_ep), to_tensors(val_ep)
    g = torch.Generator().manual_seed(args.seed)
    train_dl = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, drop_last=True, generator=g)
    val_dl = DataLoader(val_ds, batch_size=1024)
    print(f"{args.dataset} / logs {args.logs}: {len(train_ds)} episodios de train, {len(val_ds)} de val")
    print(f"γ = {args.gamma}, τ = {args.tau}, β = {args.beta}, recompensa {args.reward}")

    model_kwargs = dict(n_items=n_items, horizon=HORIZON, d_model=args.d_model, hidden=args.hidden)
    model = IQL(**model_kwargs).to(device)

    # Test de no fuga sobre los tres codificadores antes de entrenar.
    probe = as_batch(next(iter(val_dl)), device)
    probe = {k: v[:64] for k, v in probe.items()}
    for net_name in ("q", "v", "pi"):
        if not check_no_leak(getattr(model, net_name), probe["items"], probe["ratings"], probe["groups"]):
            raise SystemExit(f"FALLA el test de no fuga en {net_name}: el estado h_t ve (a_t, r_t) o el futuro.")
    print("test de no fuga: OK")

    opts = {k: torch.optim.Adam(getattr(model, k).parameters(), lr=args.lr) for k in ("q", "v", "pi")}

    config = {**{k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
              "output": str(out), "model": model_kwargs,
              "estado": "GRU sobre (ítem, rating) previos + grupo (8 = desconocido) + paso; codificador propio por red",
              "checkpoint": "modelo final (las pérdidas no miden calidad)"}
    (out / "config.json").write_text(json.dumps(config, indent=2))

    curves = []
    for epoch in range(1, args.epochs + 1):
        t0 = time.time()
        sums, n = {k: 0.0 for k in DIAG}, 0
        for tensors in train_dl:
            b = as_batch(tensors, device, p_hide=args.p_hide)
            losses = iql_losses(model, b, **loss_kwargs(args))
            for o in opts.values():
                o.zero_grad(set_to_none=True)
            # Cada pérdida sólo llega a su red: un solo backward alcanza.
            (losses["v"] + losses["q"] + losses["pi"]).backward()
            for k, o in opts.items():
                torch.nn.utils.clip_grad_norm_(getattr(model, k).parameters(), 1.0)
                o.step()
            model.update_target(args.polyak)
            for k in DIAG:
                sums[k] += losses[k].item()
            n += 1

        row = {"epoch": epoch, **{f"train_{k}": v / n for k, v in sums.items()},
               **{f"val_{k}": v for k, v in eval_epoch(model, val_dl, device, args).items()}}
        curves.append(row)
        print(f"época {epoch:3d}  V {row['train_v']:.4f}  Q {row['train_q']:.4f}  π {row['train_pi']:.4f}  "
              f"w medio {row['train_w_media']:.2f} (truncados {100 * row['train_w_truncados']:.1f} %)  "
              f"V(s0) {row['val_v0']:.3f}  ({time.time() - t0:.0f}s)")

        with open(out / "curvas.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(row))
            w.writeheader()
            w.writerows(curves)
        torch.save({"state_dict": model.state_dict(), "model_kwargs": model_kwargs, "epoch": epoch,
                    "reward": args.reward}, out / "modelo.pt")

    print(f"modelo final en {out / 'modelo.pt'}")


if __name__ == "__main__":
    main()
