import torch

from iql.modelo import IQL, Net, check_no_leak, expectile_loss, iql_losses


def _batch(n_items=50, B=8, T=20):
    items = torch.stack([torch.randperm(n_items)[:T] for _ in range(B)])
    return {"items": items, "ratings": torch.randint(1, 6, (B, T)).float(), "groups": torch.randint(0, 9, (B,))}


def test_no_leak():
    torch.manual_seed(0)
    net = Net(50, 50, d_model=32, hidden=32)
    b = _batch()
    for t in (0, 7, 19, 20):
        assert check_no_leak(net, b["items"], b["ratings"], b["groups"], t=t)


def test_expectile_matches_guide_table():
    # Q = 1, 2, 3, 10: el expectil 0,9 es 8 y el 0,5 es la media (4).
    q = torch.tensor([1.0, 2.0, 3.0, 10.0])
    for tau, expected in ((0.5, 4.0), (0.9, 8.0)):
        v = torch.zeros(1, requires_grad=True)
        opt = torch.optim.Adam([v], lr=0.05)
        for _ in range(3000):
            opt.zero_grad()
            expectile_loss(q - v, tau).backward()
            opt.step()
        assert abs(v.item() - expected) < 0.05


def test_gradients_do_not_mix():
    torch.manual_seed(0)
    model = IQL(50, d_model=16, hidden=16)
    losses = iql_losses(model, _batch(), gamma=0.9, tau=0.7, beta=3.0)
    for loss_name, own in (("v", "v"), ("q", "q"), ("pi", "pi")):
        model.zero_grad(set_to_none=True)
        losses[loss_name].backward(retain_graph=True)
        for net_name in ("q", "v", "pi"):
            has_grad = any(p.grad is not None and p.grad.abs().sum() > 0
                           for p in getattr(model, net_name).parameters())
            assert has_grad == (net_name == own), (loss_name, net_name)
        assert all(p.grad is None for p in model.q_target.parameters())


def test_last_step_is_terminal():
    # Con γ > 0, si el último paso bootstrapeara, cambiar V(s_T) cambiaría la pérdida de Q.
    torch.manual_seed(0)
    model = IQL(50, d_model=16, hidden=16)
    b = _batch()
    base = iql_losses(model, b, gamma=0.9, tau=0.7, beta=3.0)["q"]
    q_only = iql_losses(model, b, gamma=0.0, tau=0.7, beta=3.0)["q"]
    assert not torch.allclose(base, q_only)        # γ sí afecta a los pasos no terminales
    with torch.no_grad():
        v_all = model.v(b["items"], b["ratings"], b["groups"]).squeeze(-1)
    r = (b["ratings"] - 3) / 2
    q = model.q(b["items"], b["ratings"], b["groups"])[:, :20].gather(-1, b["items"].unsqueeze(-1)).squeeze(-1)
    target = r.clone()
    target[:, :-1] += 0.9 * v_all[:, 1:20]
    assert torch.allclose(base, torch.nn.functional.mse_loss(q, target), atol=1e-5)


def test_policy_scores_match_network_state():
    import numpy as np
    from iql.politica import IQLPolicy

    torch.manual_seed(0)
    model = IQL(50, d_model=16, hidden=16).eval()
    b = _batch(B=1)
    for mode, net in (("pi", model.pi), ("q", model.q)):
        pol = IQLPolicy(model, mode)
        pol.reset(int(b["groups"][0]), 20)
        for t in (0, 5):
            s = pol.scores(b["items"][0, :t].numpy(), b["ratings"][0, :t].numpy())
            assert s.shape == (50,) and np.isfinite(s).all()
            expected = net(b["items"], b["ratings"], b["groups"])[0, t]
            assert np.allclose(s, expected.detach().numpy(), atol=1e-5)
