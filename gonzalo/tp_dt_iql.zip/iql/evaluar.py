"""Evalúa modelos IQL con el protocolo común.

A diferencia del DT, τ, β y γ se fijan al entrenar: elegirlos requiere entrenar un modelo
por combinación y compararlos en validación.

  1. Validación: evalúa varias corridas (una por combinación de τ, β y γ, semilla 0) en modo
     "pi" y "q", y elige la configuración con mejor normalizado de π.
       python -m iql.evaluar --split val --run outputs/iql_netflix_random_g*_seed0

     Escribe <run>/eval/val/ para cada corrida y outputs/iql_{dataset}_{logs}_seleccion.json.

     La selección guarda tres variantes: "principal" (la mejor por π), "gamma0" (la mejor con
     γ = 0) y "gamma_pos" (la mejor con γ > 0). Una de las dos últimas coincide con la principal.

  2. Entrenar las semillas 1 y 2 de la principal y de la otra variante de γ (iql.entrenar).

  3. Test (una sola vez por variante): evalúa en las 4 condiciones, modos "pi" y "q". Se niega
     a correr si una corrida no coincide con la variante pedida.
       python -m iql.evaluar --split test --run outputs/iql_netflix_random_g0.9_t0.7_b3_seed{0,1,2}
       python -m iql.evaluar --split test --config gamma0 --run outputs/iql_netflix_random_g0_t0.9_b3_seed{0,1,2}

     Escribe <run>/eval/test/: sesiones.csv, resumen.csv, resumen_por_grupo.csv.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from protocolo.datos import load_test, load_train, num_items, split_by_user
from protocolo.evaluar import evaluate_grid, write_reports

from iql.politica import IQLPolicy, load_model

HORIZON = 20
WARMUPS = (0, 5)
VISIBILITY = (True, False)
HYPER = ("gamma", "tau", "beta", "reward", "max_weight")    # deben coincidir entre val y test


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--run", type=Path, nargs="+", required=True, help="carpetas de entrenamiento")
    p.add_argument("--split", choices=["val", "test"], required=True)
    p.add_argument("--seleccion", type=Path, default=None,
                   help="archivo de selección (default: outputs/iql_{dataset}_{logs}_seleccion.json)")
    p.add_argument("--config", default="principal", choices=["principal", "gamma0", "gamma_pos"],
                   help="en test: qué configuración de la selección se evalúa")
    p.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2], help="semillas de sesión en test")
    p.add_argument("--seeds-val", type=int, nargs="+", default=[0], help="semillas de sesión en validación")
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    return p.parse_args()


def read_config(run: Path) -> dict:
    return json.loads((run / "config.json").read_text())


def common_dataset_logs(runs: list[Path]) -> tuple[str, str]:
    keys = {(read_config(r)["dataset"], read_config(r)["logs"]) for r in runs}
    if len(keys) > 1:
        raise SystemExit(f"Las corridas mezclan datasets o logs distintos: {keys}")
    return keys.pop()


def factories_for(model, device):
    return {f"iql_{m}": (lambda m=m: IQLPolicy(model, m, device)) for m in ("pi", "q")}


def condition_table(df: pd.DataFrame, index: list[str]) -> pd.DataFrame:
    t = df.groupby(index + ["warmup", "group_visible"])["normalized"].mean().unstack(["warmup", "group_visible"])
    t.columns = [f"warmup{w}_{'visible' if v else 'oculto'}" for w, v in t.columns]
    t["media"] = t.mean(axis=1)
    return t


def run_val(runs: list[Path], dataset: str, logs: str, args) -> None:
    _, users = split_by_user(load_train(dataset))
    n_items = num_items(dataset)
    frames = []
    for i, run in enumerate(runs, 1):
        cfg = read_config(run)
        print(f"[val {i}/{len(runs)}] {run.name}: γ = {cfg['gamma']}, τ = {cfg['tau']}, β = {cfg['beta']}")
        df = evaluate_grid(factories_for(load_model(run, args.device), args.device), users, n_items,
                           horizon=HORIZON, warmups=WARMUPS, group_visibility=VISIBILITY,
                           seeds=tuple(args.seeds_val))
        write_reports(df, run / "eval" / "val")
        df["run"] = run.name
        for k in HYPER:
            df[k] = cfg[k]
        frames.append(df)

    all_df = pd.concat(frames, ignore_index=True)
    table = condition_table(all_df, ["run", "gamma", "tau", "beta", "policy"])
    pi_media = table.xs("iql_pi", level="policy")["media"]               # índice (run, gamma, tau, beta)
    gammas = pi_media.index.get_level_values("gamma")

    def variant(mask) -> dict | None:
        """Mejor corrida (por π) dentro de un subconjunto de configuraciones."""
        sub = pi_media[mask]
        if sub.empty:
            return None
        run_name = sub.idxmax()[0]
        cfg = read_config(next(r for r in runs if r.name == run_name))
        return {**{k: cfg[k] for k in HYPER}, "run": run_name, "normalizado_pi_val": round(float(sub.max()), 4)}

    variants = {"principal": variant(np.ones(len(pi_media), dtype=bool)),
                "gamma0": variant(gammas == 0),
                "gamma_pos": variant(gammas > 0)}
    variants = {k: v for k, v in variants.items() if v is not None}
    best = variants["principal"]
    best_q = table.xs("iql_q", level="policy")["media"].idxmax()[0]

    sel_path = args.seleccion or Path("outputs") / f"iql_{dataset}_{logs}_seleccion.json"
    sel_path.parent.mkdir(parents=True, exist_ok=True)
    table.reset_index().to_csv(sel_path.with_suffix(".csv"), index=False)
    sel_path.write_text(json.dumps({
        "dataset": dataset, "logs": logs,
        **{k: best[k] for k in HYPER},
        "run_elegida": best["run"],
        "criterio": "mayor normalizado medio de π (modo 'pi') en val, promedio simple de las 4 condiciones",
        "variantes": variants,
        "nota_variantes": "gamma0 y gamma_pos: mejor configuración dentro de γ = 0 y de γ > 0, para la "
                          "comparación γ = 0 frente a γ > 0 que pide la consigna (--config en test)",
        "mejor_run_en_modo_q": best_q,
        "seeds_sesion": args.seeds_val,
        "tabla": table.round(4).reset_index().to_dict(orient="records"),
    }, indent=2, ensure_ascii=False))

    with pd.option_context("display.width", 200):
        print(table.round(3).to_string())
    print(f"\n-> {sel_path}  (tabla completa en {sel_path.with_suffix('.csv')})")
    for name, v in variants.items():
        print(f"  {name:10s} γ = {v['gamma']}, τ = {v['tau']}, β = {v['beta']}  ({v['run']}, π en val {v['normalizado_pi_val']})")
    print("Siguiente paso: entrenar las semillas 1 y 2 de 'principal' y de la variante de γ que falte "
          "(gamma0 o gamma_pos), y correr --split test con --config.")


def run_test(runs: list[Path], dataset: str, logs: str, args) -> None:
    sel_path = args.seleccion or Path("outputs") / f"iql_{dataset}_{logs}_seleccion.json"
    if not sel_path.exists():
        raise SystemExit(f"Falta {sel_path}: correr primero --split val. τ, β y γ no se eligen en test.")
    sel = json.loads(sel_path.read_text())
    config = getattr(args, "config", "principal")
    variants = sel.get("variantes", {"principal": sel})
    if config not in variants:
        raise SystemExit(f"La selección no tiene la variante '{config}' (hay: {list(variants)}). "
                         "¿El barrido de val incluyó γ = 0 y γ > 0?")
    target = variants[config]
    for run in runs:
        cfg = read_config(run)
        bad = {k: (cfg[k], target[k]) for k in HYPER if cfg[k] != target[k]}
        if bad:
            raise SystemExit(f"{run.name} no coincide con la configuración '{config}' elegida en val: {bad}")

    users = load_test(dataset)
    n_items = num_items(dataset)
    for run in runs:
        print(f"[test] {run.name} ({config}): modos pi y q, 4 condiciones, semillas {args.seeds}")
        df = evaluate_grid(factories_for(load_model(run, args.device), args.device), users, n_items,
                           horizon=HORIZON, warmups=WARMUPS, group_visibility=VISIBILITY,
                           seeds=tuple(args.seeds))
        out = run / "eval" / "test"
        write_reports(df, out)
        (out / "seleccion_usada.json").write_text(json.dumps(
            {"seleccion": str(sel_path), "variante": config, **{k: target[k] for k in HYPER}}, indent=2))
        print(condition_table(df, ["policy"]).round(3).to_string())


def main() -> None:
    args = parse_args()
    dataset, logs = common_dataset_logs(args.run)
    (run_val if args.split == "val" else run_test)(args.run, dataset, logs, args)


if __name__ == "__main__":
    main()
