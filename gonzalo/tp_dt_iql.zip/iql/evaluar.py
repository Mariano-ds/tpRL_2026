"""Evalúa modelos IQL con el protocolo común.

A diferencia del DT, τ, β y γ se fijan al entrenar: elegirlos requiere entrenar un modelo
por combinación y compararlos en validación.

  1. Validación: evalúa varias corridas (una por combinación de τ, β y γ, semilla 0) en modo
     "pi" y "q", y elige la configuración con mejor normalizado de π.
       python -m iql.evaluar --split val --run outputs/iql_netflix_random_g*_seed0

     Escribe <run>/eval/val/ para cada corrida y outputs/iql_{dataset}_{logs}_seleccion.json.

  2. Entrenar las semillas 1 y 2 con la configuración elegida (iql.entrenar).

  3. Test (una sola vez): evalúa las corridas de la configuración elegida en las 4 condiciones,
     modos "pi" y "q". Se niega a correr si una corrida no coincide con la selección.
       python -m iql.evaluar --split test --run outputs/iql_netflix_random_g0.9_t0.7_b3_seed{0,1,2}

     Escribe <run>/eval/test/: sesiones.csv, resumen.csv, resumen_por_grupo.csv.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import torch

from protocolo.datos import load_test, load_train, num_items, split_by_user
from protocolo.evaluar import evaluate_grid, write_reports

from iql.politica import IQLPolicy, load_model

HORIZON = 20
WARMUPS = (0, 5)
VISIBILITY = (True, False)
HYPER = ("gamma", "tau", "beta", "reward", "max_weight")    # deben coincidir entre val y test


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--run", type=Path, nargs="+", required=True, help="carpetas de entrenamiento")
    p.add_argument("--split", choices=["val", "test"], required=True)
    p.add_argument("--seleccion", type=Path, default=None,
                   help="archivo de selección (default: outputs/iql_{dataset}_{logs}_seleccion.json)")
    p.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2], help="semillas de sesión en test")
    p.add_argument("--seeds-val", type=int, nargs="+", default=[0], help="semillas de sesión en validación")
    p.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    return p.parse_args()


def read_config(run: Path) -> dict:
    return json.loads((run / "config.json").read_text())


def common_dataset_logs(runs: list[Path]) -> tuple[str, str]:
    keys = {(read_config(r)["dataset"], read_config(r)["logs"]) for r in runs}
    if len(keys) > 1:
        raise SystemExit(f"Las corridas mezclan datasets o logs distintos: {keys}")
    return keys.pop()


def factories_for(model, device):
    return {f"iql_{m}": (lambda m=m: IQLPolicy(model, m, device)) for m in ("pi", "q")}


def condition_table(df: pd.DataFrame, index: list[str]) -> pd.DataFrame:
    t = df.groupby(index + ["warmup", "group_visible"])["normalized"].mean().unstack(["warmup", "group_visible"])
    t.columns = [f"warmup{w}_{'visible' if v else 'oculto'}" for w, v in t.columns]
    t["media"] = t.mean(axis=1)
    return t


def run_val(runs: list[Path], dataset: str, logs: str, args) -> None:
    _, users = split_by_user(load_train(dataset))
    n_items = num_items(dataset)
    frames = []
    for i, run in enumerate(runs, 1):
        cfg = read_config(run)
        print(f"[val {i}/{len(runs)}] {run.name}: γ = {cfg['gamma']}, τ = {cfg['tau']}, β = {cfg['beta']}")
        df = evaluate_grid(factories_for(load_model(run, args.device), args.device), users, n_items,
                           horizon=HORIZON, warmups=WARMUPS, group_visibility=VISIBILITY,
                           seeds=tuple(args.seeds_val))
        write_reports(df, run / "eval" / "val")
        df["run"] = run.name
        for k in HYPER:
            df[k] = cfg[k]
        frames.append(df)

    all_df = pd.concat(frames, ignore_index=True)
    table = condition_table(all_df, ["run", "gamma", "tau", "beta", "policy"])
    best = table.xs("iql_pi", level="policy")["media"].idxmax()     # (run, gamma, tau, beta)
    best_run = best[0]
    best_cfg = read_config(next(r for r in runs if r.name == best_run))
    best_q = table.xs("iql_q", level="policy")["media"].idxmax()[0]

    sel_path = args.seleccion or Path("outputs") / f"iql_{dataset}_{logs}_seleccion.json"
    sel_path.parent.mkdir(parents=True, exist_ok=True)
    table.reset_index().to_csv(sel_path.with_suffix(".csv"), index=False)
    sel_path.write_text(json.dumps({
        "dataset": dataset, "logs": logs,
        **{k: best_cfg[k] for k in HYPER},
        "run_elegida": best_run,
        "criterio": "mayor normalizado medio de π (modo 'pi') en val, promedio simple de las 4 condiciones",
        "mejor_run_en_modo_q": best_q,
        "seeds_sesion": args.seeds_val,
        "tabla": table.round(4).reset_index().to_dict(orient="records"),
    }, indent=2, ensure_ascii=False))

    with pd.option_context("display.width", 200):
        print(table.round(3).to_string())
    print(f"\nconfiguración elegida: γ = {best_cfg['gamma']}, τ = {best_cfg['tau']}, β = {best_cfg['beta']} "
          f"({best_run})\n-> {sel_path}  (tabla completa en {sel_path.with_suffix('.csv')})")
    print("Siguiente paso: entrenar las semillas 1 y 2 con esa configuración y correr --split test.")


def run_test(runs: list[Path], dataset: str, logs: str, args) -> None:
    sel_path = args.seleccion or Path("outputs") / f"iql_{dataset}_{logs}_seleccion.json"
    if not sel_path.exists():
        raise SystemExit(f"Falta {sel_path}: correr primero --split val. τ, β y γ no se eligen en test.")
    sel = json.loads(sel_path.read_text())
    for run in runs:
        cfg = read_config(run)
        bad = {k: (cfg[k], sel[k]) for k in HYPER if cfg[k] != sel[k]}
        if bad:
            raise SystemExit(f"{run.name} no coincide con la configuración elegida en val: {bad}")

    users = load_test(dataset)
    n_items = num_items(dataset)
    for run in runs:
        print(f"[test] {run.name}: modos pi y q, 4 condiciones, semillas {args.seeds}")
        df = evaluate_grid(factories_for(load_model(run, args.device), args.device), users, n_items,
                           horizon=HORIZON, warmups=WARMUPS, group_visibility=VISIBILITY,
                           seeds=tuple(args.seeds))
        out = run / "eval" / "test"
        write_reports(df, out)
        (out / "seleccion_usada.json").write_text(json.dumps({"seleccion": str(sel_path)}, indent=2))
        print(condition_table(df, ["policy"]).round(3).to_string())


def main() -> None:
    args = parse_args()
    dataset, logs = common_dataset_logs(args.run)
    (run_val if args.split == "val" else run_test)(args.run, dataset, logs, args)


if __name__ == "__main__":
    main()
