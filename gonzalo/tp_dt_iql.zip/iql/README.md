# IQL: entrenamiento y evaluación

> Para correr el barrido, la selección, las semillas y el test de forma automática y reanudable, ver `experimentos/README.md` (`python -m experimentos.correr_todo`).

Implementación mínima del entrenamiento y la evaluación de IQL del TP. Usa los mismos episodios de 20 pasos que el DT: reutiliza `load_episodes` de `dt/entrenar.py`, así que la carpeta `dt/` tiene que estar al lado.

## Archivos

| Archivo | Qué hace |
|---|---|
| `modelo.py` | Codificador de historial, redes Q, V y π, red objetivo Q̄, `expectile_loss`, `iql_losses` y `check_no_leak`. |
| `entrenar.py` | Script de entrenamiento: carga episodios, entrena las tres redes, actualiza Q̄ y guarda curvas y el modelo final. |
| `politica.py`, `evaluar.py` | Política y evaluación con el protocolo (ver más abajo). |
| (en `dt/`) | `repro.py` guarda el entorno en `config.json`; `reporte.py` arma las tablas; `curvas.py` grafica las curvas. |
| `tests/test_iql.py` | Tests: no fuga, expectil contra la tabla de la guía (Q = 1, 2, 3, 10 → 4 con τ = 0,5 y 8 con τ = 0,9), gradientes que no se mezclan, último paso terminal y puntajes de `IQLPolicy`. |

## Decisiones de diseño (declararlas en el informe)

- **Estado:** una GRU recorre [inicio, (a_0, r_0), …, (a_{T−1}, r_{T−1})] y devuelve T + 1 estados h_0 … h_T. A cada uno se le suma el embedding del grupo (8 = "desconocido") y el del paso. h_t sólo ve lo revelado antes de t.
- **Codificadores:** Q, V y π tienen cada una el suyo, así cada pérdida entrena sólo su red, codificador incluido. El test `test_gradients_do_not_mix` lo verifica.
- **Recompensa:** centrada por defecto, (r − 3) / 2. Con `--reward raw` se usa cruda. Cambia la escala de Q, V y las ventajas, y por lo tanto el efecto de β.
- **Pérdidas:** son las de la sección 5.3 de la guía.
  - V: regresión de expectil contra Q̄(s, a).
  - Q: objetivo TD r + γ · V(s'). En el último paso es sólo r, porque es terminal.
  - π: cross-entropy ponderada por exp(β · (Q̄ − V)), sin gradiente y truncada en `--max-weight`. Los ítems ya mostrados se enmascaran.
- **Red objetivo:** Q̄ se actualiza con Polyak después de cada paso de optimización (`--polyak 0.005`).
- **Grupo oculto:** como en el DT, el grupo se reemplaza por "desconocido" en el 30 % de los episodios de train (`--p-hide`).
- **Checkpoint:** se guarda el modelo **final**. Las pérdidas de Q y π no miden la calidad de la política: τ, β y γ se eligen con el protocolo en validación.

## Cómo correrlo

Desde `2026/tp`:

```bash
python -m pytest iql/tests
python -m iql.entrenar --dataset netflix --logs random --seed 0
```

Barrido de la guía (sección 5.8), para una semilla:

```bash
for g in 0 0.9; do for t in 0.7 0.9; do for b in 3 10; do
  python -m iql.entrenar --dataset netflix --logs random --gamma $g --tau $t --beta $b --seed 0
done; done; done
```

Cada combinación se guarda en su propia carpeta: `outputs/iql_{dataset}_{logs}_g{γ}_t{τ}_b{β}_seed{seed}/`. Una vez elegida la configuración en validación, se entrena con las semillas 1 y 2.

Argumentos principales:

| Argumento | Default | Descripción |
|---|---|---|
| `--gamma` | `0.9` | descuento; `0` = bandit contextual |
| `--tau` | `0.7` | expectil de V |
| `--beta` | `3.0` | temperatura inversa de AWR |
| `--max-weight` | `100` | truncado de los pesos de AWR |
| `--reward` | `centered` | `centered` o `raw` |
| `--epochs`, `--batch-size`, `--lr` | `20`, `256`, `3e-4` | entrenamiento (Adam, uno por red) |
| `--d-model`, `--hidden` | `128`, `256` | tamaño de la GRU y del MLP |

## Salidas

| Archivo | Contenido |
|---|---|
| `modelo.pt` | `state_dict` de Q, V, π y Q̄, `model_kwargs` y el modo de recompensa |
| `config.json` | argumentos, decisiones de diseño y `entorno`: versiones, GPU, commit, comando y huella del código |
| `curvas.csv` | por época, en train y val: pérdidas de V, Q y π; peso medio de AWR y fracción truncada; media y desvío de las ventajas; V(s_0) medio y Q medio |

**Qué mirar en las curvas** (sección 5.6 de la guía):
- Si `w_truncados` es alto, β es demasiado grande para la escala de las ventajas.
- Si `w_media` queda cerca de 1, π es casi behavior cloning.
- Que las pérdidas de Q o π suban no indica un error.

## Evaluación con el protocolo

| Archivo | Qué hace |
|---|---|
| `politica.py` | `IQLPolicy(model, mode)`: adapta el modelo a la interfaz `reset` / `scores`. Codifica el historial de la sesión y devuelve, para el estado actual h_t, las logits de π (`mode="pi"`) o los valores Q(s, a) de todos los ítems (`mode="q"`, el máximo de Q que IQL evita al entrenar). `load_model` carga `modelo.pt`. |
| `evaluar.py` | `--split val` compara varias corridas y elige τ, β y γ. `--split test` evalúa la configuración elegida **una sola vez**. |

A diferencia del DT, los hiperparámetros de IQL se fijan al entrenar. Elegirlos requiere **un modelo por combinación**, y la selección se hace comparando esos modelos en validación.

### Paso 1: barrido de entrenamiento (semilla 0)

```bash
for g in 0 0.9; do for t in 0.7 0.9; do for b in 3 10; do
  python -m iql.entrenar --dataset netflix --logs random --gamma $g --tau $t --beta $b --seed 0
done; done; done
```

### Paso 2: validación (elige τ, β y γ)

```bash
python -m iql.evaluar --split val --run outputs/iql_netflix_random_g*_seed0
```

- Evalúa cada corrida en los modos `pi` y `q`, en las 4 condiciones (warm-up 0 y 5, grupo visible y oculto), sobre los usuarios de validación. Por defecto usa una semilla de sesión (`--seeds-val 0`).
- **Criterio:** se elige la corrida con mayor `normalized` medio **de π**, como promedio simple de las 4 condiciones. El modo `q` se reporta con la misma configuración, para comparar las dos formas de recomendar con el mismo modelo. Igual se anota en el archivo cuál sería la mejor corrida si se eligiera por `q`.
- Escribe `<run>/eval/val/` para cada corrida y además `outputs/iql_{dataset}_{logs}_seleccion.json` y `.csv`, con la tabla de todas las corridas.
- **Tres variantes en la selección:** para la comparación γ = 0 frente a γ > 0 que pide la consigna, el archivo guarda tres variantes. Una de las dos últimas coincide con `principal`.
  - `principal`: la mejor por π;
  - `gamma0`: la mejor con γ = 0;
  - `gamma_pos`: la mejor con γ > 0.

### Paso 3: semillas 1 y 2 de las dos variantes de γ

La consigna pide un modelo final con 3 semillas y la comparación γ = 0 frente a γ > 0. Se entrenan las semillas 1 y 2 de `principal` y de la otra variante de γ. Los hiperparámetros salen de `seleccion.json`.

```bash
# ejemplo: principal = gamma_pos (γ = 0.9, τ = 0.7, β = 3) y gamma0 = (γ = 0, τ = 0.9, β = 3)
for s in 1 2; do
  python -m iql.entrenar --dataset netflix --logs random --gamma 0.9 --tau 0.7 --beta 3 --seed $s
  python -m iql.entrenar --dataset netflix --logs random --gamma 0   --tau 0.9 --beta 3 --seed $s
done
```

### Paso 4: test (una sola vez por variante)

```bash
python -m iql.evaluar --split test                   --run outputs/iql_netflix_random_g0.9_t0.7_b3_seed{0,1,2}
python -m iql.evaluar --split test --config gamma0   --run outputs/iql_netflix_random_g0_t0.9_b3_seed{0,1,2}
```

- `--config` elige qué variante de la selección se evalúa: `principal` (el valor por defecto), `gamma0` o `gamma_pos`.
- Si falta el archivo de selección, se niega a correr. También se niega si alguna corrida tiene τ, β, γ, recompensa o `max_weight` distintos de los de esa variante.
- Evalúa los modos `pi` y `q` en las 4 condiciones, con las semillas de sesión 0, 1 y 2. El resultado va a `<run>/eval/test/`, y en `seleccion_usada.json` se anota qué variante se usó.

### Paso 5: tablas finales, junto con el DT y las líneas base

```bash
python -m dt.reporte \
    --runs outputs/dt_netflix_random_seed{0,1,2} \
    --iql  outputs/iql_netflix_random_g0.9_t0.7_b3_seed{0,1,2} \
    --iql  outputs/iql_netflix_random_g0_t0.9_b3_seed{0,1,2} \
    --baselines outputs/baselines_netflix \
    --output outputs/reporte_netflix_random
```

- **Un `--iql` por configuración.** Cada uno agrega dos filas: "IQL π" e "IQL, máximo de Q", con γ, τ y β en el nombre. Si un mismo `--iql` mezcla configuraciones, el script aborta.
- **Métricas:** las tablas incluyen el normalizado, hit rate, NDCG@10 y precision@10, con el desvío entre semillas y el IC 95 % por usuario, más la tabla por grupo. Ver "Paso 4" en `dt/README.md`.
- `--runs` del DT es opcional.

### Curvas de entrenamiento

```bash
python -m dt.curvas --runs outputs/iql_netflix_random_g0.9_t0.7_b3_seed{0,1,2} --output outputs/reporte_netflix_random
```

`curvas_iql.png` muestra, con train en línea sólida y validación en punteada:
- las pérdidas de V, Q y π;
- el peso medio de AWR, con la referencia 1 = behavior cloning, y la fracción de pesos truncados;
- el desvío de las ventajas, V(s₀) medio y Q medio.

Hay una línea por semilla. Sirve para el diagnóstico de la sección 5.6 de la guía.

Para los logs `mixto`, repetir todo cambiando `--logs mixto`. La selección queda en otro archivo, `iql_netflix_mixto_seleccion.json`.
