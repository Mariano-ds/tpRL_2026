# IQL: entrenamiento

Implementación mínima del entrenamiento de IQL del TP. Usa los mismos episodios de 20 pasos que el DT: reutiliza `load_episodes` de `dt/entrenar.py`, así que la carpeta `dt/` tiene que estar al lado.

## Archivos

| Archivo | Qué hace |
|---|---|
| `modelo.py` | Codificador de historial, redes Q, V y π, red objetivo Q̄, `expectile_loss`, `iql_losses` y `check_no_leak`. |
| `entrenar.py` | Script de entrenamiento: carga episodios, entrena las tres redes, actualiza Q̄ y guarda curvas y el modelo final. |
| `tests/test_iql.py` | Tests: no fuga, expectil contra la tabla de la guía (Q = 1, 2, 3, 10 → 4 con τ = 0,5 y 8 con τ = 0,9), gradientes que no se mezclan y último paso terminal. |

## Decisiones de diseño (declararlas en el informe)

- **Estado:** una GRU recorre [inicio, (a_0, r_0), …, (a_{T−1}, r_{T−1})] y devuelve T + 1 estados h_0 … h_T. A cada uno se le suma el embedding del grupo (8 = "desconocido") y el del paso. h_t sólo ve lo revelado antes de t.
- **Codificadores:** Q, V y π tienen cada una el suyo, así cada pérdida entrena sólo su red, codificador incluido. El test `test_gradients_do_not_mix` lo verifica.
- **Recompensa:** centrada por defecto, (r − 3) / 2. Con `--reward raw` se usa cruda. Cambia la escala de Q, V y las ventajas, y por lo tanto el efecto de β.
- **Pérdidas:** son las de la sección 5.3 de la guía.
  - V: regresión de expectil contra Q̄(s, a).
  - Q: objetivo TD r + γ · V(s'). En el último paso es sólo r, porque es terminal.
  - π: cross-entropy ponderada por exp(β · (Q̄ − V)), sin gradiente y truncada en `--max-weight`. Los ítems ya mostrados se enmascaran.
- **Red objetivo:** Q̄ se actualiza con Polyak después de cada paso de optimización (`--polyak 0.005`).
- **Grupo oculto:** como en el DT, el grupo se reemplaza por "desconocido" en el 30 % de los episodios de train (`--p-hide`).
- **Checkpoint:** se guarda el modelo **final**. Las pérdidas de Q y π no miden la calidad de la política: τ, β y γ se eligen con el protocolo en validación.

## Cómo correrlo

Desde `2026/tp`:

```bash
python -m pytest iql/tests
python -m iql.entrenar --dataset netflix --logs random --seed 0
```

Barrido de la guía (sección 5.8), para una semilla:

```bash
for g in 0 0.9; do for t in 0.7 0.9; do for b in 3 10; do
  python -m iql.entrenar --dataset netflix --logs random --gamma $g --tau $t --beta $b --seed 0
done; done; done
```

Cada combinación se guarda en su propia carpeta: `outputs/iql_{dataset}_{logs}_g{γ}_t{τ}_b{β}_seed{seed}/`. Una vez elegida la configuración en validación, se entrena con las semillas 1 y 2.

Argumentos principales:

| Argumento | Default | Descripción |
|---|---|---|
| `--gamma` | `0.9` | descuento; `0` = bandit contextual |
| `--tau` | `0.7` | expectil de V |
| `--beta` | `3.0` | temperatura inversa de AWR |
| `--max-weight` | `100` | truncado de los pesos de AWR |
| `--reward` | `centered` | `centered` o `raw` |
| `--epochs`, `--batch-size`, `--lr` | `20`, `256`, `3e-4` | entrenamiento (Adam, uno por red) |
| `--d-model`, `--hidden` | `128`, `256` | tamaño de la GRU y del MLP |

## Salidas

| Archivo | Contenido |
|---|---|
| `modelo.pt` | `state_dict` de Q, V, π y Q̄, `model_kwargs` y el modo de recompensa |
| `config.json` | argumentos y decisiones de diseño |
| `curvas.csv` | por época, en train y val: pérdidas de V, Q y π; peso medio de AWR y fracción truncada; media y desvío de las ventajas; V(s_0) medio y Q medio |

**Qué mirar en las curvas** (sección 5.6 de la guía):
- Si `w_truncados` es alto, β es demasiado grande para la escala de las ventajas.
- Si `w_media` queda cerca de 1, π es casi behavior cloning.
- Que las pérdidas de Q o π suban no indica un error.

## Pendiente

`IQLPolicy`, con los modos `pi` y `q`, y la evaluación con el protocolo.
