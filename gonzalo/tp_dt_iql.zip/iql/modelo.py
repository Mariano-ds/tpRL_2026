"""IQL mínimo: codificador de historial, redes Q, V y π, y pérdidas.

Decisiones de diseño (declararlas en el informe):

- Q, V y π tienen cada una su propio codificador. Así cada pérdida entrena sólo su red
  (incluido su codificador) y los gradientes no se mezclan.
- Codificador: GRU sobre [inicio, (a_0, r_0), ..., (a_{T-1}, r_{T-1})], que devuelve T + 1
  estados h_0..h_T. A cada h_k se le suma el embedding del grupo (8 = "desconocido") y el
  del paso k. h_t sólo depende de lo revelado antes de t (causal por construcción).
- Recompensa centrada por defecto: (r − 3) / 2.
- Los ítems ya mostrados se enmascaran en π (y en el máximo de Q al recomendar).
"""

from __future__ import annotations

import copy

import torch
import torch.nn as nn
import torch.nn.functional as F

from dt.modelo import N_GROUPS, UNKNOWN_GROUP, seen_before_mask  # noqa: F401  (UNKNOWN_GROUP se reexporta)


class HistoryEncoder(nn.Module):
    """(items, ratings, groups) de T pasos -> T + 1 estados (B, T + 1, d)."""

    def __init__(self, n_items: int, horizon: int = 20, d_model: int = 128):
        super().__init__()
        self.item_emb = nn.Embedding(n_items, d_model)
        self.rating_emb = nn.Embedding(6, d_model)            # 1..5 (0 sin uso)
        self.start = nn.Parameter(torch.zeros(1, 1, d_model))
        self.gru = nn.GRU(d_model, d_model, batch_first=True)
        self.group_emb = nn.Embedding(N_GROUPS + 1, d_model)
        self.step_emb = nn.Embedding(horizon + 1, d_model)    # pasos 0..T
        self.ln = nn.LayerNorm(d_model)

    def forward(self, items: torch.Tensor, ratings: torch.Tensor, groups: torch.Tensor) -> torch.Tensor:
        B, T = items.shape
        r = ratings.round().clamp(1, 5).long()
        x = self.item_emb(items) + self.rating_emb(r)                          # (B, T, d)
        x = torch.cat([self.start.expand(B, 1, -1), x], dim=1)                 # (B, T + 1, d)
        h, _ = self.gru(x)                                                     # h_k ve inicio, pares 0..k-1
        steps = torch.arange(T + 1, device=items.device)
        return self.ln(h + self.group_emb(groups)[:, None] + self.step_emb(steps)[None])


class Net(nn.Module):
    """Codificador propio + MLP. out_dim = n_items (Q o π) o 1 (V)."""

    def __init__(self, n_items: int, out_dim: int, horizon: int = 20, d_model: int = 128, hidden: int = 256):
        super().__init__()
        self.encoder = HistoryEncoder(n_items, horizon, d_model)
        self.head = nn.Sequential(nn.Linear(d_model, hidden), nn.GELU(), nn.Linear(hidden, out_dim))

    def forward(self, items, ratings, groups) -> torch.Tensor:
        """(B, T + 1, out_dim): salida para cada uno de los T + 1 estados."""
        return self.head(self.encoder(items, ratings, groups))


class IQL(nn.Module):
    def __init__(self, n_items: int, horizon: int = 20, d_model: int = 128, hidden: int = 256):
        super().__init__()
        self.n_items, self.horizon = n_items, horizon
        self.q = Net(n_items, n_items, horizon, d_model, hidden)
        self.v = Net(n_items, 1, horizon, d_model, hidden)
        self.pi = Net(n_items, n_items, horizon, d_model, hidden)
        self.q_target = copy.deepcopy(self.q).requires_grad_(False)

    @torch.no_grad()
    def update_target(self, lam: float = 0.005) -> None:
        for p_t, p in zip(self.q_target.parameters(), self.q.parameters()):
            p_t.lerp_(p, lam)                                   # Q̄ ← (1 − λ) Q̄ + λ Q


def expectile_loss(diff: torch.Tensor, tau: float) -> torch.Tensor:
    """diff = Q_obj − V. Con tau > 0,5 penaliza más diff > 0 (V por debajo de Q)."""
    weight = torch.where(diff < 0, 1.0 - tau, tau)
    return (weight * diff.pow(2)).mean()


def centered_reward(ratings: torch.Tensor, mode: str = "centered") -> torch.Tensor:
    return (ratings - 3.0) / 2.0 if mode == "centered" else ratings


def iql_losses(model: IQL, batch: dict, gamma: float, tau: float, beta: float,
               max_weight: float = 100.0, reward: str = "centered") -> dict:
    items, ratings, groups = batch["items"], batch["ratings"], batch["groups"]   # (B, T), (B, T), (B,)
    B, T = items.shape
    r = centered_reward(ratings, reward)
    not_done = torch.ones_like(r)
    not_done[:, -1] = 0.0                                        # el último paso es terminal
    idx = items.unsqueeze(-1)

    with torch.no_grad():
        q_obj = model.q_target(items, ratings, groups)[:, :T].gather(-1, idx).squeeze(-1)   # (B, T)

    v_all = model.v(items, ratings, groups).squeeze(-1)                                    # (B, T + 1)
    loss_v = expectile_loss(q_obj - v_all[:, :T], tau)

    q = model.q(items, ratings, groups)[:, :T].gather(-1, idx).squeeze(-1)                 # (B, T)
    td_target = r + gamma * not_done * v_all[:, 1:].detach()
    loss_q = F.mse_loss(q, td_target)

    with torch.no_grad():
        adv = q_obj - v_all[:, :T]
        weights = torch.exp(beta * adv).clamp(max=max_weight)
    logits = model.pi(items, ratings, groups)[:, :T]
    logits = logits.masked_fill(seen_before_mask(items, model.n_items), float("-inf"))
    nll = F.cross_entropy(logits.reshape(-1, model.n_items), items.reshape(-1), reduction="none")
    loss_pi = (weights.reshape(-1) * nll).mean()

    return {"v": loss_v, "q": loss_q, "pi": loss_pi,
            # diagnósticos (sin gradiente)
            "w_media": weights.mean().detach(), "w_truncados": (weights >= max_weight).float().mean(),
            "adv_media": adv.mean(), "adv_desvio": adv.std(), "v0": v_all[:, 0].mean().detach(),
            "q_media": q.mean().detach()}


@torch.no_grad()
def check_no_leak(net: Net, items, ratings, groups, t: int = 7, atol: float = 1e-5) -> bool:
    """La salida del estado h_t no debe cambiar si se alteran (a_k, r_k) para k ≥ t."""
    was_training = net.training
    net.eval()
    base = net(items, ratings, groups)[:, t]
    items2, ratings2 = items.clone(), ratings.clone()
    items2[:, t:] = torch.randint(0, items.max().item() + 1, items2[:, t:].shape, device=items.device)
    ratings2[:, t:] = torch.randint(1, 6, ratings2[:, t:].shape, device=ratings.device).float()
    out = net(items2, ratings2, groups)[:, t]
    net.train(was_training)
    return torch.allclose(base, out, atol=atol)
