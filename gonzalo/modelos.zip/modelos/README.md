# `modelos/` — DT, IQL y experimentos con el protocolo común

Código del grupo. Usa `protocolo/` sin modificarlo: partición `split_by_user`,
episodios `make_episodes` / `logged_episodes`, sesiones `protocolo.evaluar.evaluate`
y reportes `write_reports`. Todo se ejecuta desde `2026/tp` con el entorno activado
(`source /workspace/.venv/bin/activate`).

| Archivo | Contenido |
|---|---|
| `comun.py` | carga de datos por tipo de logs, lotes, *group dropout*, `seen_before_mask`, semillas, rutas |
| `dt.py` | `DecisionTransformer`, `dt_loss`, `DTPolicy` |
| `iql.py` | codificador GRU, `IQLModel` (Q, Q̄, V, π), `expectile_loss`, `iql_losses`, `IQLPolicy` (`pi` / `q`) |
| `entrenar.py` | entrenamiento de un modelo con config, curvas y checkpoint |
| `evaluar_modelo.py` | evaluación con el protocolo (val o test): líneas base de a una sesión, DT/IQL por lotes |
| `evaluar_lotes.py` | evaluador por lotes (GPU si hay), equivalente a `protocolo.evaluar.evaluate` |
| `empaquetar.py` | genera `modelos.zip` para Colab |
| `experimentos.py` | barridos en validación y corridas finales con 3 semillas |
| `reporte.py` | tabla final, return conditioning, comparación de logs, curvas |
| `tests/` | no fuga del DT, alineación política/entrenamiento, expectil, gradientes separados, paso terminal, equivalencia del evaluador por lotes con el protocolo |

## Flujo completo

```bash
python -m pytest modelos/tests protocolo/tests

# Logs originales (uniformes)
python -m modelos.experimentos barrido-dt  --dataset netflix --logs random   # R̂ pedido, en val
python -m modelos.experimentos barrido-iql --dataset netflix --logs random   # τ, β, γ, en val
python -m modelos.experimentos final       --dataset netflix --logs random   # 3 semillas, test
python -m modelos.reporte rc               --dataset netflix --logs random   # return conditioning

# Logs "mixto": mismos hiperparámetros de IQL; R̂ pedido elegido en val con estos logs
python -m modelos.experimentos barrido-dt --dataset netflix --logs mixto
python -m modelos.experimentos final      --dataset netflix --logs mixto --hp-de random
python -m modelos.reporte logs            --dataset netflix

python -m modelos.reporte curvas outputs/modelos/netflix_*/dt/base/seed* outputs/modelos/netflix_*/iql/*/seed*
```

Cada paso reutiliza los checkpoints y evaluaciones que ya existen, así que se
puede interrumpir y retomar. Para probar la cadena en minutos:
`TP_OUTPUTS=/tmp/prueba ... --epochs 1 --max-episodes 1000 --max-users 40`.

## Evaluación por lotes

`protocolo.evaluar.evaluate` corre una sesión por vez y llama al modelo con lote 1
en cada paso. `evaluar_lotes.evaluate_batch` crea las mismas sesiones (una por
semilla de sesión y usuario, cada una con su generador `default_rng([seed, índice])`),
las avanza sincronizadas y en cada paso calcula los puntajes de todas juntas con
una sola llamada al modelo. Cada sesión sigue eligiendo con `simulador.choose`
sobre su máscara, y las métricas se calculan con las funciones del protocolo.
Los tests verifican que el resultado coincide con `evaluate` (exacto con líneas
base; con DT/IQL, mismas recomendaciones y retornos, NDCG igual salvo redondeo de float32).

Es el camino por defecto para DT e IQL (`--device auto` usa GPU si hay;
`--no-batch` vuelve al camino original). Las líneas base siguen con `evaluate`:
`random` consume su generador en el orden de las sesiones.

## Google Colab (GPU y resultados en Drive)

1. Entorno de ejecución con GPU. No reinstalar `torch`: Colab ya lo trae con CUDA.
2. Clonar el repositorio del TP, descargar `modelos.zip` y descomprimirlo en `2026/tp`:
   `unzip -o modelos.zip -d 2026/tp`.
3. Montar Drive y definir `TP_OUTPUTS=/content/drive/MyDrive/<carpeta>/outputs/modelos`.
   Checkpoints, evaluaciones, tablas y la caché de logs `mixto` (en `<carpeta>/outputs/logs`)
   quedan en Drive; si la sesión se corta, volver a ejecutar el mismo comando retoma.
4. Ejecutar desde `2026/tp` los comandos del flujo completo. Entrenamiento y evaluación
   de DT/IQL usan la GPU automáticamente.

Para regenerar el ZIP después de un cambio: `python -m modelos.empaquetar`.

## Salidas (`outputs/modelos/<dataset>_<logs>/`)

- `dt/base/seed<k>/`, `iql/g<γ>_t<τ>_b<β>/seed<k>/`: `config.json` (argumentos, versiones,
  soporte de retornos de train), `curvas.csv`, `curvas_pasos.csv`, `checkpoint.pt`, `ultimo.pt`.
- `barridos/dt|iql/`: evaluación en val, `puntajes.csv` y `elegido.json`.
- `final/test/lineas_base/`, `final/test/seed<k>/`: `sesiones.csv`, `resumen.csv`, `resumen_por_grupo.csv`.
- `final/tabla_normalized.md`, `tabla_larga.csv`, `tabla_por_grupo.csv`: media entre semillas de
  entrenamiento, desvío entre semillas e IC 95 % por usuario, por separado.
- `final/return_conditioning*.png|csv`: retorno pedido frente a obtenido, agregado y por grupo.

## Decisiones de diseño (a justificar en el reporte)

- **Episodios**: tramos de 20 pasos; R̂ dentro del episodio. DT e IQL usan los mismos.
- **Grupo oculto**: en el 30 % de los episodios de train el grupo se reemplaza por
  "desconocido" (`--group-dropout`), en ambos modelos.
- **DT**: tokens intercalados (R̂_t, s_t, a_t); s_t = grupo + rating del paso anterior;
  a_t se predice desde la salida de s_t; máscara causal 3T × 3T; sin padding; salida
  con pesos compartidos con los embeddings de ítems; ítems ya vistos enmascarados.
  Checkpoint con menor cross-entropy en val. `dropout = 0` por costo en CPU.
- **IQL**: un codificador GRU por red (Q, V, π), así cada pérdida entrena sólo su red;
  recompensa (r − 3)/2; último paso terminal; red objetivo Q̄ con Polyak 0,005;
  pesos AWR truncados en 100. Se guarda el último checkpoint: las pérdidas no miden la
  calidad, y la configuración se elige con el protocolo en val.
- **Selección**: media de `normalized` en las cuatro condiciones en val (semilla de sesión 0).
  Test se usa una sola vez, en `final`.

## Costo aproximado

En CPU de 8 hilos (medido): DT ≈ 3 min por época (≈ 30 min por semilla), IQL ≈ 1,5 min
por época (≈ 15 min por configuración). Evaluación por lotes en CPU, 1600 sesiones por
condición: DT ≈ 19 s e IQL ≈ 2,7 s (de a una sesión eran ≈ 120 s y ≈ 50 s).

En GPU el entrenamiento y la parte del modelo en la evaluación son mucho más rápidos;
lo que queda es el bucle de Python de las sesiones (≈ 1–3 s por cada 1600 sesiones y
condición) y las líneas base, que corren en CPU.
