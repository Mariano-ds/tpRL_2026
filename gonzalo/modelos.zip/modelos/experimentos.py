"""Experimentos del TP: barridos en validación y corridas finales en test.

Uso, desde `2026/tp` (cada paso reutiliza los checkpoints que ya existen):

    # 1. Barridos en validación (semilla de entrenamiento 0)
    python -m modelos.experimentos barrido-dt  --dataset netflix --logs random
    python -m modelos.experimentos barrido-iql --dataset netflix --logs random

    # 2. Corridas finales: 3 semillas de entrenamiento, evaluación en test una sola vez
    python -m modelos.experimentos final --dataset netflix --logs random

    # 3. Calidad de los logs: mismos pasos con logs "mixto". Por defecto, los
    #    hiperparámetros de IQL se toman del barrido con logs "random" (--hp-de)
    #    y el retorno pedido del DT se elige en validación con los logs "mixto".
    python -m modelos.experimentos barrido-dt --dataset netflix --logs mixto
    python -m modelos.experimentos final      --dataset netflix --logs mixto --hp-de random

Criterio de selección en validación: media de `normalized` sobre las cuatro
condiciones (warm-up 0/5 × grupo visible/oculto). Para IQL se selecciona con
la política π; el máximo de Q se reporta como comparación.

Salidas en `outputs/modelos/<dataset>_<logs>/`:
    dt/base/seed<k>/, iql/<g_t_b>/seed<k>/     corridas (config, curvas, checkpoint)
    barridos/dt/, barridos/iql/                evaluación en val y `elegido.json`
    final/test/seed<k>/, final/test/lineas_base/   evaluación en test
"""

from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd

from .comun import load_json, run_dir, save_json
from .entrenar import DEFAULTS, entrenar, tag_de
from .evaluar_modelo import default_workers, evaluar_politicas, specs_dt, specs_iql, specs_lineas_base

CONDICIONES = ["warmup", "group_visible"]


MAX_EPISODES: int | None = None  # sólo para pruebas rápidas (--max-episodes)
DEVICE = "auto"  # entrenamiento y evaluación de DT/IQL: GPU si hay (--device)


def asegurar_entrenado(modelo: str, dataset: str, logs: str, seed: int, epochs: int | None = None,
                       **hp) -> Path:
    cfg = {"modelo": modelo, "dataset": dataset, "logs": logs, "seed": seed, "epochs": epochs,
           "max_episodes": MAX_EPISODES, "device": DEVICE, **hp}
    full = {**DEFAULTS[modelo], **{k: v for k, v in cfg.items() if v is not None}}
    run = run_dir(dataset, logs, modelo, tag_de(full), f"seed{seed}")
    if (run / "checkpoint.pt").exists() and (run / "curvas.csv").exists():
        done = pd.read_csv(run / "curvas.csv")["epoch"].max()
        if done >= full["epochs"]:
            print(f"Reutilizo {run}")
            return run
    print(f"Entreno {run}", flush=True)
    return entrenar({**cfg, "output": str(run)})


def puntaje_por_politica(results: pd.DataFrame) -> pd.DataFrame:
    """normalized medio por política y condición (usuarios promediados entre semillas de sesión)."""
    per_user = results.groupby(["policy", *CONDICIONES, "user_id"])["normalized"].mean()
    by_cond = per_user.groupby(["policy", *CONDICIONES]).mean().unstack(CONDICIONES)
    by_cond.columns = [f"w{w}_{'vis' if v else 'oculto'}" for w, v in by_cond.columns]
    by_cond["promedio"] = by_cond.mean(axis=1)
    return by_cond.sort_values("promedio", ascending=False)


def targets_barrido(support: dict) -> list[float]:
    """Percentiles del retorno de train, el máximo y dos valores fuera del soporte."""
    pts = [support[k] for k in ("p10", "p25", "p50", "p75", "p90", "p99")] + [support["max"]]
    pts += [support["max"] + 10, support["max"] + 20]
    return sorted({round(float(x), 1) for x in pts})


# --- barridos -----------------------------------------------------------------------------

def barrido_dt(args) -> dict:
    run = asegurar_entrenado("dt", args.dataset, args.logs, 0, args.epochs)
    support = load_json(run / "config.json")["train_return_support"]
    targets = args.targets or targets_barrido(support)
    out = run_dir(args.dataset, args.logs, "barridos", "dt")
    res = evaluar_politicas(specs_dt(run, targets), args.dataset, args.logs, "val", out / "eval",
                            seeds=args.seeds, workers=args.workers, device=args.device, max_users=args.max_users)
    tabla = puntaje_por_politica(res)
    tabla.to_csv(out / "puntajes.csv")
    best_name = tabla.index[0]
    best = float(best_name.split("_R")[1])
    elegido = {"target": best, "targets": targets, "train_return_support": support,
               "dentro_del_soporte": best <= support["max"], "criterio": "max normalized promedio en val",
               "run": str(run)}
    save_json(elegido, out / "elegido.json")
    print(tabla.round(3).to_string(), f"\nRetorno pedido elegido: {best}", sep="\n")
    return elegido


def barrido_iql(args) -> dict:
    out = run_dir(args.dataset, args.logs, "barridos", "iql")
    specs, configs = [], {}
    for gamma, tau, beta in itertools.product(args.gammas, args.taus, args.betas):
        hp = {"gamma": gamma, "tau": tau, "beta": beta}
        run = asegurar_entrenado("iql", args.dataset, args.logs, 0, args.epochs, **hp)
        tag = run.parent.name
        configs[tag] = hp
        specs += specs_iql(run, ("pi", "q"), prefix=f"iql_{tag}")
    res = evaluar_politicas(specs, args.dataset, args.logs, "val", out / "eval",
                            seeds=args.seeds, workers=args.workers, device=args.device, max_users=args.max_users)
    tabla = puntaje_por_politica(res)
    tabla.to_csv(out / "puntajes.csv")
    pi = tabla[tabla.index.str.endswith("_pi")]
    tag_of = lambda name: name[len("iql_"):-len("_pi")]  # noqa: E731
    best = configs[tag_of(pi.index[0])]
    por_gamma = {}
    for gamma in args.gammas:
        rows = [n for n in pi.index if configs[tag_of(n)]["gamma"] == gamma]
        por_gamma[str(gamma)] = configs[tag_of(rows[0])]
    elegido = {"best": best, "best_por_gamma": por_gamma, "criterio": "max normalized promedio en val (π)",
               "grilla": {"gamma": args.gammas, "tau": args.taus, "beta": args.betas}}
    save_json(elegido, out / "elegido.json")
    print(tabla.round(3).to_string(), f"\nElegido: {best}", sep="\n")
    return elegido


# --- corridas finales ----------------------------------------------------------------------

def final(args) -> None:
    hp_logs = args.hp_de or args.logs
    iql_sel = run_dir(args.dataset, hp_logs, "barridos", "iql", "elegido.json")
    dt_sel = run_dir(args.dataset, args.logs, "barridos", "dt", "elegido.json")
    if not iql_sel.exists():
        raise SystemExit(f"Falta {iql_sel}: correr antes `barrido-iql --logs {hp_logs}`")
    if args.dt_target is None and not dt_sel.exists():
        raise SystemExit(f"Falta {dt_sel}: correr antes `barrido-dt --logs {args.logs}` o pasar --dt-target")
    iql_cfg = load_json(iql_sel)
    dt_info = load_json(dt_sel) if dt_sel.exists() else {}
    dt_target = args.dt_target if args.dt_target is not None else dt_info["target"]
    # Para return conditioning se evalúan en test todos los retornos del barrido.
    dt_targets = sorted({dt_target, *dt_info.get("targets", [])}) if args.rc else [dt_target]

    # IQL: la configuración elegida y la mejor con el otro γ (comparación γ = 0 frente a γ > 0).
    iql_cfgs = {}
    for hp in [iql_cfg["best"], *iql_cfg["best_por_gamma"].values()]:
        iql_cfgs[f"g{hp['gamma']:g}"] = hp

    base = run_dir(args.dataset, args.logs, "final")
    save_json({"hp_de": hp_logs, "dt_target": dt_target, "dt_targets_test": dt_targets, "iql": iql_cfgs,
               "iql_elegido": f"g{iql_cfg['best']['gamma']:g}", "seeds": args.train_seeds,
               "session_seeds": args.seeds}, base / "seleccion.json")

    if not (base / "test" / "lineas_base" / "sesiones.csv").exists() or args.force_baselines:
        evaluar_politicas(specs_lineas_base(args.logs), args.dataset, args.logs, "test",
                          base / "test" / "lineas_base", seeds=args.seeds, workers=args.workers, device=args.device,
                          max_users=args.max_users)

    for seed in args.train_seeds:
        out = base / "test" / f"seed{seed}"
        if (out / "sesiones.csv").exists() and not args.force_eval:
            print(f"Ya evaluado: {out}")
            continue
        dt_run = asegurar_entrenado("dt", args.dataset, args.logs, seed, args.epochs)
        specs = specs_dt(dt_run, dt_targets)
        for name, hp in iql_cfgs.items():
            iql_run = asegurar_entrenado("iql", args.dataset, args.logs, seed, args.epochs, **hp)
            specs += specs_iql(iql_run, ("pi", "q"), prefix=f"iql_{name}")
        evaluar_politicas(specs, args.dataset, args.logs, "test", out, seeds=args.seeds,
                          workers=args.workers, device=args.device, max_users=args.max_users)

    from .reporte import tabla_final

    tabla_final(args.dataset, args.logs)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    def comunes(sp):
        sp.add_argument("--dataset", choices=["netflix", "goodreads"], default="netflix")
        sp.add_argument("--logs", choices=["random", "mixto", "experto"], default="random")
        sp.add_argument("--epochs", type=int, help="épocas de entrenamiento (por defecto las de entrenar.py)")
        sp.add_argument("--workers", type=int, default=default_workers())
        sp.add_argument("--max-users", type=int, help="sólo para pruebas rápidas")
        sp.add_argument("--max-episodes", type=int, help="sólo para pruebas rápidas")
        sp.add_argument("--device", default="auto", help="auto: GPU si hay")

    sp = sub.add_parser("barrido-dt", help="retornos pedidos al DT, en validación")
    comunes(sp)
    sp.add_argument("--targets", type=float, nargs="*", help="por defecto: percentiles de train y fuera del soporte")
    sp.add_argument("--seeds", type=int, nargs="+", default=[0], help="semillas de sesión")
    sp.set_defaults(func=barrido_dt)

    sp = sub.add_parser("barrido-iql", help="τ, β y γ de IQL, en validación")
    comunes(sp)
    sp.add_argument("--gammas", type=float, nargs="+", default=[0.0, 0.9])
    sp.add_argument("--taus", type=float, nargs="+", default=[0.7, 0.9])
    sp.add_argument("--betas", type=float, nargs="+", default=[3.0, 10.0])
    sp.add_argument("--seeds", type=int, nargs="+", default=[0], help="semillas de sesión")
    sp.set_defaults(func=barrido_iql)

    sp = sub.add_parser("final", help="3 semillas de entrenamiento y evaluación en test")
    comunes(sp)
    sp.add_argument("--hp-de", choices=["random", "mixto", "experto"],
                    help="logs cuyo barrido de IQL fija τ, β y γ (por defecto los mismos logs)")
    sp.add_argument("--dt-target", type=float, help="retorno pedido; por defecto el elegido en val")
    sp.add_argument("--no-rc", dest="rc", action="store_false",
                    help="no evaluar en test todos los retornos del barrido (sin return conditioning)")
    sp.add_argument("--train-seeds", type=int, nargs="+", default=[0, 1, 2])
    sp.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2], help="semillas de sesión")
    sp.add_argument("--force-eval", action="store_true")
    sp.add_argument("--force-baselines", action="store_true")
    sp.set_defaults(func=final)

    args = p.parse_args()
    global MAX_EPISODES, DEVICE
    MAX_EPISODES, DEVICE = args.max_episodes, args.device
    np.set_printoptions(precision=3)
    args.func(args)


if __name__ == "__main__":
    main()
