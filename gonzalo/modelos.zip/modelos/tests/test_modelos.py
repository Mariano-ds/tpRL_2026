"""Tests de DT e IQL: no fuga, alineación de targets y separación de gradientes.

    python -m pytest modelos/tests
"""

from __future__ import annotations

import numpy as np
import pytest
import torch

from modelos.comun import UNKNOWN_GROUP, seen_before_mask
from modelos.dt import DecisionTransformer, DTPolicy, dt_loss, previous_ratings
from modelos.iql import IQLModel, IQLPolicy, expectile_loss, iql_losses

N_ITEMS, T, B = 50, 20, 4


@pytest.fixture
def batch():
    g = torch.Generator().manual_seed(0)
    items = torch.stack([torch.randperm(N_ITEMS, generator=g)[:T] for _ in range(B)])
    ratings = torch.randint(1, 6, (B, T), generator=g).float()
    rtg = ratings.flip(1).cumsum(1).flip(1)
    groups = torch.tensor([0, 3, 7, UNKNOWN_GROUP])
    return {"items": items, "ratings": ratings, "rtg": rtg, "groups": groups}


@pytest.fixture
def dt():
    torch.manual_seed(0)
    return DecisionTransformer(N_ITEMS, T, d_model=32, n_layers=2, n_heads=4).eval()


@pytest.fixture
def iql():
    torch.manual_seed(0)
    return IQLModel(N_ITEMS, T, d_model=32).eval()


def test_seen_before_mask_example():
    m = seen_before_mask(torch.tensor([[17, 30, 45]]), 50)[0]
    assert not m[0].any()
    assert m[1].nonzero().flatten().tolist() == [17]
    assert m[2].nonzero().flatten().tolist() == [17, 30]


@pytest.mark.parametrize("t", [0, 7, T - 1])
def test_dt_prediction_at_t_ignores_current_and_future_tokens(dt, batch, t):
    state = previous_ratings(batch["ratings"])
    base = dt(batch["rtg"], batch["items"], state, batch["groups"])[:, t]
    items2 = batch["items"].clone()
    items2[:, t:] = torch.randint(0, N_ITEMS, items2[:, t:].shape)
    rtg2 = batch["rtg"].clone()
    rtg2[:, t + 1:] = -7.0
    state2 = state.clone()
    state2[:, t + 1:] = 1.0  # el estado de t + 1 contiene r_t: no debe influir en el paso t
    out = dt(rtg2, items2, state2, batch["groups"])[:, t]
    assert torch.allclose(base, out, atol=1e-5)


def test_dt_prediction_depends_on_past(dt, batch):
    state = previous_ratings(batch["ratings"])
    base = dt(batch["rtg"], batch["items"], state, batch["groups"])[:, 5]
    items2 = batch["items"].clone()
    items2[:, 2] = (items2[:, 2] + 1) % N_ITEMS
    assert not torch.allclose(base, dt(batch["rtg"], items2, state, batch["groups"])[:, 5])


def test_dt_policy_matches_training_alignment(dt, batch):
    """La política autorregresiva reproduce las logits de entrenamiento del paso t."""
    full = dt(batch["rtg"], batch["items"], previous_ratings(batch["ratings"]), batch["groups"])
    for i in range(B):
        target = float(batch["rtg"][i, 0])
        pol = DTPolicy(dt, target)
        g = int(batch["groups"][i])
        pol.reset(None if g == UNKNOWN_GROUP else g, T)
        for t in (0, 3, T - 1):
            s = pol.scores(batch["items"][i, :t].numpy(), batch["ratings"][i, :t].numpy())
            np.testing.assert_allclose(s, full[i, t].double().detach().numpy(), atol=1e-4)


def test_dt_loss_finite_and_learnable(batch):
    torch.manual_seed(0)
    model = DecisionTransformer(N_ITEMS, T, d_model=32, n_layers=1, n_heads=2)
    opt = torch.optim.Adam(model.parameters(), lr=1e-2)
    first = dt_loss(model, batch)[0].item()
    for _ in range(30):
        loss = dt_loss(model, batch)[0]
        opt.zero_grad()
        loss.backward()
        opt.step()
    assert np.isfinite(first) and loss.item() < first


@pytest.mark.parametrize("tau,expected", [(0.5, 4.0), (0.9, 8.0)])
def test_expectile_matches_guide_example(tau, expected):
    q = torch.tensor([1.0, 2.0, 3.0, 10.0])
    grid = torch.linspace(0, 11, 11001)
    losses = torch.stack([expectile_loss(q - v, tau) for v in grid])
    assert abs(grid[losses.argmin()].item() - expected) < 0.05


def test_iql_state_at_t_ignores_current_and_future(iql, batch):
    t = 6
    for net in (iql.q, iql.v, iql.pi):
        base = net(batch["items"], batch["ratings"], batch["groups"])[:, t]
        items2, ratings2 = batch["items"].clone(), batch["ratings"].clone()
        items2[:, t:] = torch.randint(0, N_ITEMS, items2[:, t:].shape)
        ratings2[:, t:] = 1.0
        out = net(items2, ratings2, batch["groups"])[:, t]
        assert torch.allclose(base, out, atol=1e-5)


def test_iql_policy_matches_encoder(iql, batch):
    for mode, net in (("pi", iql.pi), ("q", iql.q)):
        full = net(batch["items"], batch["ratings"], batch["groups"])
        pol = IQLPolicy(iql, mode)
        pol.reset(3, T)
        for t in (0, 5, T - 1):
            s = pol.scores(batch["items"][1, :t].numpy(), batch["ratings"][1, :t].numpy())
            np.testing.assert_allclose(s, full[1, t].double().detach().numpy(), atol=1e-4)


def test_iql_gradients_do_not_mix(iql, batch):
    iql.train()
    for name, net_names in (("v", {"v"}), ("q", {"q"}), ("pi", {"pi"})):
        iql.zero_grad(set_to_none=True)
        losses, _ = iql_losses(iql, batch, gamma=0.9, tau=0.7, beta=3.0)
        losses[name].backward()
        for other in ("q", "v", "pi", "q_target"):
            grads = [p.grad for p in getattr(iql, other).parameters()]
            has = any(g is not None and g.abs().sum() > 0 for g in grads)
            assert has == (other in net_names), (name, other)


def test_iql_last_step_is_terminal(iql, batch):
    """Con γ = 1, L_Q coincide con un cálculo manual donde el último paso no usa V(s_T)."""
    l1, _ = iql_losses(iql, batch, gamma=1.0, tau=0.7, beta=3.0)
    r =(batch["ratings"] - 3) / 2
    v_all = iql.v(batch["items"], batch["ratings"], batch["groups"]).squeeze(-1)
    q = iql.q(batch["items"], batch["ratings"], batch["groups"])[:, :T].gather(-1, batch["items"].unsqueeze(-1))
    target = r.clone()
    target[:, :-1] += v_all[:, 1:T]
    manual = torch.nn.functional.mse_loss(q.squeeze(-1), target)
    assert torch.allclose(l1["q"], manual, atol=1e-6)
