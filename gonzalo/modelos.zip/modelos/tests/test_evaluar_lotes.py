"""El evaluador por lotes reproduce `protocolo.evaluar.evaluate`.

    python -m pytest modelos/tests
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
import torch

from protocolo.baselines import GroupPosteriorPolicy, ItemMeanPolicy
from protocolo.datos import User
from protocolo.evaluar import evaluate
from protocolo.simulador import SessionConfig

from modelos.dt import DecisionTransformer, DTPolicy
from modelos.evaluar_lotes import DTBatchPolicy, IQLBatchPolicy, PorSesion, evaluate_batch
from modelos.iql import IQLModel, IQLPolicy

N_ITEMS = 60
CONFIGS = [SessionConfig(20, w, v) for w in (0, 5) for v in (True, False)]
SEEDS = (0, 1)


def _users(n: int, seed: int, full: bool) -> list[User]:
    """Usuarios sintéticos: `full` como test (todo el catálogo), si no como val (subconjunto)."""
    rng = np.random.default_rng(seed)
    out = []
    for u in range(n):
        g = int(rng.integers(0, 8))
        items = np.arange(N_ITEMS) if full else rng.choice(N_ITEMS, size=int(rng.integers(25, N_ITEMS)),
                                                          replace=False)
        ratings = np.clip(np.round(rng.normal(3 + (items % 8 == g), 1.0)), 1, 5).astype(float)
        out.append(User(u, g, items.astype(np.int64), ratings))
    return out


TRAIN = _users(200, 0, full=False)
EVAL_SETS = {"test": _users(30, 1, full=True), "val": _users(30, 2, full=False)}


def _assert_same(a: pd.DataFrame, b: pd.DataFrame) -> None:
    pd.testing.assert_frame_equal(a.reset_index(drop=True), b.reset_index(drop=True), check_exact=False,
                                  rtol=1e-12, atol=1e-12)


@pytest.mark.parametrize("split", ["test", "val"])
@pytest.mark.parametrize("config", CONFIGS, ids=lambda c: f"w{c.warmup}_{'vis' if c.group_visible else 'oc'}")
@pytest.mark.parametrize("make", [lambda: ItemMeanPolicy(TRAIN, N_ITEMS, by_group=True),
                                  lambda: GroupPosteriorPolicy(TRAIN, N_ITEMS)], ids=["group_mean", "posterior"])
def test_batch_reproduces_protocol_with_baselines(split, config, make):
    users = EVAL_SETS[split]
    _assert_same(evaluate(make(), users, N_ITEMS, config, SEEDS),
                 evaluate_batch(PorSesion(make), users, N_ITEMS, config, SEEDS))


@pytest.fixture(scope="module")
def modelos():
    torch.manual_seed(0)
    return DecisionTransformer(N_ITEMS, 20, d_model=32, n_layers=2, n_heads=4).eval(), IQLModel(N_ITEMS, 20, 32).eval()


@pytest.mark.parametrize("config", CONFIGS, ids=lambda c: f"w{c.warmup}_{'vis' if c.group_visible else 'oc'}")
def test_batch_dt_and_iql_match_single_session_policies(modelos, config):
    dt, iql = modelos
    users = EVAL_SETS["val"]
    pairs = [(DTPolicy(dt, 75.0), DTBatchPolicy(dt, 75.0, chunk=7)),
             (IQLPolicy(iql, "pi"), IQLBatchPolicy(iql, "pi", chunk=7)),
             (IQLPolicy(iql, "q"), IQLBatchPolicy(iql, "q"))]
    for single, batch in pairs:
        a = evaluate(single, users, N_ITEMS, config, SEEDS)
        b = evaluate_batch(batch, users, N_ITEMS, config, SEEDS)
        # Mismas recomendaciones (y por lo tanto mismo retorno) en cada sesión;
        # el ranking del primer paso puede diferir por redondeo de float32 entre lote 1 y lote N.
        cols = ["user_id", "group", "seed", "return", "full_return", "hit_rate", "normalized", "oracle"]
        _assert_same(a[cols], b[cols])
        np.testing.assert_allclose(a["ndcg@10"], b["ndcg@10"], atol=1e-6)


def test_batch_scores_match_single(modelos):
    dt, iql = modelos
    rng = np.random.default_rng(0)
    items = np.stack([rng.choice(N_ITEMS, 7, replace=False) for _ in range(5)])
    ratings = rng.integers(1, 6, items.shape).astype(float)
    groups = [0, None, 3, 7, None]
    for single, batch in ((DTPolicy(dt, 80.0), DTBatchPolicy(dt, 80.0, chunk=2)),
                          (IQLPolicy(iql, "q"), IQLBatchPolicy(iql, "q", chunk=2))):
        batch.reset_batch(groups, 20)
        out = batch.scores_batch(items, ratings)
        for k, g in enumerate(groups):
            single.reset(g, 20)
            np.testing.assert_allclose(out[k], single.scores(items[k], ratings[k]), atol=1e-4)
