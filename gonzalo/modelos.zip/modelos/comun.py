"""Utilidades compartidas por DT e IQL: datos, lotes, semillas y rutas."""

from __future__ import annotations

import json
import os
import platform
import random
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch

from protocolo.datos import N_GROUPS, Episodes, User, load_train, num_items, split_by_user
from protocolo.logs import logged_episodes, logs_cache

TP_ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = Path(os.environ.get("TP_OUTPUTS", TP_ROOT / "outputs" / "modelos"))
HORIZON = 20
UNKNOWN_GROUP = N_GROUPS  # índice del token "grupo desconocido"


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def get_device(name: str = "auto") -> torch.device:
    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(name)


def run_dir(dataset: str, logs: str, *parts: str) -> Path:
    return OUTPUTS / f"{dataset}_{logs}" / Path(*parts)


def versions() -> dict[str, str]:
    import pandas

    return {
        "python": platform.python_version(),
        "torch": torch.__version__,
        "numpy": np.__version__,
        "pandas": pandas.__version__,
    }


def save_json(obj: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=2, ensure_ascii=False, default=str)


def load_json(path: Path) -> dict:
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


@dataclass
class DatosTP:
    """Todo lo que necesita un experimento con un tipo de logs.

    - `train_users` / `val_users`: partición por usuario del protocolo (90/10, semilla 0).
    - `train_eps` / `val_eps`: episodios de 20 pasos con los logs elegidos.
    - `baseline_users`: con qué se ajustan las líneas base (los mismos logs que el modelo).
    """

    dataset: str
    logs: str
    n_items: int
    train_users: list[User]
    val_users: list[User]
    train_eps: Episodes
    val_eps: Episodes
    baseline_users: list[User]


def cargar_datos(dataset: str, logs: str = "random") -> DatosTP:
    n_items = num_items(dataset)
    train, val = split_by_user(load_train(dataset))

    def cache(split: str) -> Path | None:
        # Junto a los resultados (con TP_OUTPUTS en Drive, también persiste allí).
        rel = logs_cache(dataset, logs, split)
        return None if rel is None else OUTPUTS.parent / "logs" / rel.name

    tr = logged_episodes(logs, train, train, n_items, HORIZON, seed=0, cache=cache("train"))
    va = logged_episodes(logs, val, train, n_items, HORIZON, seed=1, cache=cache("val"))
    baseline_users = train if logs == "random" else tr.logged_users()
    return DatosTP(dataset, logs, n_items, train, val, tr.episodes, va.episodes, baseline_users)


def episodios_a_tensores(ep: Episodes) -> dict[str, torch.Tensor]:
    return {
        "items": torch.as_tensor(ep.items, dtype=torch.long),
        "ratings": torch.as_tensor(ep.ratings, dtype=torch.float32),
        "rtg": torch.as_tensor(ep.returns_to_go().copy(), dtype=torch.float32),
        "groups": torch.as_tensor(ep.groups, dtype=torch.long),
    }


def iterar_lotes(
    data: dict[str, torch.Tensor],
    batch_size: int,
    shuffle: bool,
    generator: torch.Generator | None = None,
    group_dropout: float = 0.0,
    device: torch.device = torch.device("cpu"),
):
    """Lotes de episodios. `group_dropout` reemplaza el grupo por "desconocido".

    Así el modelo aprende a recomendar también con el grupo oculto (cold-start).
    """
    n = data["items"].shape[0]
    order = torch.randperm(n, generator=generator) if shuffle else torch.arange(n)
    for start in range(0, n, batch_size):
        idx = order[start:start + batch_size]
        batch = {k: v[idx].to(device) for k, v in data.items()}
        if group_dropout > 0:
            drop = torch.rand(len(idx), generator=generator) < group_dropout
            batch["groups"] = torch.where(drop.to(device), torch.full_like(batch["groups"], UNKNOWN_GROUP),
                                          batch["groups"])
        yield batch


def seen_before_mask(items: torch.Tensor, n_items: int) -> torch.Tensor:
    """(B, T, n_items): True si el ítem ya se mostró antes del paso t del episodio."""
    onehot = torch.nn.functional.one_hot(items, n_items).to(torch.int32)  # (B, T, n)
    before = onehot.cumsum(dim=1) - onehot  # cuenta sólo los pasos < t
    return before > 0


def returns_support(ep: Episodes) -> dict[str, float]:
    """Distribución del retorno de los episodios de train (R̂_0)."""
    r0 = ep.ratings.sum(axis=1)
    out = {f"p{p}": float(np.percentile(r0, p)) for p in (1, 10, 25, 50, 75, 90, 99)}
    out.update(min=float(r0.min()), max=float(r0.max()), mean=float(r0.mean()))
    return out
