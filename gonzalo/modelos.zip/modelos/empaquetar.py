"""Genera el ZIP con el código de `modelos/` para usarlo en Colab.

Uso, desde `2026/tp`:

    python -m modelos.empaquetar                 # → ../../dist/modelos.zip
    python -m modelos.empaquetar --output /ruta/modelos.zip

La raíz del ZIP es `modelos/`, así que se descomprime directamente en `2026/tp`:

    unzip -o modelos.zip -d 2026/tp

Excluye cachés de Python. No incluye datos ni resultados.
"""

from __future__ import annotations

import argparse
import zipfile
from pathlib import Path

PKG = Path(__file__).resolve().parent
EXCLUDE_DIRS = {"__pycache__", ".pytest_cache", ".ipynb_checkpoints"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".pt", ".npz", ".zip"}


def archivos() -> list[Path]:
    return sorted(p for p in PKG.rglob("*")
                  if p.is_file() and not EXCLUDE_DIRS & set(p.relative_to(PKG).parts)
                  and p.suffix not in EXCLUDE_SUFFIXES)


def empaquetar(output: Path) -> Path:
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in archivos():
            zf.write(f, Path("modelos") / f.relative_to(PKG))
    return output


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--output", type=Path, default=PKG.parents[2] / "dist" / "modelos.zip")
    out = empaquetar(p.parse_args().output)
    with zipfile.ZipFile(out) as zf:
        for name in zf.namelist():
            print(name)
    print(f"\n{out} ({out.stat().st_size / 1024:.1f} KB)")


if __name__ == "__main__":
    main()
