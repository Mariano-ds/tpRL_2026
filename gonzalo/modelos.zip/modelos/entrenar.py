"""Entrenamiento de DT o IQL con los episodios de 20 pasos del protocolo.

Uso, desde `2026/tp`:

    python -m modelos.entrenar --modelo dt  --dataset netflix --logs random --seed 0
    python -m modelos.entrenar --modelo iql --dataset netflix --logs random --seed 0 \\
        --gamma 0.9 --tau 0.7 --beta 3

Escribe en `--output` (por defecto `outputs/modelos/<dataset>_<logs>/<modelo>/<tag>/seed<k>`):

- `config.json`: argumentos, versiones, soporte de retornos de train y tamaños.
- `curvas.csv`: por época, pérdidas de train y validación (sin recortes).
- `curvas_pasos.csv`: cada `--log-every` pasos de optimización.
- `checkpoint.pt`: DT → el de menor cross-entropy en validación; IQL → el último
  (las pérdidas de IQL no miden la calidad de la política; se elige con el protocolo).
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from .comun import (HORIZON, cargar_datos, episodios_a_tensores, get_device, iterar_lotes, load_json,
                    returns_support, run_dir, save_json, set_seed, versions)
from .dt import DecisionTransformer, dt_loss
from .iql import IQLModel, iql_losses

DEFAULTS = {
    # dropout = 0 por costo: en CPU cada capa de dropout tarda ~0,1 s por lote (3× el paso completo).
    "dt": dict(epochs=10, batch_size=256, lr=1e-3, weight_decay=0.1, d_model=128, n_layers=3, n_heads=4,
               dropout=0.0, group_dropout=0.3),
    "iql": dict(epochs=10, batch_size=256, lr=3e-4, weight_decay=0.0, d_model=128, group_dropout=0.3,
                gamma=0.9, tau=0.7, beta=3.0, max_weight=100.0, polyak=0.005,
                reward_center=3.0, reward_scale=2.0),
}


def tag_de(cfg: dict) -> str:
    if cfg["modelo"] == "dt":
        return cfg.get("tag") or "base"
    return cfg.get("tag") or f"g{cfg['gamma']:g}_t{cfg['tau']:g}_b{cfg['beta']:g}"


def construir_modelo(cfg: dict, n_items: int) -> torch.nn.Module:
    if cfg["modelo"] == "dt":
        return DecisionTransformer(n_items, HORIZON, cfg["d_model"], cfg["n_layers"], cfg["n_heads"], cfg["dropout"])
    return IQLModel(n_items, HORIZON, cfg["d_model"])


def cargar_modelo(run: Path, device: str = "cpu") -> tuple[torch.nn.Module, dict]:
    cfg = load_json(run / "config.json")
    model = construir_modelo(cfg, cfg["n_items"])
    state = torch.load(run / "checkpoint.pt", map_location=device, weights_only=True)
    model.load_state_dict(state["model"])
    return model.to(device).eval(), cfg


def _subset(data: dict[str, torch.Tensor], n: int | None) -> dict[str, torch.Tensor]:
    return data if n is None else {k: v[:n] for k, v in data.items()}


def entrenar(cfg: dict, datos=None) -> Path:
    """Entrena un modelo y devuelve la carpeta de la corrida."""
    cfg = {**DEFAULTS[cfg["modelo"]], **{k: v for k, v in cfg.items() if v is not None}}
    out = Path(cfg["output"]) if cfg.get("output") else run_dir(
        cfg["dataset"], cfg["logs"], cfg["modelo"], tag_de(cfg), f"seed{cfg['seed']}")
    out.mkdir(parents=True, exist_ok=True)
    set_seed(cfg["seed"])
    device = get_device(cfg.get("device", "auto"))
    datos = datos or cargar_datos(cfg["dataset"], cfg["logs"])
    train = _subset(episodios_a_tensores(datos.train_eps), cfg.get("max_episodes"))
    val = _subset(episodios_a_tensores(datos.val_eps), cfg.get("max_episodes"))
    gen = torch.Generator().manual_seed(cfg["seed"])

    model = construir_modelo(cfg, datos.n_items).to(device)
    is_dt = cfg["modelo"] == "dt"
    steps_per_epoch = -(-train["items"].shape[0] // cfg["batch_size"])
    if is_dt:
        opts = [torch.optim.AdamW(model.parameters(), lr=cfg["lr"], weight_decay=cfg["weight_decay"])]
        scheduler = torch.optim.lr_scheduler.OneCycleLR(opts[0], max_lr=cfg["lr"],
                                                        total_steps=cfg["epochs"] * steps_per_epoch)
    else:  # un optimizador por red; cada pérdida sólo llega a su red
        opts = [torch.optim.Adam(net.parameters(), lr=cfg["lr"]) for net in (model.v, model.q, model.pi)]
        scheduler = None

    save_json({**cfg, "output": str(out), "n_items": datos.n_items, "versions": versions(),
               "n_train_episodes": int(train["items"].shape[0]), "n_val_episodes": int(val["items"].shape[0]),
               "train_return_support": returns_support(datos.train_eps)}, out / "config.json")

    def step_loss(batch):
        if is_dt:
            loss, diag = dt_loss(model, batch)
            return loss, diag
        losses, diag = iql_losses(model, batch, cfg["gamma"], cfg["tau"], cfg["beta"], cfg["max_weight"],
                                  cfg["reward_center"], cfg["reward_scale"])
        return losses["v"] + losses["q"] + losses["pi"], diag

    @torch.no_grad()
    def evaluate_val() -> dict[str, float]:
        model.eval()
        rows, sizes = [], []
        for batch in iterar_lotes(val, 1024, shuffle=False, device=device):
            rows.append(step_loss(batch)[1])
            sizes.append(batch["items"].shape[0])
        model.train()
        df = pd.DataFrame(rows)
        return (df.mul(np.array(sizes), axis=0).sum() / sum(sizes)).to_dict()

    epoch_rows, step_rows = [], []
    best, global_step = float("inf"), 0
    model.train()
    t0 = time.time()
    for epoch in range(1, cfg["epochs"] + 1):
        train_diags = []
        for batch in iterar_lotes(train, cfg["batch_size"], True, gen, cfg["group_dropout"], device):
            loss, diag = step_loss(batch)
            for opt in opts:
                opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            for opt in opts:
                opt.step()
            if scheduler is not None:
                scheduler.step()
            if not is_dt:
                model.update_target(cfg["polyak"])
            global_step += 1
            train_diags.append(diag)
            if global_step % cfg.get("log_every", 50) == 0:
                step_rows.append({"step": global_step, "epoch": epoch, **diag})
        tr = pd.DataFrame(train_diags).mean().add_prefix("train_").to_dict()
        va = {f"val_{k}": v for k, v in evaluate_val().items()}
        row = {"epoch": epoch, "step": global_step, "seconds": round(time.time() - t0, 1), **tr, **va}
        epoch_rows.append(row)
        pd.DataFrame(epoch_rows).to_csv(out / "curvas.csv", index=False)
        pd.DataFrame(step_rows).to_csv(out / "curvas_pasos.csv", index=False)
        print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in row.items()}, flush=True)

        state = {"model": model.state_dict(), "epoch": epoch}
        torch.save(state, out / "ultimo.pt")
        if is_dt and va["val_ce"] < best:
            best = va["val_ce"]
            torch.save(state, out / "checkpoint.pt")
    if not is_dt:
        torch.save({"model": model.state_dict(), "epoch": cfg["epochs"]}, out / "checkpoint.pt")
    return out


def parse_args(argv=None) -> dict:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--modelo", choices=["dt", "iql"], required=True)
    p.add_argument("--dataset", choices=["netflix", "goodreads"], default="netflix")
    p.add_argument("--logs", choices=["random", "mixto", "experto"], default="random")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--tag", help="nombre de la configuración (por defecto: base / g_t_b)")
    p.add_argument("--output", help="carpeta de la corrida")
    p.add_argument("--device", default="auto")
    p.add_argument("--max-episodes", type=int, help="sólo para pruebas rápidas")
    p.add_argument("--log-every", type=int, default=50)
    for name in ("epochs", "batch_size", "d_model", "n_layers", "n_heads"):
        p.add_argument(f"--{name.replace('_', '-')}", type=int)
    for name in ("lr", "weight_decay", "dropout", "group_dropout", "gamma", "tau", "beta", "max_weight",
                 "polyak", "reward_center", "reward_scale"):
        p.add_argument(f"--{name.replace('_', '-')}", type=float)
    return vars(p.parse_args(argv))


if __name__ == "__main__":
    print(entrenar(parse_args()))
