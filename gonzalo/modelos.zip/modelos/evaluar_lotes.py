"""Evaluador por lotes: mismo protocolo, puntajes de todas las sesiones en una llamada.

`protocolo.evaluar.evaluate` corre una sesión por vez y llama a la política una
vez por paso y por usuario. Con DT o IQL eso es una pasada del modelo por paso,
con lote 1. Este módulo reproduce exactamente `evaluate` y `run_session`:

- una `Session` por (semilla de sesión, usuario), con su propio generador
  `np.random.default_rng([seed, user_index])`, que decide el warm-up y los empates;
- las mismas cotas (`session_bounds`), métricas (`normalized_score`,
  `ranking_metrics` del primer paso controlado) y columnas, en el mismo orden;
- cada sesión elige su ítem con `simulador.choose` sobre su propia máscara.

Lo único que cambia es que, en cada paso, los puntajes de todas las sesiones se
calculan juntos (`scores_batch`), en GPU si hay. Todas las sesiones de una
condición avanzan sincronizadas: en el paso t todas tienen t ítems observados.
`tests/test_evaluar_lotes.py` verifica que el resultado coincide con `evaluate`.

Las líneas base se siguen evaluando con `evaluate`: `RandomPolicy` consume su
generador en el orden de las sesiones y por lotes daría otros números.
"""

from __future__ import annotations

from typing import Callable, Iterable, Protocol

import numpy as np
import pandas as pd
import torch

from protocolo.datos import RELEVANCE_THRESHOLD, User
from protocolo.metricas import normalized_score, ranking_metrics, session_bounds
from protocolo.simulador import Policy, Session, SessionConfig, choose

from .comun import UNKNOWN_GROUP
from .dt import DecisionTransformer
from .iql import IQLModel


class BatchPolicy(Protocol):
    def reset_batch(self, groups: list[int | None], horizon: int) -> None: ...

    def scores_batch(self, items: np.ndarray, ratings: np.ndarray) -> np.ndarray:
        """items, ratings: (N, t) de las N sesiones. Devuelve (N, n_items)."""
        ...


def _groups_tensor(groups: list[int | None], device) -> torch.Tensor:
    return torch.tensor([UNKNOWN_GROUP if g is None else int(g) for g in groups], dtype=torch.long, device=device)


class DTBatchPolicy:
    """Versión por lotes de `DTPolicy`: R̂_t = objetivo − ratings ya revelados."""

    def __init__(self, model: DecisionTransformer, target_return: float, device="cpu", chunk: int = 4096):
        self.model = model.to(device).eval()
        self.target, self.device, self.chunk = float(target_return), torch.device(device), chunk

    def reset_batch(self, groups, horizon):
        self.groups = _groups_tensor(groups, self.device)

    @torch.no_grad()
    def scores_batch(self, items: np.ndarray, ratings: np.ndarray) -> np.ndarray:
        N, t = items.shape
        r = torch.as_tensor(ratings, dtype=torch.float32, device=self.device)
        spent = torch.cat([torch.zeros(N, 1, device=self.device), r.cumsum(1)], dim=1)  # (N, t + 1)
        rtg = self.target - spent
        it = torch.as_tensor(items, dtype=torch.long, device=self.device)
        it = torch.cat([it, torch.full((N, 1), self.model.pad_item, device=self.device)], dim=1)
        state = torch.cat([torch.zeros(N, 1, device=self.device), r], dim=1)
        out = [self.model(rtg[s:s + self.chunk], it[s:s + self.chunk], state[s:s + self.chunk],
                          self.groups[s:s + self.chunk], last_only=True) for s in range(0, N, self.chunk)]
        return torch.cat(out).double().cpu().numpy()


class IQLBatchPolicy:
    """Versión por lotes de `IQLPolicy` (`mode="pi"` o `"q"`)."""

    def __init__(self, model: IQLModel, mode: str = "pi", device="cpu", chunk: int = 4096):
        if mode not in ("pi", "q"):
            raise ValueError("mode debe ser 'pi' o 'q'")
        self.model = model.to(device).eval()
        self.net = model.pi if mode == "pi" else model.q
        self.device, self.chunk = torch.device(device), chunk

    def reset_batch(self, groups, horizon):
        self.groups = _groups_tensor(groups, self.device)

    @torch.no_grad()
    def scores_batch(self, items: np.ndarray, ratings: np.ndarray) -> np.ndarray:
        it = torch.as_tensor(items, dtype=torch.long, device=self.device)
        r = torch.as_tensor(ratings, dtype=torch.float32, device=self.device)
        out = [self.net.last(it[s:s + self.chunk], r[s:s + self.chunk], self.groups[s:s + self.chunk])
               for s in range(0, it.shape[0], self.chunk)]
        return torch.cat(out).double().cpu().numpy()


class PorSesion:
    """Adapta una política del protocolo (una instancia por sesión) a `BatchPolicy`.

    Sirve para verificar el evaluador contra `evaluate` con políticas sin estado
    compartido entre sesiones.
    """

    def __init__(self, make: Callable[[], Policy]):
        self.make = make

    def reset_batch(self, groups, horizon):
        self.policies = [self.make() for _ in groups]
        for p, g in zip(self.policies, groups):
            p.reset(g, horizon)

    def scores_batch(self, items, ratings):
        return np.stack([np.asarray(p.scores(i.copy(), r.copy()), dtype=np.float64)
                         for p, i, r in zip(self.policies, items, ratings)])


def evaluate_batch(policy: BatchPolicy, users: list[User], n_items: int, config: SessionConfig,
                   seeds: Iterable[int] = (0, 1, 2)) -> pd.DataFrame:
    """Equivalente a `protocolo.evaluar.evaluate`, con los puntajes calculados por lotes."""
    keys = [(seed, index, user) for seed in seeds for index, user in enumerate(users)]
    rngs = [np.random.default_rng([seed, index]) for seed, index, _ in keys]
    sessions = [Session(user, n_items, config, rng) for (_, _, user), rng in zip(keys, rngs)]
    policy.reset_batch([s.visible_group for s in sessions], config.horizon)

    steps = config.controlled_steps
    bounds = [session_bounds(s._available_hidden_ratings(), steps) for s in sessions]
    controlled = [[] for _ in sessions]
    first_ranking: list[dict] = [{} for _ in sessions]

    while not sessions[0].done:
        obs = [s.observed() for s in sessions]
        items = np.stack([o[0] for o in obs]).reshape(len(sessions), -1)
        ratings = np.stack([o[1] for o in obs]).reshape(len(sessions), -1)
        scores = policy.scores_batch(items, ratings)
        for k, s in enumerate(sessions):
            mask = s.available_mask()
            if not first_ranking[k]:
                first_ranking[k] = ranking_metrics(scores[k], s._hidden_ratings(), mask, k=10)
            controlled[k].append(s.step(choose(scores[k], mask, rngs[k])))

    rows = []
    for (seed, _, user), s, ctrl, (random_expected, oracle), rank in zip(
            keys, sessions, controlled, bounds, first_ranking):
        ret = float(np.sum(ctrl))
        rows.append({
            "user_id": user.user_id,
            "group": user.group,
            "seed": seed,
            "return": ret,
            "full_return": float(np.sum(s.ratings)),
            "mean_rating": ret / steps,
            "hit_rate": float(np.mean(np.array(ctrl) >= RELEVANCE_THRESHOLD)),
            "normalized": normalized_score(ret, random_expected, oracle),
            "random_expected": random_expected,
            "oracle": oracle,
            **rank,
        })
    return pd.DataFrame(rows)
