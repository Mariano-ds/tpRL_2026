"""Evaluación de DT e IQL (y líneas base) con el protocolo común.

Uso, desde `2026/tp`:

    # DT con varios retornos pedidos, en validación
    python -m modelos.evaluar_modelo --dataset netflix --split val \\
        --dt outputs/modelos/netflix_random/dt/base/seed0 --targets 60 70 80 90 \\
        --output outputs/modelos/netflix_random/eval/dt_val

    # IQL (π y máximo de Q) y líneas base, en test
    python -m modelos.evaluar_modelo --dataset netflix --split test --baselines \\
        --iql outputs/modelos/netflix_random/iql/g0.9_t0.7_b3/seed0 \\
        --output outputs/modelos/netflix_random/eval/test_seed0

Corre `protocolo.evaluar.evaluate` para cada (política, condición): mismos
usuarios, candidatos, historial, horizonte, condiciones y semillas de sesión que
las líneas base, y escribe los reportes con `protocolo.evaluar.write_reports`
(`sesiones.csv`, `resumen.csv`, `resumen_por_grupo.csv`).

DT e IQL se evalúan por defecto con `modelos.evaluar_lotes.evaluate_batch`
(mismo protocolo, puntajes de todas las sesiones en una llamada, en GPU si hay;
`--no-batch` vuelve al camino de a una sesión). Las líneas base siempre usan
`evaluate`, repartidas entre procesos (`--workers`).

Las políticas se describen con especificaciones serializables:

    ("base", nombre)                 línea base de `protocolo` (o "sistema_anterior_eps0")
    ("dt", nombre, carpeta, retorno) DT con un retorno pedido
    ("iql", nombre, carpeta, modo)   IQL con modo "pi" o "q"
"""

from __future__ import annotations

import argparse
import multiprocessing as mp
import os
import time
from functools import lru_cache
from pathlib import Path
from typing import Callable, Iterable

import numpy as np
import pandas as pd
import torch

from protocolo.datos import load_test
from protocolo.evaluar import baseline_factories, evaluate, write_reports
from protocolo.logs import PRESETS, PreviousSystem
from protocolo.simulador import Policy, SessionConfig

from .comun import DatosTP, cargar_datos, get_device
from .dt import DTPolicy
from .entrenar import cargar_modelo
from .evaluar_lotes import DTBatchPolicy, IQLBatchPolicy, evaluate_batch
from .iql import IQLPolicy

Spec = tuple


def factories_lineas_base(datos: DatosTP) -> dict[str, Callable[[], Policy]]:
    """Líneas base ajustadas con los mismos logs que los modelos (igual que `protocolo.evaluar`)."""
    factories = baseline_factories(datos.baseline_users, datos.n_items)
    if datos.logs != "random":
        _, temperature = PRESETS[datos.logs]
        train, n_items = datos.train_users, datos.n_items
        factories["sistema_anterior_eps0"] = lambda: PreviousSystem.fit(
            train, n_items, 0.0, temperature, np.random.default_rng(0))
    return factories


def specs_lineas_base(logs: str) -> list[Spec]:
    names = ["random", "popularity", "item_mean", "group_mean", "group_posterior"]
    if logs != "random":
        names.append("sistema_anterior_eps0")
    return [("base", n) for n in names]


def specs_dt(run: Path | str, targets: Iterable[float], prefix: str = "dt") -> list[Spec]:
    return [("dt", f"{prefix}_R{t:g}", str(run), float(t)) for t in targets]


def specs_iql(run: Path | str, modes: Iterable[str] = ("pi", "q"), prefix: str = "iql") -> list[Spec]:
    return [("iql", f"{prefix}_{m}", str(run), m) for m in modes]


# --- ejecución (también dentro de cada proceso) ----------------------------------------

_STATE: dict = {}


def _init_worker(dataset: str, logs: str, split: str, max_users: int | None) -> None:
    torch.set_num_threads(1)
    datos = cargar_datos(dataset, logs)
    users = datos.val_users if split == "val" else load_test(dataset)
    _STATE.update(datos=datos, users=users if max_users is None else users[:max_users],
                  base=factories_lineas_base(datos))


@lru_cache(maxsize=16)
def _modelo(run: str):
    return cargar_modelo(Path(run))[0]


def _build(spec: Spec) -> Policy:
    kind = spec[0]
    if kind == "base":
        return _STATE["base"][spec[1]]()
    if kind == "dt":
        return DTPolicy(_modelo(spec[2]), spec[3])
    if kind == "iql":
        return IQLPolicy(_modelo(spec[2]), spec[3])
    raise ValueError(f"Especificación desconocida: {spec}")


def _run_task(task: tuple[Spec, int, int, bool, tuple[int, ...]]) -> pd.DataFrame:
    spec, horizon, warmup, visible, seeds = task
    config = SessionConfig(horizon, warmup, visible)
    datos = _STATE["datos"]
    df = evaluate(_build(spec), _STATE["users"], datos.n_items, config, seeds)
    return df.assign(policy=spec[1], warmup=warmup, group_visible=visible)


def _evaluar_por_sesion(specs, dataset, logs, split, warmups, visibility, seeds, workers, horizon, max_users):
    """Camino original: `protocolo.evaluar.evaluate`, una sesión por vez (procesos en paralelo)."""
    tasks = [(s, horizon, w, v, tuple(seeds)) for s in specs for w in warmups for v in visibility]
    init_args = (dataset, logs, split, max_users)
    if workers > 1 and len(tasks) > 1:
        with mp.get_context("spawn").Pool(min(workers, len(tasks)), _init_worker, init_args) as pool:
            return pool.map(_run_task, tasks, chunksize=1)
    n_threads = torch.get_num_threads()
    _init_worker(*init_args)
    try:
        return [_run_task(t) for t in tasks]
    finally:
        torch.set_num_threads(n_threads)


def _evaluar_por_lotes(specs, dataset, logs, split, warmups, visibility, seeds, horizon, max_users,
                       device, chunk):
    """DT e IQL con `evaluate_batch`: puntajes de todas las sesiones por paso, en `device`."""
    datos = cargar_datos(dataset, logs)
    users = datos.val_users if split == "val" else load_test(dataset)
    users = users if max_users is None else users[:max_users]
    dev = get_device(device)
    modelos: dict[str, torch.nn.Module] = {}
    frames = []
    for spec in specs:
        kind, name, run, arg = spec
        if run not in modelos:
            modelos[run] = cargar_modelo(Path(run), dev)[0]
        policy = (DTBatchPolicy(modelos[run], arg, dev, chunk) if kind == "dt"
                  else IQLBatchPolicy(modelos[run], arg, dev, chunk))
        for w in warmups:
            for v in visibility:
                t0 = time.time()
                df = evaluate_batch(policy, users, datos.n_items, SessionConfig(horizon, w, v), tuple(seeds))
                frames.append(df.assign(policy=name, warmup=w, group_visible=v))
                print(f"  {name} warmup={w} visible={v}: {time.time() - t0:.1f} s", flush=True)
    return frames


def evaluar_politicas(
    specs: list[Spec], dataset: str, logs: str, split: str, output: Path | None = None,
    warmups: Iterable[int] = (0, 5), visibility: Iterable[bool] = (True, False),
    seeds: Iterable[int] = (0, 1, 2), workers: int = 1, horizon: int = 20, max_users: int | None = None,
    batched: bool = True, device: str = "auto", chunk: int = 4096,
) -> pd.DataFrame:
    """Evalúa cada especificación en cada condición. `split="val"` restringe el
    catálogo de cada usuario de validación a los ítems que valoró (protocolo).

    Con `batched=True` (por defecto), DT e IQL se evalúan por lotes en `device`
    (GPU si hay); las líneas base siempre con `evaluate`, una sesión por vez.
    """
    warmups, visibility, seeds = tuple(warmups), tuple(visibility), tuple(seeds)
    por_sesion = [s for s in specs if s[0] == "base" or not batched]
    por_lotes = [s for s in specs if s[0] != "base" and batched]
    frames = []
    if por_sesion:
        frames += _evaluar_por_sesion(por_sesion, dataset, logs, split, warmups, visibility, seeds, workers,
                                      horizon, max_users)
    if por_lotes:
        frames += _evaluar_por_lotes(por_lotes, dataset, logs, split, warmups, visibility, seeds, horizon,
                                     max_users, device, chunk)
    results = pd.concat(frames, ignore_index=True)
    if output is not None:
        write_reports(results, Path(output))
    return results


def default_workers() -> int:
    return max(1, (os.cpu_count() or 2) - 1)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--dataset", choices=["netflix", "goodreads"], default="netflix")
    p.add_argument("--logs", choices=["random", "mixto", "experto"], default="random",
                   help="logs con los que se ajustan las líneas base")
    p.add_argument("--split", choices=["val", "test"], default="val")
    p.add_argument("--dt", nargs="*", default=[], help="carpetas de corridas DT")
    p.add_argument("--targets", type=float, nargs="*", default=[], help="retornos pedidos al DT")
    p.add_argument("--iql", nargs="*", default=[], help="carpetas de corridas IQL")
    p.add_argument("--modes", nargs="+", default=["pi", "q"], choices=["pi", "q"])
    p.add_argument("--baselines", action="store_true")
    p.add_argument("--warmup", type=int, nargs="+", default=[0, 5])
    p.add_argument("--visibility", choices=["both", "visible", "hidden"], default="both")
    p.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2], help="semillas de sesión")
    p.add_argument("--workers", type=int, default=default_workers())
    p.add_argument("--max-users", type=int, help="sólo para pruebas rápidas")
    p.add_argument("--device", default="auto", help="dispositivo para DT/IQL por lotes (auto: GPU si hay)")
    p.add_argument("--chunk", type=int, default=4096, help="sesiones por llamada al modelo")
    p.add_argument("--no-batch", dest="batched", action="store_false",
                   help="evaluar DT/IQL una sesión por vez con protocolo.evaluar.evaluate")
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()

    specs: list[Spec] = specs_lineas_base(args.logs) if args.baselines else []
    for i, run in enumerate(args.dt):
        specs += specs_dt(run, args.targets, f"dt{i}" if len(args.dt) > 1 else "dt")
    for i, run in enumerate(args.iql):
        specs += specs_iql(run, args.modes, f"iql{i}" if len(args.iql) > 1 else "iql")
    if not specs:
        p.error("No hay políticas para evaluar (usar --dt, --iql o --baselines)")
    if args.dt and not args.targets:
        p.error("--dt requiere --targets")
    vis = {"both": (True, False), "visible": (True,), "hidden": (False,)}[args.visibility]
    evaluar_politicas(specs, args.dataset, args.logs, args.split, args.output, args.warmup, vis, args.seeds,
                      args.workers, max_users=args.max_users, batched=args.batched, device=args.device,
                      chunk=args.chunk)


if __name__ == "__main__":
    main()
