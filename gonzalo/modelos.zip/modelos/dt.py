"""Decision Transformer condicionado por retorno (Chen et al., 2021).

Tokens por paso t, intercalados: R̂_t, s_t, a_t.

- R̂_t: retorno pendiente del episodio de 20 pasos, dividido por `rtg_scale`, con una capa lineal.
- s_t: embedding del grupo (o del token "desconocido") + proyección lineal de
  [rating del paso anterior centrado, indicador de que existe]. En t = 0 no hay
  rating previo. s_t nunca incluye r_t, que se revela después de mostrar a_t.
- a_t: embedding del ítem. En inferencia, el a_t del último paso es un relleno
  (índice `n_items`) que la salida de s_t no ve por la máscara causal.

A cada token se le suma un embedding del paso t (el mismo para los tres) y otro
del tipo de token. La máscara causal (3T × 3T) deja que cada token vea sólo los
anteriores. Las logits de a_t se leen de la salida del token s_t (posiciones
1, 4, 7, ...), que vio R̂_≤t, s_≤t y a_<t, pero no a_t. No hay padding: los
episodios de train tienen siempre T = 20 y en inferencia la secuencia tiene
largo t + 1, lo que la máscara causal hace equivalente a un prefijo.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from protocolo.datos import N_GROUPS

from .comun import UNKNOWN_GROUP, seen_before_mask

RATING_CENTER, RATING_SCALE = 3.0, 2.0


def previous_ratings(ratings: torch.Tensor) -> torch.Tensor:
    """(B, T): rating del paso anterior; 0 en t = 0 (sin rating previo)."""
    return torch.cat([torch.zeros_like(ratings[:, :1]), ratings[:, :-1]], dim=1)


class DecisionTransformer(nn.Module):
    def __init__(self, n_items: int, horizon: int = 20, d_model: int = 128, n_layers: int = 3,
                 n_heads: int = 4, dropout: float = 0.1, rtg_scale: float = 100.0):
        super().__init__()
        self.n_items, self.horizon, self.rtg_scale = n_items, horizon, rtg_scale
        self.pad_item = n_items
        self.rtg_proj = nn.Linear(1, d_model)
        self.group_emb = nn.Embedding(N_GROUPS + 1, d_model)  # +1: "desconocido"
        self.state_proj = nn.Linear(2, d_model)
        self.item_emb = nn.Embedding(n_items + 1, d_model)  # +1: relleno de a_t en inferencia
        self.time_emb = nn.Embedding(horizon, d_model)
        self.type_emb = nn.Embedding(3, d_model)  # 0 = R̂, 1 = s, 2 = a
        self.emb_norm = nn.LayerNorm(d_model)
        self.drop = nn.Dropout(dropout)
        layer = nn.TransformerEncoderLayer(d_model, n_heads, 4 * d_model, dropout, activation="gelu",
                                           batch_first=True, norm_first=True)
        self.transformer = nn.TransformerEncoder(layer, n_layers, enable_nested_tensor=False)
        self.out_norm = nn.LayerNorm(d_model)
        self.out_bias = nn.Parameter(torch.zeros(n_items))
        nn.init.normal_(self.item_emb.weight, std=0.02)

    def forward(self, rtg: torch.Tensor, items: torch.Tensor, state: torch.Tensor,
                groups: torch.Tensor, last_only: bool = False) -> torch.Tensor:
        """Logits (B, T, n_items) de a_t, calculadas desde el token s_t.

        Con `last_only=True` devuelve sólo las del último paso, (B, n_items): es
        lo que se usa al recomendar y evita materializar (B, T, n_items).

        rtg: (B, T) R̂_t. items: (B, T) a_t. state: (B, T) rating previo
        (`previous_ratings`). groups: (B,) grupo o `UNKNOWN_GROUP`.
        """
        B, T = items.shape
        steps = torch.arange(T, device=items.device)
        time = self.time_emb(steps)[None]  # (1, T, d)

        tok_r = self.rtg_proj((rtg / self.rtg_scale).unsqueeze(-1))
        has_prev = (steps > 0).float().expand(B, T)
        feats = torch.stack([(state - RATING_CENTER) / RATING_SCALE * has_prev, has_prev], dim=-1)
        tok_s = self.group_emb(groups)[:, None] + self.state_proj(feats)
        tok_a = self.item_emb(items)

        types = self.type_emb.weight  # (3, d)
        tokens = torch.stack([tok_r + types[0], tok_s + types[1], tok_a + types[2]], dim=2)  # (B, T, 3, d)
        tokens = (tokens + time.unsqueeze(2)).reshape(B, 3 * T, -1)  # R̂_0, s_0, a_0, R̂_1, ...
        x = self.drop(self.emb_norm(tokens))

        causal = torch.triu(torch.ones(3 * T, 3 * T, dtype=torch.bool, device=items.device), diagonal=1)
        h = self.transformer(x, mask=causal)
        h_state = self.out_norm(h[:, 1::3])  # salidas de los tokens s_t
        if last_only:
            h_state = h_state[:, -1]
        return h_state @ self.item_emb.weight[: self.n_items].T + self.out_bias


def dt_loss(model: DecisionTransformer, batch: dict[str, torch.Tensor]) -> tuple[torch.Tensor, dict[str, float]]:
    items = batch["items"]
    logits = model(batch["rtg"], items, previous_ratings(batch["ratings"]), batch["groups"])
    logits = logits.masked_fill(seen_before_mask(items, logits.shape[-1]), float("-inf"))
    loss = F.cross_entropy(logits.reshape(-1, logits.shape[-1]), items.reshape(-1))
    acc = (logits.argmax(-1) == items).float().mean().item()
    return loss, {"ce": loss.item(), "acc": acc}


class DTPolicy:
    """Política del protocolo: en cada paso pide R̂_t = objetivo − ratings ya revelados.

    Con warm-up, los ítems del warm-up llegan en `items_seen` y sus ratings
    también se restan. El objetivo se refiere a los 20 pasos de la sesión.
    """

    def __init__(self, model: DecisionTransformer, target_return: float, device: torch.device | str = "cpu"):
        self.model = model.to(device).eval()
        self.target = float(target_return)
        self.device = torch.device(device)
        self.group = UNKNOWN_GROUP

    def reset(self, group: int | None, horizon: int) -> None:
        self.group = UNKNOWN_GROUP if group is None else int(group)

    @torch.no_grad()
    def scores(self, items_seen: np.ndarray, ratings_seen: np.ndarray) -> np.ndarray:
        t = len(items_seen)
        if t >= self.model.horizon:
            raise ValueError("La sesión supera el horizonte del modelo")
        r = np.asarray(ratings_seen, dtype=np.float32)
        spent = np.concatenate([[0.0], np.cumsum(r)]).astype(np.float32)  # (t + 1,)
        rtg = torch.tensor(self.target - spent, device=self.device)[None]
        items = torch.tensor(np.append(items_seen, self.model.pad_item), dtype=torch.long, device=self.device)[None]
        state = torch.tensor(np.concatenate([[0.0], r]).astype(np.float32), device=self.device)[None]
        groups = torch.tensor([self.group], dtype=torch.long, device=self.device)
        logits = self.model(rtg, items, state, groups)[0, t]
        return logits.double().cpu().numpy()
