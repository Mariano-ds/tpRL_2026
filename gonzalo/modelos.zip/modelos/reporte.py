"""Tablas y gráficos del reporte a partir de las evaluaciones finales.

Uso, desde `2026/tp`:

    python -m modelos.reporte tabla       --dataset netflix --logs random
    python -m modelos.reporte rc          --dataset netflix --logs random
    python -m modelos.reporte logs        --dataset netflix
    python -m modelos.reporte curvas      outputs/modelos/netflix_random/dt/base/seed*

Dos fuentes de variabilidad, separadas:
- `desvio_semillas`: desvío estándar entre semillas de entrenamiento del modelo
  (media por semilla sobre usuarios). Las líneas base no se reentrenan: no tienen.
- `ic95_usuarios`: semiancho del IC 95 % por usuario de `protocolo.metricas.summarize`,
  promediado entre semillas de entrenamiento.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from protocolo.metricas import summarize  # noqa: E402

from .comun import load_json, run_dir  # noqa: E402

CONDS = ["policy", "warmup", "group_visible"]
METRICS = ["normalized", "return", "hit_rate", "ndcg@10"]
COND_LABEL = {(0, True): "Visible", (0, False): "Oculto", (5, True): "Warm-up 5, visible",
              (5, False): "Warm-up 5, oculto"}


def _sesiones_finales(dataset: str, logs: str) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    base = run_dir(dataset, logs, "final")
    sel = load_json(base / "seleccion.json")
    lb = pd.read_csv(base / "test" / "lineas_base" / "sesiones.csv").assign(train_seed=-1)
    frames = [pd.read_csv(f).assign(train_seed=int(f.parent.name[4:]))
              for f in sorted((base / "test").glob("seed*/sesiones.csv"))]
    if not frames:
        raise SystemExit(f"No hay evaluaciones en {base / 'test'}")
    return lb, pd.concat(frames, ignore_index=True), sel


def _por_semilla(df: pd.DataFrame, by: list[str]) -> pd.DataFrame:
    rows = []
    for seed, d in df.groupby("train_seed"):
        s = summarize(d.drop(columns="train_seed"), by=by)
        flat = pd.DataFrame({f"{m}_{stat}": s[(m, stat)] for m in METRICS if m in s for stat in ("mean", "ci95")})
        rows.append(flat.assign(train_seed=seed))
    return pd.concat(rows).reset_index()


def agregar_semillas(df: pd.DataFrame, by: list[str]) -> pd.DataFrame:
    per_seed = _por_semilla(df, by)
    g = per_seed.groupby(by)
    out = pd.DataFrame({"n_semillas": g.size()})
    for m in METRICS:
        if f"{m}_mean" not in per_seed:
            continue
        out[f"{m}_media"] = g[f"{m}_mean"].mean()
        out[f"{m}_desvio_semillas"] = g[f"{m}_mean"].std(ddof=1)
        out[f"{m}_ic95_usuarios"] = g[f"{m}_ci95"].mean()
    return out.reset_index()


def _etiquetas(sel: dict) -> dict[str, str]:
    lab = {f"dt_R{sel['dt_target']:g}": f"DT (R̂ = {sel['dt_target']:g}, elegido en val.)"}
    for name in sel["iql"]:
        star = " (elegido)" if name == sel["iql_elegido"] else ""
        gamma = name[1:]
        lab[f"iql_{name}_pi"] = f"IQL π, γ = {gamma}{star}"
        lab[f"iql_{name}_q"] = f"IQL máx. Q, γ = {gamma}{star}"
    return lab


def tabla_final(dataset: str, logs: str, metric: str = "normalized") -> pd.DataFrame:
    lb, modelos, sel = _sesiones_finales(dataset, logs)
    labels = _etiquetas(sel)
    modelos = modelos[modelos["policy"].isin(labels)]
    larga = pd.concat([agregar_semillas(lb, CONDS), agregar_semillas(modelos, CONDS)], ignore_index=True)
    por_grupo = pd.concat([agregar_semillas(lb, [*CONDS, "group"]),
                           agregar_semillas(modelos, [*CONDS, "group"])], ignore_index=True)
    out = run_dir(dataset, logs, "final")
    larga.to_csv(out / "tabla_larga.csv", index=False)
    por_grupo.to_csv(out / "tabla_por_grupo.csv", index=False)

    def celda(r):
        s = f"{r[f'{metric}_media']:.3f}"
        if pd.notna(r[f"{metric}_desvio_semillas"]):
            s += f" ± {r[f'{metric}_desvio_semillas']:.3f}"
        return s + f" [IC ±{r[f'{metric}_ic95_usuarios']:.3f}]"

    larga["celda"] = larga.apply(celda, axis=1)
    larga["condicion"] = [COND_LABEL[(w, v)] for w, v in zip(larga["warmup"], larga["group_visible"])]
    ancha = larga.pivot(index="policy", columns="condicion", values="celda")
    ancha = ancha[[c for c in COND_LABEL.values() if c in ancha.columns]]
    orden = ["random", "popularity", "item_mean", "group_mean", "group_posterior", "sistema_anterior_eps0",
             *labels]
    ancha = ancha.reindex([p for p in orden if p in ancha.index])
    ancha.index = [labels.get(p, f"`{p}`") for p in ancha.index]
    md = (f"### {dataset}, logs `{logs}`, test — `{metric}`\n\n"
          f"media entre semillas de entrenamiento ± desvío entre semillas [IC 95 % por usuario]\n\n"
          + _markdown(ancha))
    (out / f"tabla_{metric}.md").write_text(md, encoding="utf-8")
    print(md)
    return larga


def _markdown(df: pd.DataFrame) -> str:
    cols = ["Política", *df.columns]
    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" + "---:|" * len(df.columns)]
    lines += ["| " + " | ".join([str(i), *map(str, r)]) + " |" for i, r in zip(df.index, df.values)]
    return "\n".join(lines) + "\n"


# --- return conditioning --------------------------------------------------------------------

def return_conditioning(dataset: str, logs: str) -> pd.DataFrame:
    _, modelos, sel = _sesiones_finales(dataset, logs)
    dt = modelos[modelos["policy"].str.startswith("dt_R")].copy()
    dt["pedido"] = dt["policy"].str[4:].astype(float)
    support = load_json(run_dir(dataset, logs, "barridos", "dt", "elegido.json"))["train_return_support"]
    out = run_dir(dataset, logs, "final")

    # obtenido = retorno de la sesión completa de 20 pasos (incluye warm-up), comparable con lo pedido
    def resumen(by):
        per_seed = dt.groupby(["train_seed", "pedido", *by])[["full_return", "normalized"]].mean()
        g = per_seed.groupby(["pedido", *by])
        return pd.concat({"media": g.mean(), "desvio_semillas": g.std(ddof=1)}, axis=1)

    agg = resumen(["warmup", "group_visible"])
    grp = resumen(["warmup", "group_visible", "group"])
    agg.to_csv(out / "return_conditioning.csv")
    grp.to_csv(out / "return_conditioning_por_grupo.csv")

    fig, axes = plt.subplots(1, 4, figsize=(18, 4.5), sharey=True)
    for ax, (w, v) in zip(axes, COND_LABEL):
        d = agg.xs((w, v), level=["warmup", "group_visible"])
        x = d.index.values
        ax.errorbar(x, d[("media", "full_return")], yerr=d[("desvio_semillas", "full_return")], marker="o",
                    capsize=3, label="obtenido (media ± desvío entre semillas)")
        _decorar_rc(ax, x, support, sel)
        ax.set_title(COND_LABEL[(w, v)])
    axes[0].set_ylabel("retorno obtenido en 20 pasos")
    axes[0].legend(fontsize=8)
    fig.suptitle(f"Return conditioning — {dataset}, logs {logs}, test")
    fig.tight_layout()
    fig.savefig(out / "return_conditioning.png", dpi=130)

    fig, axes = plt.subplots(1, 2, figsize=(13, 4.8), sharey=True)
    for ax, v in zip(axes, (True, False)):
        d = grp.xs((0, v), level=["warmup", "group_visible"])
        for g, dg in d.groupby(level="group"):
            ax.plot(dg.index.get_level_values("pedido"), dg[("media", "full_return")], marker=".", label=f"grupo {g}")
        _decorar_rc(ax, agg.index.get_level_values("pedido").unique().values, support, sel)
        ax.set_title(f"Por grupo, warm-up 0, grupo {'visible' if v else 'oculto'}")
    axes[0].set_ylabel("retorno obtenido en 20 pasos")
    axes[1].legend(fontsize=7, ncol=2)
    fig.tight_layout()
    fig.savefig(out / "return_conditioning_por_grupo.png", dpi=130)
    print(agg.round(3).to_string())
    return agg


def _decorar_rc(ax, x, support, sel):
    lo, hi = min(x.min(), support["min"]), max(x.max(), support["max"])
    ax.plot([lo, hi], [lo, hi], "k--", lw=0.8, label="diagonal")
    ax.axvspan(support["p1"], support["max"], color="grey", alpha=0.12, label="soporte de train (p1–máx)")
    ax.axvline(support["max"], color="grey", lw=1)
    ax.axvline(sel["dt_target"], color="tab:red", lw=1, ls=":", label="elegido en val")
    ax.set_xlabel("retorno pedido")


# --- calidad de los logs y curvas ------------------------------------------------------------

def comparar_logs(dataset: str, logs_list=("random", "mixto")) -> pd.DataFrame:
    frames = []
    for logs in logs_list:
        f = run_dir(dataset, logs, "final", "tabla_larga.csv")
        if f.exists():
            sel = load_json(run_dir(dataset, logs, "final", "seleccion.json"))
            t = pd.read_csv(f)
            names = {f"dt_R{sel['dt_target']:g}": "DT (R̂ elegido en val.)"}
            for name in sel["iql"]:
                star = " (elegido)" if name == sel["iql_elegido"] else ""
                names[f"iql_{name}_pi"] = f"IQL π, γ = {name[1:]}{star}"
                names[f"iql_{name}_q"] = f"IQL máx. Q, γ = {name[1:]}{star}"
            t = t[~t["policy"].str.startswith(("dt_R", "iql_")) | t["policy"].isin(names)]
            t["policy"] = t["policy"].replace(names)
            frames.append(t.assign(logs=logs))
    df = pd.concat(frames, ignore_index=True)
    df = df[df["warmup"] == 0]
    df["cond"] = np.where(df["group_visible"], "visible", "oculto")
    tab = df.pivot_table(index="policy", columns=["logs", "cond"], values="normalized_media")
    out = run_dir(dataset, "comparacion_logs")
    out.mkdir(parents=True, exist_ok=True)
    tab.to_csv(out / "normalized_warmup0.csv")
    print(tab.round(3).to_string())
    return tab


def curvas(runs: list[Path]) -> None:
    for run in runs:
        run = Path(run)
        c = pd.read_csv(run / "curvas.csv")
        cols = [k[len("train_"):] for k in c.columns if k.startswith("train_")]
        fig, axes = plt.subplots(1, len(cols), figsize=(3.2 * len(cols), 3))
        for ax, k in zip(np.atleast_1d(axes), cols):
            ax.plot(c["epoch"], c[f"train_{k}"], label="train")
            if f"val_{k}" in c:
                ax.plot(c["epoch"], c[f"val_{k}"], label="val")
            ax.set_title(k)
            ax.set_xlabel("época")
        np.atleast_1d(axes)[0].legend()
        fig.suptitle(str(run.relative_to(run.parents[3])) if len(run.parents) > 3 else str(run))
        fig.tight_layout()
        fig.savefig(run / "curvas.png", dpi=110)
        plt.close(fig)
        print(run / "curvas.png")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("tabla", "rc", "logs"):
        sp = sub.add_parser(name)
        sp.add_argument("--dataset", choices=["netflix", "goodreads"], default="netflix")
        if name != "logs":
            sp.add_argument("--logs", choices=["random", "mixto", "experto"], default="random")
        if name == "tabla":
            sp.add_argument("--metric", default="normalized", choices=METRICS)
    sp = sub.add_parser("curvas")
    sp.add_argument("runs", nargs="+", type=Path)
    a = p.parse_args()
    if a.cmd == "tabla":
        tabla_final(a.dataset, a.logs, a.metric)
    elif a.cmd == "rc":
        return_conditioning(a.dataset, a.logs)
    elif a.cmd == "logs":
        comparar_logs(a.dataset)
    else:
        curvas(a.runs)


if __name__ == "__main__":
    main()
