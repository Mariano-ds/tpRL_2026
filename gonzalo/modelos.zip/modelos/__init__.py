"""Modelos del TP: Decision Transformer e IQL, entrenamiento y evaluación.

Todo se ejecuta desde `2026/tp` y usa `protocolo/` sin modificarlo:

    python -m modelos.entrenar --modelo dt --dataset netflix --logs random --seed 0
    python -m modelos.evaluar_modelo --checkpoint outputs/modelos/... --split val
    python -m modelos.experimentos barrido-dt --dataset netflix --logs random
"""
