"""Implicit Q-Learning (Kostrikov, Nair y Levine, 2022) para sesiones de recomendación.

Estado s_t = lo observable antes de recomendar a_t: grupo (o "desconocido"),
pares (ítem, rating) de los pasos < t y el paso t. Cada red tiene su propio
codificador (una GRU sobre el historial), así cada pérdida entrena sólo su red:

- V(s): regresión de expectil τ sobre Q̄(s, a) de la acción registrada (Q̄ = red objetivo).
- Q(s, a): TD con r + γ · V(s'); en el último paso del episodio el objetivo es sólo r.
- π(a | s): regresión ponderada por ventaja (AWR), pesos min(exp(β (Q̄ − V)), w_max).

El codificador devuelve T + 1 estados h_0 ... h_T: h_t resume los pasos < t, y
h_{t+1} se usa para V(s'). La recompensa es (r − centro) / escala.
"""

from __future__ import annotations

import copy

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from protocolo.datos import N_GROUPS

from .comun import UNKNOWN_GROUP, seen_before_mask

RATING_CENTER, RATING_SCALE = 3.0, 2.0


class HistoryEncoder(nn.Module):
    """(ítems, ratings) de k pasos → k + 1 estados (B, k + 1, d), causal por construcción."""

    def __init__(self, n_items: int, horizon: int = 20, d_model: int = 128):
        super().__init__()
        self.item_emb = nn.Embedding(n_items, d_model)
        self.rating_proj = nn.Linear(1, d_model)
        self.group_emb = nn.Embedding(N_GROUPS + 1, d_model)
        self.step_emb = nn.Embedding(horizon + 1, d_model)
        self.start = nn.Parameter(torch.zeros(d_model))
        self.gru = nn.GRU(d_model, d_model, batch_first=True)
        self.mlp = nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, d_model), nn.GELU())

    def forward(self, items: torch.Tensor, ratings: torch.Tensor, groups: torch.Tensor) -> torch.Tensor:
        B, k = items.shape
        g = self.group_emb(groups)[:, None]  # (B, 1, d)
        pairs = self.item_emb(items) + self.rating_proj(((ratings - RATING_CENTER) / RATING_SCALE).unsqueeze(-1))
        x = torch.cat([self.start.expand(B, 1, -1), pairs], dim=1) + g  # (B, k + 1, d)
        out, _ = self.gru(x)
        steps = torch.arange(k + 1, device=items.device)
        return self.mlp(out + g + self.step_emb(steps)[None])


class Head(nn.Module):
    def __init__(self, n_items: int, horizon: int, d_model: int, out_dim: int):
        super().__init__()
        self.encoder = HistoryEncoder(n_items, horizon, d_model)
        self.head = nn.Sequential(nn.Linear(d_model, d_model), nn.GELU(), nn.Linear(d_model, out_dim))

    def forward(self, items, ratings, groups) -> torch.Tensor:
        return self.head(self.encoder(items, ratings, groups))  # (B, k + 1, out_dim)

    def last(self, items, ratings, groups) -> torch.Tensor:
        """Salida sólo del estado actual h_k, (B, out_dim): para recomendar."""
        return self.head(self.encoder(items, ratings, groups)[:, -1])


class IQLModel(nn.Module):
    def __init__(self, n_items: int, horizon: int = 20, d_model: int = 128):
        super().__init__()
        self.n_items, self.horizon = n_items, horizon
        self.q = Head(n_items, horizon, d_model, n_items)
        self.v = Head(n_items, horizon, d_model, 1)
        self.pi = Head(n_items, horizon, d_model, n_items)
        self.q_target = copy.deepcopy(self.q).requires_grad_(False)

    @torch.no_grad()
    def update_target(self, polyak: float) -> None:
        for p_t, p in zip(self.q_target.parameters(), self.q.parameters()):
            p_t.lerp_(p, polyak)


def expectile_loss(diff: torch.Tensor, tau: float) -> torch.Tensor:
    """diff = Q_obj − V. Con τ > 0,5 pesa más quedarse por debajo (diff > 0)."""
    weight = torch.where(diff < 0, 1.0 - tau, tau)
    return (weight * diff.pow(2)).mean()


def iql_losses(model: IQLModel, batch: dict[str, torch.Tensor], gamma: float, tau: float, beta: float,
               max_weight: float = 100.0, reward_center: float = 3.0, reward_scale: float = 2.0
               ) -> tuple[dict[str, torch.Tensor], dict[str, float]]:
    items, ratings, groups = batch["items"], batch["ratings"], batch["groups"]
    T = items.shape[1]
    r = (ratings - reward_center) / reward_scale
    not_done = torch.ones(T, device=items.device)
    not_done[-1] = 0.0  # el último paso es terminal: objetivo TD = r
    idx = items.unsqueeze(-1)

    with torch.no_grad():
        q_obj = model.q_target(items, ratings, groups)[:, :T].gather(-1, idx).squeeze(-1)  # (B, T)

    v_all = model.v(items, ratings, groups).squeeze(-1)  # (B, T + 1)
    v_s = v_all[:, :T]
    loss_v = expectile_loss(q_obj - v_s, tau)

    q = model.q(items, ratings, groups)[:, :T].gather(-1, idx).squeeze(-1)
    td_target = r + gamma * not_done * v_all[:, 1:].detach()
    loss_q = F.mse_loss(q, td_target)

    with torch.no_grad():
        adv = q_obj - v_s
        raw_w = torch.exp(beta * adv)
        weights = raw_w.clamp(max=max_weight)
    logits = model.pi(items, ratings, groups)[:, :T]
    logits = logits.masked_fill(seen_before_mask(items, logits.shape[-1]), float("-inf"))
    logp = F.log_softmax(logits, dim=-1).gather(-1, idx).squeeze(-1)
    loss_pi = (weights * -logp).mean()

    diag = {
        "loss_v": loss_v.item(), "loss_q": loss_q.item(), "loss_pi": loss_pi.item(),
        "bc_nll": (-logp).mean().item(),
        "adv_mean": adv.mean().item(), "adv_std": adv.std().item(),
        "w_mean": weights.mean().item(), "w_frac_clipped": (raw_w >= max_weight).float().mean().item(),
        "v_mean": v_s.mean().item(), "q_mean": q.mean().item(),
    }
    return {"v": loss_v, "q": loss_q, "pi": loss_pi}, diag


class IQLPolicy:
    """`mode="pi"`: ordena por las logits de π (AWR). `mode="q"`: por Q(s, a) de todos los ítems.

    El protocolo ya descarta lo mostrado; "q" es el máximo de Q que IQL evita al
    entrenar, aplicado al recomendar sobre todo el catálogo disponible.
    """

    def __init__(self, model: IQLModel, mode: str = "pi", device: torch.device | str = "cpu"):
        if mode not in ("pi", "q"):
            raise ValueError("mode debe ser 'pi' o 'q'")
        self.model = model.to(device).eval()
        self.net = model.pi if mode == "pi" else model.q
        self.device = torch.device(device)
        self.group = UNKNOWN_GROUP

    def reset(self, group: int | None, horizon: int) -> None:
        self.group = UNKNOWN_GROUP if group is None else int(group)

    @torch.no_grad()
    def scores(self, items_seen: np.ndarray, ratings_seen: np.ndarray) -> np.ndarray:
        items = torch.tensor(np.asarray(items_seen, dtype=np.int64), device=self.device)[None]
        ratings = torch.tensor(np.asarray(ratings_seen, dtype=np.float32), device=self.device)[None]
        groups = torch.tensor([self.group], dtype=torch.long, device=self.device)
        out = self.net(items, ratings, groups)[0, -1]  # estado actual h_t
        return out.double().cpu().numpy()
